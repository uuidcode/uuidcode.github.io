import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import query.*;

import message.*;

import com.enterprisedt.net.ftp.FTPClient;
import com.enterprisedt.net.ftp.FTPTransferType;

public class ImageServerPanel extends JPanel { //implements Reportable {
	private static final String IMAGE_SERVER = "211.233.74.45";
	private static final int PORT = 21;
	private static final String PASSWORD = "rudrh~~";
	private static final String ID = "image";
	private static final String DIR = "/interpark_goods/org";	
	private static final String TMP = "/interpark_goods/tmp";
	private JPanel panel;
	
	
	public ImageServerPanel() {		
		this.setLayout(new BorderLayout());
		this.panel = this.makeStatePanel();
		this.add(panel, BorderLayout.CENTER);
		final JButton button = new JButton("refresh");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				remove(panel);
				panel = makeStatePanel();
				add(panel, BorderLayout.CENTER);
				revalidate();
			}
		});
		this.add(button, BorderLayout.SOUTH);
	}

	private JPanel makeStatePanel() {
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		CResultSet rs = null;//this.getReportObject(0);
		try {
			if (rs != null) {
				ResultSetTable table = new ResultSetTable(rs);
				table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
				table.getTableHeader().setReorderingAllowed(false);
				panel.add(new JScrollPane(table));
			}
		} catch (Exception e) {
		}
		return panel;
	}
	
	private int[] getImage() {
		int[] result = new int[2];
		FTPClient ftp = null;
		long start = System.currentTimeMillis();
		try {			
			ftp = new FTPClient(IMAGE_SERVER, PORT);
			MessageQueue.getInstance().sendMessage(new ConsoleMessage("connected image server"));
			ftp.login(ID, PASSWORD);
			MessageQueue.getInstance().sendMessage(new ConsoleMessage("logined in image server"));
			ftp.setType(FTPTransferType.BINARY);
			ftp.chdir(DIR);
			MessageQueue.getInstance().sendMessage(new ConsoleMessage("changed " + DIR));
			result[0] =  ftp.dir().length;
			ftp.chdir(TMP);
			MessageQueue.getInstance().sendMessage(new ConsoleMessage("changed " + TMP));
			result[1] =  ftp.dir().length;
			return result;
		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(new ConsoleMessage(e.toString()));			
		} finally {
			if (ftp != null) {
				try {
					ftp.quit();
				} catch (Exception e) {
				}
			}
			MessageQueue.getInstance().sendMessage(new ConsoleMessage("image check time:" + (System.currentTimeMillis() - start) + "ms"));
		}
		return null;
	}

	public void report() {
		Vector rows = new Vector();
		Vector data = new Vector();
		String[] columnName = {"name", "value"};
		int[] result = this.getImage();
		data.add("���� ������¡ ����� �̹��� ��");
		data.add(new Integer(result[0]));
		rows.add(data);
		data = new Vector();
		data.add("���� tmp �̹��� ��");
		data.add(new Integer(result[1]));
		rows.add(data);
		try {
			CResultSet rs = new CResultSet(columnName, rows);
			rs.setQuery(new Query(true, false, null, null, null, null, "�̹���������¡"));
			MessageQueue.getInstance().sendMessage(new ResultSetMessage(new CResultSet[] {rs}));			
		} catch (Exception e) {
		}
	}
}