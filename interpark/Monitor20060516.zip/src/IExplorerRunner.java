public class IExplorerRunner {
	private String url;
	public IExplorerRunner(String url) {
		this.url = url;
	}
	
	public void run() {
		String[] run = new String[2];
		run[0] = "C:\\Program Files\\Internet Explorer\\iexplore.exe";
		run[1] = this.url;
		Runtime runtime = Runtime.getRuntime();
		try {
			runtime.exec(run);	
			System.out.println("Ok");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
