import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import message.ConsoleMessage;
import message.Message;
import message.MessageListener;
import message.MessageQueue;

public class ConsolePanel extends JPanel implements MessageListener {
	private DefaultTableModel model = new DefaultTableModel();
	private JScrollPane scrollPane;
	private JTable table;

	public ConsolePanel() {
		this.setLayout(new BorderLayout());
		this.model.addColumn("Console");
		this.table = new JTable(model);
		this.scrollPane = new JScrollPane(this.table);
		this.add(scrollPane, BorderLayout.CENTER);
		JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		JButton removeButton = new JButton("remove");
		removeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.getDataVector().removeAllElements();
				model.fireTableDataChanged();
			}
		});
		controlPanel.add(removeButton);
		this.add(controlPanel, BorderLayout.NORTH);
		MessageQueue.getInstance().addListener(this);
	}

	public void listen(final Message message) {
		if (message != null && message instanceof ConsoleMessage) {
			ConsoleMessage consoleMessage = (ConsoleMessage) message;
			Object object = consoleMessage.getMessage();

			if (object != null && object instanceof SQLException) {
				JOptionPane.showMessageDialog(
					ConsolePanel.this,
					((SQLException) object).getMessage(),
					"Error",
					JOptionPane.ERROR_MESSAGE);
			}
			
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					table.getColumnModel().getColumn(0).setCellRenderer(
						new TextAreaCell());
					model.addRow(new Object[] { message });
					scrollPane.getVerticalScrollBar().setValue(
						scrollPane.getVerticalScrollBar().getMaximum());
					scrollToEnd();
				}
			});
		}
	}

	private void scrollToEnd() {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				if (isAdjusting()) {
					return;
				}
				int height = table.getHeight();
				table.scrollRectToVisible(
					new Rectangle(0, height - 1, table.getWidth(), height));
			}
		});
	}

	private boolean isAdjusting() {
		JScrollBar scrollBar = this.scrollPane.getVerticalScrollBar();
		if (scrollBar != null && scrollBar.getValueIsAdjusting()) {
			return true;
		}
		return false;
	}
}
