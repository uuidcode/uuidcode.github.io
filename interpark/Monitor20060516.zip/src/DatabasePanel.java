import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.border.Border;

public class DatabasePanel extends JPanel {
	public DatabasePanel() {
		this.setupUI();
	}

	private void setupUI() {
		this.setLayout(new BorderLayout());
		JTabbedPane mainTabbedPane = new JTabbedPane();
		this.add(mainTabbedPane, BorderLayout.CENTER);

		Database[] database = Config.getDatabase();
		for (int i = 0; i < database.length; i++) {
			PropertyTableModel tableModel = new PropertyTableModel();
			tableModel.setIsCellEditable(true);
			tableModel.addRow("name", database[i].getName());
			tableModel.addRow("driver", database[i].getDriver());
			tableModel.addRow("url", database[i].getUrl());
			tableModel.addRow("user", database[i].getUser());
			tableModel.addRow("password", database[i].getPassword());
			JTable table = new JTable(tableModel);
			JPanel panel = new JPanel(new GridLayout(2, 1));
			JPanel databasePanel = new JPanel(new BorderLayout());
			databasePanel.add(new JScrollPane(table), BorderLayout.CENTER);
			Border databaseBorder = BorderFactory.createEtchedBorder();
			databaseBorder =
				BorderFactory.createTitledBorder(databaseBorder, "database");
			databasePanel.setBorder(databaseBorder);
			panel.add(databasePanel);

			DatabaseMetaDataPanel metaDataPanel =
				new DatabaseMetaDataPanel(database[i].getName());

			JTabbedPane tableInfoTabbedPane = new JTabbedPane();
			tableInfoTabbedPane.add("meta data", metaDataPanel);
			tableInfoTabbedPane.add(
				"catalog",
				new CatalogPanel(database[i].getName()));
			tableInfoTabbedPane.add(
				"schema",
				new SchemaPanel(database[i].getName()));

			Border metaDataBorder = BorderFactory.createEtchedBorder();
			metaDataBorder =
				BorderFactory.createTitledBorder(
					metaDataBorder,
					"database info");
			tableInfoTabbedPane.setBorder(metaDataBorder);

			panel.add(tableInfoTabbedPane);
			mainTabbedPane.add(database[i].getName(), panel);
		}
	}
}
