import java.awt.Color;
import java.awt.Component;
import java.awt.event.MouseEvent;
import java.util.EventObject;
import java.util.Hashtable;
import java.util.StringTokenizer;

import javax.swing.AbstractCellEditor;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

public class TextAreaCell
	extends AbstractCellEditor
	implements TableCellRenderer, TableCellEditor {
	private static final int MARGIN = 5;
	protected static Border noFocusBorder = new EmptyBorder(1, 1, 1, 1);
	protected static final int LABEL_HEIGHT = 16;

	private JScrollPane scrollPane;
	private JTextArea textarea;
	private JPanel panel;
	private Color unselectedForeground;
	private Color unselectedBackground;
	private Hashtable lineCount = new Hashtable();
	private JTable table;
	private int currentEditedRow;
	private int lineCountOfcurrentEditedRow;
	
	public TextAreaCell() {
		this.textarea = new JTextArea();
		this.scrollPane = new JScrollPane(textarea);
		this.panel = new JPanel();
		this.panel.setLayout(null);
		this.panel.setBackground(Color.white);
		this.panel.setOpaque(true);
		this.panel.setBorder(noFocusBorder);
	}

	public Component getTableCellRendererComponent(
		JTable table,
		Object value,
		boolean isSelected,
		boolean hasFocus,
		int row,
		int column) {
		this.panel.removeAll();

		int labelWidth = table.getColumnModel().getColumn(column).getWidth();
		
		int count = 0;
		if (value.toString().trim().length() == 0) {
			count = 1;
		} else {
			boolean isNewLine = false;
			StringTokenizer tokenizer = new StringTokenizer(value.toString(), "\n", true);
			while (tokenizer.hasMoreTokens()) {
				String str = tokenizer.nextToken();
				
				if (!isNewLine && str.equals("\n")) {
					isNewLine = true;
					continue;
				} else {
					isNewLine = false;
				}		
				
				JLabel label = new JLabel(str);
				label.setBounds(0, count * LABEL_HEIGHT, labelWidth, LABEL_HEIGHT);
				panel.add(label);
				count++;
			}
		}
		
		if (isSelected) {
			this.panel.setForeground(table.getSelectionForeground());
			this.panel.setBackground(table.getSelectionBackground());
		} else {
			this.panel.setForeground(
				(unselectedForeground != null)
					? unselectedForeground
					: table.getForeground());
			this.panel.setBackground(
				(unselectedBackground != null)
					? unselectedBackground
					: table.getBackground());
		}

		if (hasFocus) {
			this.panel.setBorder(
				UIManager.getBorder("Table.focusCellHighlightBorder"));
			if (table.isCellEditable(row, column)) {
				this.panel.setForeground(
					UIManager.getColor("Table.focusCellForeground"));
				this.panel.setBackground(
					UIManager.getColor("Table.focusCellBackground"));
			}
		} else {
			this.panel.setBorder(noFocusBorder);
		}
		
		Object object = this.lineCount.get(new Integer(row));
		boolean setRowHeight = false;
		
		if (object == null) {
			this.lineCount.put(new Integer(row), new Integer(count));
			setRowHeight = true;
		} else {
			if (((Integer) object).intValue() != count) {
				this.lineCount.put(new Integer(row), new Integer(count));
				setRowHeight = true;
			}
		}
		
		if (setRowHeight) {
			table.setRowHeight(row, count*LABEL_HEIGHT + MARGIN);
		}
		return this.panel;
	}

	public Component getTableCellEditorComponent(
		JTable table,
		Object value,
		boolean isSelected,
		int row,
		int column) {
		this.table = table;
		this.currentEditedRow = row;
		
		this.textarea.setText(value.toString());
				
		Object object = this.lineCount.get(new Integer(row));
		if (object != null) {
			this.lineCountOfcurrentEditedRow = ((Integer) object).intValue();
			table.setRowHeight(row, (this.lineCountOfcurrentEditedRow + 1)*LABEL_HEIGHT + MARGIN);
		}
			
		return this.scrollPane;
	}

	public Object getCellEditorValue() {
		return this.textarea.getText();
	}

	public boolean isCellEditable(EventObject anEvent) {
		if (anEvent instanceof MouseEvent) {
			return ((MouseEvent) anEvent).getClickCount() >= 2;
		}
		return true;
	}
	
	public boolean stopCellEditing() {
		System.out.println("stopCellEditing");
		if (this.table != null) {
			table.setRowHeight(this.currentEditedRow, this.lineCountOfcurrentEditedRow*LABEL_HEIGHT + MARGIN);
		}
		return super.stopCellEditing();
	}
	
	public void cancelCellEditing() {
		System.out.println("cancelCellEditing");
		super.cancelCellEditing();
	}

}