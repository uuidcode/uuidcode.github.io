import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import message.ConsoleMessage;
import message.MessageQueue;
import message.ResultSetMessage;
import query.CResultSet;
import query.ResultSetTable;

import com.enterprisedt.net.ftp.FTPClient;
import com.enterprisedt.net.ftp.FTPTransferType;

public class CronViewer extends JPanel { //implements Reportable {
	private static final String CRON_SERVER = "211.233.74.33";
	private static final int PORT = 21;
	private static final String ID = "ec";
	private static final String PASSWORD = "ec2002";
	private static final String DIR = "/var/cron";
	private JPanel panel = new JPanel();

	public CronViewer() {
		this.setLayout(new BorderLayout());
		this.add(panel, BorderLayout.CENTER);
		final JButton button = new JButton("refresh");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Thread() {
					public void run() {
						button.setText("refreshing");
						button.setEnabled(false);
						remove(panel);
						panel = makeStatePanel();
						add(panel, BorderLayout.CENTER);
						revalidate();		
						button.setText("refresh");
						button.setEnabled(true);
					}
				}.start();
				
			}
		});
		this.add(button, BorderLayout.SOUTH);
	}

	private Vector split(String string, String delimiter) {
		StringTokenizer tokenizer = new StringTokenizer(string, delimiter);
	
		Vector tokens = new Vector();
		while (tokenizer.hasMoreTokens()) {
			tokens.add(tokenizer.nextToken());
		}
		return tokens;
	}
		
	private JPanel makeStatePanel() {
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		CResultSet[] rs = null;//this.getReportObject();
		try {
			if (rs != null) {
				ResultSetTable table = new ResultSetTable(rs[0]);
				table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
				table.getTableHeader().setReorderingAllowed(false);
				panel.add(new JScrollPane(table));
			}
		} catch (Exception e) {
		}
		return panel;
	}
		
	public void report() {
		int[] result = new int[2];
		FTPClient ftp = null;
		long start = System.currentTimeMillis();
		try {
			ftp = new FTPClient(CRON_SERVER, PORT);
			MessageQueue.getInstance().sendMessage(
				new ConsoleMessage("connected cron server"));
			ftp.login(ID, PASSWORD);
			MessageQueue.getInstance().sendMessage(
				new ConsoleMessage("logined in cron server"));
			ftp.setType(FTPTransferType.BINARY);
			ftp.chdir(DIR);
				MessageQueue.getInstance().sendMessage(
					new ConsoleMessage("changed " + DIR));
			byte[] content = ftp.get("log");
			String contentString = new String(content);
			Vector log = this.split(contentString, "\n");
			Vector filteredLog = new Vector();
			for (int i = 0; i < log.size(); i++) {
				if (log.get(i).equals(">  CMD: su - ec -c \"(cd /usr7/ec/scm/demon; java DelvProsessDemon )\"") ||
					log.get(i).equals(">  CMD: su - ec -c \"(cd /usr7/ec/scm/demon; java BulkGoodsDaemon)\"")) {
					Vector row1 = new Vector();
					row1.add(log.get(i));
					filteredLog.add(row1);
					Vector row2 = new Vector();
					row2.add(log.get(++i));
					filteredLog.add(row2);
				}
			}
			
			Vector sortedFilteredLog = new Vector();
			for (int i = (filteredLog.size() - 1); i >= 0; i--) {
				sortedFilteredLog.add(filteredLog.get(i));
			}
			CResultSet[] rs = new CResultSet[1];
			rs[0] = new CResultSet(new String[] {"log"}, sortedFilteredLog);
			MessageQueue.getInstance().sendMessage(new ResultSetMessage(rs));
		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(
				new ConsoleMessage(e.toString()));
		} finally {
			if (ftp != null) {
				try {
					ftp.quit();
				} catch (Exception e) {
				}
			}
			MessageQueue.getInstance().sendMessage(
				new ConsoleMessage(
					"check time:"
						+ (System.currentTimeMillis() - start)
						+ "ms"));
		}
	}
}
