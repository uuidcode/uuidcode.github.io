import java.awt.BorderLayout;
import java.util.Enumeration;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.Border;

public class JavaPropertyPanel extends JPanel {
	public JavaPropertyPanel() {
		PropertyTableModel tableModel = new PropertyTableModel();
		Properties props = System.getProperties();

		Enumeration enum = props.propertyNames();
		while (enum.hasMoreElements()) {
			String propName = (String) enum.nextElement();
			String propValue = (String) props.get(propName);

			tableModel.addRow(propName, propValue);
		}

		JTable table = new JTable(tableModel);
		this.setLayout(new BorderLayout());
		this.add(new JScrollPane(table));

		Border etchedTitleBorder = BorderFactory.createEtchedBorder();
		etchedTitleBorder =
			BorderFactory.createTitledBorder(
				etchedTitleBorder,
				"Java Properties");
		this.setBorder(etchedTitleBorder);
		UIUtilities.fixColumnSize(table);
	}
}
