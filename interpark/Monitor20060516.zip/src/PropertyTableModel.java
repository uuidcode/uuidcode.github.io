import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class PropertyTableModel extends DefaultTableModel {
	private boolean isCellEditable;
	private Object object;

	public PropertyTableModel() {
		columnIdentifiers.add("Property");
		columnIdentifiers.add("Value");
	}

	public PropertyTableModel(Object object, boolean isCellEditable) {
		this();
		this.object = object;
		this.isCellEditable = isCellEditable;
		Field[] fields = this.object.getClass().getDeclaredFields();
		AccessibleObject.setAccessible(fields, true);
		try {
			for (int i = 0; i < fields.length; i++) {
				addRow(fields[i].getName(), fields[i].get(this.object));
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void addRow(String propertyName, Object value) {
		Object[] row = { propertyName, value };
		this.addRow(row);
	}

	public void addRow(String propertyName, String value) {
		Object[] row = { propertyName, value };
		this.addRow(row);
	}

	public void addRow(String propertyName, boolean value) {
		Object[] row = { propertyName, String.valueOf(value)};
		this.addRow(row);
	}

	public void addRow(String propertyName, int value) {
		Object[] row = { propertyName, String.valueOf(value)};
		this.addRow(row);
	}

	public void removeAll() {
		dataVector.removeAllElements();
		fireTableDataChanged();
	}

	public boolean isCellEditable(int row, int column) {
		return this.isCellEditable && column == 1;
	}

	public void setIsCellEditable(boolean isCellEditable) {
		this.isCellEditable = isCellEditable;
	}

	public Object getValueAt(int row, int column) {
		if (object != null) {
			Field[] fields = this.object.getClass().getDeclaredFields();
			AccessibleObject.setAccessible(fields, true);
			try {
				return fields[row].get(this.object);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			return "";
		} else {
			return super.getValueAt(row, column);
		}
	}

	public void setValueAt(Object aValue, int row, int column) {
		if (this.isCellEditable) {
			Field[] fields = this.object.getClass().getDeclaredFields();
			AccessibleObject.setAccessible(fields, true);

			try {
				fields[row].set(this.object, aValue);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
	}

	public String asXML() {
		if (!this.isCellEditable) {
			return null;
		}

		String name = object.getClass().getName();
		name = name.substring(0, 1).toLowerCase() + name.substring(1);
		Field[] fields = object.getClass().getDeclaredFields();
		AccessibleObject.setAccessible(fields, true);
		StringBuffer buffer = new StringBuffer();
		buffer.append("<");
		buffer.append(name);
		buffer.append(">\r\n");
		try {
			for (int i = 0; i < fields.length; i++) {
				buffer.append("<");
				buffer.append(fields[i].getName());
				buffer.append(">");
				buffer.append(fields[i].get(this.object));
				buffer.append("</");
				buffer.append(fields[i].getName());
				buffer.append(">\r\n");
			}
		} catch (Exception e) {
		}
		buffer.append("</");
		buffer.append(name);
		buffer.append(">\r\n");
		return buffer.toString();
	}

	public static void main(String[] args) {
		JFrame f = new JFrame("Test");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Database database =
			new Database("test", "url", "driver", "scott", "tiger");
		final PropertyTableModel model = new PropertyTableModel(database, true);
		JPanel panel = new JPanel(new BorderLayout());
		JTable table = new JTable(model);
		panel.add(new JScrollPane(table), BorderLayout.CENTER);
		JButton button = new JButton("OK");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println(model.asXML());
			}
		});
		panel.add(button, BorderLayout.SOUTH);
		f.setContentPane(panel);
		f.setSize(400, 400);
		f.setVisible(true);
	}
}
