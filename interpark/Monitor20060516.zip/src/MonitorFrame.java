import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.util.Enumeration;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JToolBar;
import javax.swing.UIDefaults;
import javax.swing.UIManager;

import action.ActionManager;

import query.QueryHistory;

public class MonitorFrame extends JFrame {
	private JMenu menu;
	private JMenuItem closeAllItem;

	public MonitorFrame(MonitorPanel monitorPanel) {
		super("Rabbit Girl");

		this.addWindowListener(new WindowListener() {
			public void windowOpened(WindowEvent e) {
			}

			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}

			public void windowClosed(WindowEvent e) {
				System.out.println("EXIT");
				System.exit(0);
			}

			public void windowIconified(WindowEvent e) {

			}

			public void windowDeiconified(WindowEvent e) {

			}

			public void windowActivated(WindowEvent e) {

			}

			public void windowDeactivated(WindowEvent e) {

			}
		});

		JToolBar toolBar = ActionManager.getToolBar();
		toolBar.setRollover(true);
		toolBar.setFloatable(true);
		JPanel panel = new JPanel(new BorderLayout());
		panel.add(toolBar, BorderLayout.NORTH);
		panel.add(monitorPanel, BorderLayout.CENTER);
		this.setContentPane(panel);
		this.setJMenuBar(ActionManager.getMenuBar());
		QueryHistory.read();
	}

	public boolean deleteDirectory(File path) {
		if (path.exists()) {
			File[] files = path.listFiles();
			for (int i = 0; i < files.length; i++) {
				if (files[i].isDirectory()) {
					deleteDirectory(files[i]);
				} else {
					files[i].delete();
				}
			}
		}
		return (path.delete());
	}

	public static void main(String[] args) throws Exception {
		
//		UIManager.put(Options.USE_SYSTEM_FONTS_APP_KEY, Boolean.TRUE);
//		//Options.setGlobalFontSizeHints(FontSizeHints.MIXED);
//		Options.setDefaultIconSize(new Dimension(18, 18));
//
//		String lafName =
//			LookUtils.IS_OS_WINDOWS_XP
//				? Options.getCrossPlatformLookAndFeelClassName()
//				: Options.getSystemLookAndFeelClassName();
//
//		try {
//			UIManager.setLookAndFeel(lafName);
//		} catch (Exception e) {
//			System.err.println("Can't set look & feel:" + e);
//		}
				
		SplashPanel splashPanel = new SplashPanel();
		splashPanel.showSplash();
		
		//UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		UIDefaults uiDefaults = UIManager.getDefaults();
		Color defaultColor = new Color(236, 233, 216);
		Font font = new Font("Gulim", Font.PLAIN, 12);
		Enumeration enum = uiDefaults.keys();
		while (enum.hasMoreElements()) {
			Object obj = enum.nextElement();

			String key = obj.toString();
			if (key.toLowerCase().indexOf("font") != -1) {
				UIManager.put(key, font);
			}
			
			Object value = UIManager.get(key);
			if (value != null && value.toString().toLowerCase().indexOf("[r=204,g=204,b=204]") != -1) {
				UIManager.put(key, defaultColor);
			}
		}
		
//		UIManager.put("Button.background", new Color(212, 208, 208));
//		UIManager.put("OptionPane.background", new Color(212, 208, 208));
//		UIManager.put("Panel.background", new Color(212, 208, 208));
		UIManager.put("TabbedPane.background", defaultColor);
//		UIManager.put("TabbedPane.tabAreaBackground", new Color(212, 208, 208));
//		UIManager.put("TabbedPane.light", new Color(212, 208, 208));
//		UIManager.put("TabbedPane.selected", new Color(255, 255, 255));
//		UIManager.put("Label.background", new Color(212, 208, 208));
//		UIManager.put("ScrollBar.background", new Color(212, 208, 208));
//		UIManager.put("ViewPoint.background", new Color(212, 208, 208));
//		UIManager.put("MenuBar.background", new Color(212, 208, 208));
//		UIManager.put("Menu.background", new Color(212, 208, 208));
//		UIManager.put("PopUpMenu.background", new Color(212, 208, 208));
		UIManager.put("Divider.background", defaultColor);
		UIManager.put("ScrollBar.thumb", defaultColor);
		UIManager.put("ScrollBar.thumbHighlight", defaultColor);
		UIManager.put("ScrollBar.background", defaultColor);
//		UIManager.put("TableHeader.background", new Color(212, 208, 208));
//		UIManager.put("ScrollPane.background", new Color(212, 208, 208));
//		UIManager.put("Viewport.background", new Color(212, 208, 208));
//		UIManager.put("ToolBar.background", new Color(212, 208, 208));
		UIManager.put("Desktop.background", new Color(132, 130, 132));

		//UIManager.put("InternalFrame.closeIcon", new ImageIcon("resource/image/close.gif"));
		//UIManager.put("InternalFrame.iconizeIcon", new ImageIcon("iconify.gif"));
		//UIManager.put("InternalFrame.maximizeIcon", new ImageIcon("resource/image/maximize.gif"));
		//UIManager.put("InternalFrame.altMaximizeIcon", new ImageIcon("resource/image/altMax.gif"));

		

		MonitorPanel panel = new MonitorPanel();
		MonitorFrame frame = new MonitorFrame(panel);
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("resource/image/rabbitgirl.jpg"));
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		splashPanel.setVisible(false);
		frame.setVisible(true);
		frame.deleteDirectory(new File(".cash"));
		
	}
}