import java.awt.BorderLayout;
import java.awt.Component;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListCellRenderer;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

public class CheckBoxCellRender implements ListCellRenderer{
	protected static Border noFocusBorder;
	private JPanel panel = new JPanel();
	private JLabel label = new JLabel();
	private JCheckBox checkbox = new JCheckBox();
	
	public CheckBoxCellRender() {
		this.panel.setLayout(new BorderLayout());
		this.panel.add(this.checkbox, BorderLayout.WEST);
		this.panel.add(this.label, BorderLayout.CENTER);
		this.label.setOpaque(true);
		this.checkbox.setOpaque(true);
		this.panel.setOpaque(true);
		
		if (noFocusBorder == null) {
			noFocusBorder = new EmptyBorder(1, 1, 1, 1);
		}
	}
	
	public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
		this.label.setText(value.toString());
		if (isSelected) {
			this.checkbox.setBackground(list.getSelectionBackground());
			this.checkbox.setForeground(list.getSelectionForeground());
			this.label.setBackground(list.getSelectionBackground());
			this.label.setForeground(list.getSelectionForeground());
			this.panel.setBackground(list.getSelectionBackground());
			this.panel.setForeground(list.getSelectionForeground());
		}
		else {
			this.checkbox.setBackground(list.getBackground());
			this.checkbox.setForeground(list.getForeground());
			this.label.setBackground(list.getBackground());
			this.label.setForeground(list.getForeground());
			this.panel.setBackground(list.getBackground());
			this.panel.setForeground(list.getForeground());
		}
		this.panel.setBorder((cellHasFocus) ? UIManager.getBorder("List.focusCellHighlightBorder") : noFocusBorder);
		return this.panel;
	}

}
