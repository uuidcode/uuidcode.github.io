import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;

import message.ConsoleMessage;
import message.MessageQueue;
import query.QueryHistoryPanel;
import query.MainPanel;
import query.ResultHistoryPanel;

public class MonitorPanel extends JPanel {
	public MonitorPanel() throws Exception {
		this.setLayout(new BorderLayout());		
		JSplitPane splitPanel = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		MainPanel mainPanel = new MainPanel(null);
		splitPanel.setLeftComponent(mainPanel);
		//splitPanel.setOneTouchExpandable(true);
		splitPanel.setDividerSize(5);
		splitPanel.setDividerLocation(700);
		JTabbedPane tab = new JTabbedPane();
		tab.addTab("log", new ConsolePanel());
		tab.addTab("history", new QueryHistoryPanel());
		tab.addTab("result history", new ResultHistoryPanel());
		//this.tab.addTab("cron", new CronViewer());
		//this.tab.addTab("server", new ServerStatPanel());
		tab.addTab("thread", new ThreadViewerPanel());
//		this.tab.addTab("database", new DatabasePanel());
		tab.addTab("loaded classes", new LoadedClassesPanel());
		//this.tab.addTab("memory", new MemoryUsagePanel());
		tab.addTab("properties", new JavaPropertyPanel());
		splitPanel.setRightComponent(tab);
		add(splitPanel, BorderLayout.CENTER);
		MessageQueue.getInstance().sendMessage(new ConsoleMessage("started"));
	}
}