import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.util.Hashtable;
import java.util.Vector;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
public class XMLObject {
	private Hashtable fieldHashtable = new Hashtable();
	private Vector fieldVector = new Vector();
	private Object object;

	public XMLObject(Object object) {
		this.object = object;
		Field[] fields = object.getClass().getDeclaredFields();
		AccessibleObject.setAccessible(fields, true);

		try {
			for (int i = 0; i < fields.length; i++) {
				this.add(fields[i]);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void add(Field field) {
		this.fieldHashtable.put(field.getName().toUpperCase(), field);
		this.fieldVector.add(field);
	}

	public Object getValue(String fieldName, Object object)
		throws IllegalArgumentException, IllegalAccessException {
		return ((Field) fieldHashtable.get(fieldName)).get(object);
	}

	public Object getValue(int i, Object object)
		throws IllegalArgumentException, IllegalAccessException {
		return ((Field) this.fieldVector.get(i)).get(object);
	}

	public boolean set(String fieldName, Object object, Object value) {
		Object fieldObject = this.fieldHashtable.get(fieldName);
		if (fieldObject != null && fieldObject instanceof Field) {
			try {
				((Field) fieldObject).set(object, value);
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
		}
		return false;
	}

	public Field getField(String fileName) {
		return (Field) fieldHashtable.get(fileName);
	}

	public Field getField(int i) {
		return (Field) this.fieldVector.get(i);
	}

	public int size() {
		return this.fieldVector.size();
	}

	private void setField(Field field, String value) {
		try {
			if (field.getType() == boolean.class) {
				field.set(this.object, Boolean.valueOf(value));
			} else if (field.getType() == int.class) {
				try {
					Integer.parseInt(value);
					field.set(this.object, Integer.valueOf(value));
				} catch (Exception e) {
				}
			} else if (field.getType() == long.class) {
				try {
					Long.parseLong(value);
					field.set(this.object, Long.valueOf(value));
				} catch (Exception e) {
				}
			} else if (field.getType() == float.class) {
				try {
					Float.parseFloat(value);
					field.set(this.object, Float.valueOf(value));
				} catch (Exception e) {
				}
			} else if (field.getType() == double.class) {
				try {
					Double.parseDouble(value);
					field.set(this.object, Double.valueOf(value));
				} catch (Exception e) {
				}
			} else {
				field.set(this.object, value);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Object convertElementToObject(Element element) {
		for (int i = 0; i < this.fieldVector.size(); i++) {
			Field field = (Field) this.fieldVector.get(i);
			this.setField(field, element.elementText(field.getName()));
		}
		return this.object;
	}

	public Element convertObjectToElement() {
		Element element =
			DocumentHelper.createElement(this.object.getClass().getName());
		try {
			for (int i = 0; i < this.fieldVector.size(); i++) {
				Field field = (Field) this.fieldVector.get(i);
				Element newElement = DocumentHelper.createElement(field.getName());
				newElement.addText(field.get(this.object).toString());
				element.add(newElement);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return element;
	}
	
	public static void main(String[] args) {
		Database database = new Database("1", "2", "3", "4", "5");
		XMLObject object = new XMLObject(database);
		Element element = object.convertObjectToElement();
		System.out.println(element.asXML());
	}
}
