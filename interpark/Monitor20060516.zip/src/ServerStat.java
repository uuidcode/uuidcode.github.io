import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class ServerStat {
	private String server;
	private String port;
	
	public ServerStat(String server, String port) {
		this.server = server;
		this.port = port;
	}

	public String getPort() {
		return port;
	}

	public String getServer() {
		return server;
	}

	public void setPort(String string) {
		port = string;
	}

	public String checkStat() {
		Socket socket = null;
		InputStream in = null;
		OutputStream out = null;
		try {
			socket =
				new Socket(
					this.server,
					Integer.parseInt(this.port));
			socket.setSoTimeout(1000 * 3);
			in = socket.getInputStream();
			out = socket.getOutputStream();
			if (in != null && out != null) {
				return "OK";
			} else {
				return "FAIL";
			}
		} catch (Exception e) {
			return e.getMessage();
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (Exception e) {
				}
			}

			if (out != null) {
				try {
					out.close();
				} catch (Exception e) {
				}
			}

			if (socket != null) {
				try {
					socket.close();
				} catch (Exception e) {
				}
			}
		}
	}
}
