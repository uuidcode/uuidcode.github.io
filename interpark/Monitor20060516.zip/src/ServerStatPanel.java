import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import message.MessageQueue;
import message.ResultSetMessage;

import query.CResultSet;
import query.Query;
import query.ResultSetTable;

public class ServerStatPanel extends JPanel { //implements Reportable {
	private JPanel panel;

	public ServerStatPanel() {
		this.setLayout(new BorderLayout());
		this.panel = this.makeStatePanel();
		this.add(panel, BorderLayout.CENTER);
		final JButton button = new JButton("refresh");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				remove(panel);
				panel = makeStatePanel();
				add(panel, BorderLayout.CENTER);
				revalidate();
			}
		});
		this.add(button, BorderLayout.SOUTH);
	}

	private JPanel makeStatePanel() {		
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		CResultSet rs = null;//this.getReportObject(0);
		
		try {
			if (rs != null) {
				JTable table = new ResultSetTable(rs);
				table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
				table.getTableHeader().setReorderingAllowed(false);		
				panel.add(new JScrollPane(table));
			}
		} catch (Exception e) {
		}
		
		return panel;
	}

	public void report() {
		Vector rows = new Vector();
		String[] columnName = {"IP", "port", "stat"};
				
		ServerStat[] serverStat = Config.getServerStat();
		for (int i = 0; i < serverStat.length; i++) {
			serverStat[i].checkStat();
			Vector data = new Vector();
			data.add(serverStat[i].getServer());
			data.add(serverStat[i].getPort());
			data.add(serverStat[i].checkStat());
			rows.add(data);
		}	
		
		try {
			CResultSet rs = new CResultSet(columnName, rows);
			rs.setQuery(new Query(true, false, null, null, null, null, "��������"));
			MessageQueue.getInstance().sendMessage(new ResultSetMessage(new CResultSet[] {rs}));
		} catch (Exception e) {
		}
	}
}
