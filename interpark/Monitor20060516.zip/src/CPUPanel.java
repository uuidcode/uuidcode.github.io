import java.awt.Color;
import java.awt.GridLayout;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.Minute;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

import com.enterprisedt.net.ftp.FTPClient;

public class CPUPanel extends JPanel {
	private FTPClient ftp = null;
	
	public CPUPanel() {
		this.setupUI();
	}
		
	private void setupUI() {
		this.setLayout(new GridLayout(1, 2));
		this.add(new ChartPanel(this.makeChart("wscm1")));
		this.add(new ChartPanel(this.makeChart("wscm2")));
		
		if (this.ftp != null) {
			try {
				this.ftp.quit();
			} catch (Exception e) {
			}			
		}
	}

	private JFreeChart makeChart(String systemName) {
		String filename = new SimpleDateFormat("yyyyMMdd").format(new Date()) + "." + systemName;
		String fileContent = this.getFile(filename);
		
		Date date = new Date();
		int year = Integer.parseInt(new SimpleDateFormat("yyyy").format(date));
		int month = Integer.parseInt(new SimpleDateFormat("MM").format(date));
		int day = Integer.parseInt(new SimpleDateFormat("dd").format(date));
		TimeSeries timeSeries = new TimeSeries(systemName, Minute.class);
		
		for (int i = 0; i < 30*24; i++) {
			timeSeries.add(new Minute(2*i%60, 2*i/60, day, month, year), 0);
		}
		
		StringTokenizer tokenizer = new StringTokenizer(fileContent, "\r\n");
		if (tokenizer != null) {
			tokenizer.nextToken();
		}
		
		while (tokenizer.hasMoreTokens()) {
			try {			
				String line = tokenizer.nextToken();
				int hour = Integer.parseInt(line.substring(0, 2).trim());
				int minute = Integer.parseInt(line.substring(3, 5).trim());
				int cpu = Integer.parseInt(line.substring(10, 12).trim());
				timeSeries.addOrUpdate(new Minute(minute, hour, day, month, year), cpu);
			} catch (Exception e) {				
			}
		}
		TimeSeriesCollection collection = new TimeSeriesCollection();
		collection.addSeries(timeSeries);
		JFreeChart chart =
			ChartFactory.createTimeSeriesChart(
				"cpu",
				"time",
				"cpu",
				collection,
				true,
				true,
				true);
		XYPlot plot = chart.getXYPlot();
		plot.getRenderer().setPaint(Color.blue);
		plot.getRangeAxis().setRange(0, 100);
		return chart;
	}

	private String getFile(String filename) {
		try {
			if (this.ftp == null) {
				this.ftp = new FTPClient("211.233.74.33", 21);
				this.ftp.login("ec", "ec2002");
			}
			byte[] fileContent = ftp.get("/usr7/Monitor/" + filename);
			return new String(fileContent);
		} catch (Exception e) {
			System.out.println("Server Error");
		}
		return null;
	}
}
