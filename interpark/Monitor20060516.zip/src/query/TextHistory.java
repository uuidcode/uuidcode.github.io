package query;

import java.io.Serializable;

public class TextHistory implements Serializable {
	private String text;
	private int caretPosition;
	
	public TextHistory(String text, int caretPosition) {
		this.text = text;
		this.caretPosition = caretPosition;
	}
	
	public int getCaretPosition() {
		return caretPosition;
	}

	public String getText() {
		return text;
	}
}