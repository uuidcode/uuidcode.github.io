package query;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FileUserObject {
	private File file;
	private CResultSet rs;
	
	public FileUserObject(File file) {
		this.file = file;
		if (this.file.isFile()) {
			ObjectInputStream ois = null;
			try {
				ois = new ObjectInputStream(new FileInputStream(this.file));
				Object object = ois.readObject();
				if (object != null && object instanceof CResultSet) {
					this.rs = (CResultSet) object;
				}
			} catch (Exception e) {

			} finally {
				if (ois != null) {
					try {
						ois.close();
					} catch (Exception e) {

					}
				}
			}
		}
	}

	public String toString() {
		if (rs == null) {
			return this.file.getName();
		} else {
			Date date = new Date(this.file.lastModified());
			SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
			String dateString = format.format(date);
			String[] parameter = rs.getQuery().getParameter();
			StringBuffer name = new StringBuffer();
			name.append(dateString);
			name.append(" ");
			name.append(rs.getQuery().getComment());
			for (int i = 0; parameter != null && i < parameter.length; i++) {
				name.append("[");
				name.append(parameter[i]);
				name.append("]");
			}
			return name.toString();
		}
	}

	public File getFile() {
		return file;
	}

	public CResultSet getRs() {
		return rs;
	}
}
