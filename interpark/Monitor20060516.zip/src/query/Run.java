package query;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import message.HistoryFileMessage;
import message.MessageQueue;
import message.ResultSetMessage;

public class Run {
	private static void save(CResultSet rs) {
		String filename = ResultHistoryPanel.METADATA_DIR;
		filename += File.separator;
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd HHmmss");
		String dateFormate = format.format(new Date());
		filename += dateFormate.substring(0, 8);
		File dir = new File(filename);
		if (!dir.exists()) {
			dir.mkdirs();
		}

		filename = dateFormate.substring(9) + " " + rs.getQuery().getComment();
		File dataFile = new File(dir, filename);
		boolean isOK = false;
		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(new FileOutputStream(dataFile));
			oos.writeObject(rs);
			isOK = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (oos != null) {
				try {
					oos.close();
				} catch (Exception e) {
				}
			}
		}

		if (isOK) {
			MessageQueue.getInstance().sendMessage(
				new HistoryFileMessage(dataFile.getAbsolutePath()));
		}
	}

	public static void run(final Query[] query, final String[] parameter) {
		new Thread() {
			public void run() {
				Vector resultsetVector = new Vector();
				for (int i = 0; i < query.length; i++) {
					query[i].setParameter(parameter);
					CResultSet rs = QueryExecutor.getData(query[i]);
					resultsetVector.add(rs);
					if (query[i].getFilename() != null) {
						save(rs);
					}

				}

				if (query[0].getFilename() != null) {
					QueryHistory history = new QueryHistory(query);
					history.save();
				}

				MessageQueue.getInstance().sendMessage(
					new ResultSetMessage(
						(CResultSet[]) resultsetVector.toArray(
							new CResultSet[0])));
			}
		}
		.start();
	}

	public static void run(final Query[] query) {
		new Thread() {
			public void run() {
				Vector resultsetVector = new Vector();
				for (int i = 0; i < query.length; i++) {
					CResultSet rs = QueryExecutor.getData(query[i]);
					resultsetVector.add(rs);
					if (query[i].getFilename() != null) {
						save(rs);
					}

				}

				if (query[0].getFilename() != null) {
					QueryHistory history = new QueryHistory(query);
					history.save();
				}

				MessageQueue.getInstance().sendMessage(
					new ResultSetMessage(
						(CResultSet[]) resultsetVector.toArray(
							new CResultSet[0])));
			}
		}
		.start();
	}
}
