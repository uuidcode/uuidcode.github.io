package query;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;

public class Test {
	public static void main(String[] args) {
		JFrame f = new JFrame();
		JPanel panel = new JPanel(new BorderLayout());
		JPanel controlPanel = new JPanel(new FlowLayout());
		JButton button1 = new JButton("open");
		controlPanel.add(button1);
		final JDesktopPane desktop = new JDesktopPane();
		desktop.addContainerListener(new ContainerListener() {

			public void componentAdded(ContainerEvent e) {
				System.out.println(">>> Add");
				System.out.println(e.getChild());
				
			}

			public void componentRemoved(ContainerEvent e) {
				System.out.println(">>> Remove");
				System.out.println(e.getChild());
				
			}
		});
		panel.add(controlPanel, BorderLayout.NORTH);
		panel.add(desktop, BorderLayout.CENTER);
		button1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				JInternalFrame internalFrame =
					new JInternalFrame("test", true, true, true, false);
				desktop.add(internalFrame);
				internalFrame.setSize(200, 200);
				internalFrame.setVisible(true);			
			}
		});
		
		f.setContentPane(panel);
		f.addWindowListener(new WindowListener() {

			public void windowActivated(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}

			public void windowClosed(WindowEvent e) {
				System.exit(1);
				
			}

			public void windowClosing(WindowEvent e) {
				System.exit(1);
				
			}

			public void windowDeactivated(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}

			public void windowDeiconified(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}

			public void windowIconified(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}

			public void windowOpened(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		f.setSize(400, 400);
		f.setVisible(true);
	}
}
