package query;

import java.io.File;

import javax.swing.JInternalFrame;

public class QueryInteralFrame extends JInternalFrame {
	private String filename;

	public QueryInteralFrame(String filename) {
		super("", true, true, true, false);
		this.filename = filename;
		this.title = filename;
		int index = title.lastIndexOf(File.separator);
		if (index > 0) {
			title = title.substring(index + 1);
		}
		this.setTitle(title);
	}	
}
