package query;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.Enumeration;
import java.util.TreeSet;

import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

import message.HistoryFileMessage;
import message.Message;
import message.MessageListener;
import message.MessageQueue;
import message.ResultSetMessage;

public class ResultHistoryPanel extends JPanel implements MessageListener {
	public static final String METADATA_DIR = ".metadata";
	private JTree tree;
	private DefaultTreeModel model;
	private DefaultMutableTreeNode root;
	private JPopupMenu popupMenu;

	public ResultHistoryPanel() {
		MessageQueue.getInstance().addListener(this);
		UIManager.put(
			"Tree.collapsedIcon",
			new ImageIcon("resource/image/tree_folder_collapsed.gif"));
		UIManager.put(
			"Tree.expandedIcon",
			new ImageIcon("resource/image/tree_folder_expanded.gif"));
		this.setLayout(new BorderLayout());
		this.root =
			new DefaultMutableTreeNode(
				new FileUserObject(new File(METADATA_DIR)));
		this.initTreeNode(root, new File(METADATA_DIR));
		this.model = new DefaultTreeModel(this.root);
		this.tree = new JTree(this.model);
		DefaultTreeCellRenderer renderer =
			(DefaultTreeCellRenderer) this.tree.getCellRenderer();
		renderer.setOpenIcon(new ImageIcon("resource/image/history_dir.gif"));
		renderer.setClosedIcon(new ImageIcon("resource/image/history_dir.gif"));
		renderer.setLeafIcon(new ImageIcon("resource/image/history.gif"));
		this.add(new JScrollPane(this.tree), BorderLayout.CENTER);
		this.tree.setRootVisible(false);
		this.expandAll(true);
		this.setupPopupMenu();
	}

	public DefaultMutableTreeNode getSelectedNode() {
		TreePath path = tree.getSelectionPath();
		if (path == null) {
			return null;
		}

		Object object = path.getLastPathComponent();

		if (object != null && object instanceof DefaultMutableTreeNode) {
			return (DefaultMutableTreeNode) object;
		}

		return null;
	}

	private void setupPopupMenu() {
		this.popupMenu = new JPopupMenu();
		JMenuItem executeMenuItem = new JMenuItem("execute");
		executeMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				DefaultMutableTreeNode node = getSelectedNode();
				Object object = node.getUserObject();
				if (object != null && object instanceof FileUserObject) {
					FileUserObject fileUserObject = (FileUserObject) object;
					CResultSet rs = fileUserObject.getRs();
					if (rs != null) {
						MessageQueue.getInstance().sendMessage(
							new ResultSetMessage(new CResultSet[] { rs }));
					}
				}
			}
		});
		popupMenu.add(executeMenuItem);

		this.tree.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent me) {
				showPopup(me);
			}

			public void mouseReleased(MouseEvent me) {
				showPopup(me);
			}

			public void showPopup(MouseEvent me) {
				if (me.isPopupTrigger()) {
					popupMenu.show(me.getComponent(), me.getX(), me.getY());
				}
			}
		});
	}

	public void resetTreeNode(DefaultMutableTreeNode parent, File f) {
		File[] list = this.getSortedFiles(f);
		for (int i = 0; i < list.length; i++) {
			if (list[i].isFile()) {
				parent.add(
					new DefaultMutableTreeNode(new FileUserObject(list[i])));
			} else if (list[i].isDirectory()) {
				this.initTreeNode(parent, list[i]);
			}
		}
	}

	public void expandAll(boolean expand) {
		expandAll(new TreePath(this.root), expand);
	}

	private void expandAll(TreePath parent, boolean expand) {
		TreeNode node = (TreeNode) parent.getLastPathComponent();
		if (node.getChildCount() >= 0) {
			for (Enumeration e = node.children(); e.hasMoreElements();) {
				TreeNode n = (TreeNode) e.nextElement();
				TreePath path = parent.pathByAddingChild(n);
				expandAll(path, expand);
			}
		}

		if (expand) {
			this.tree.expandPath(parent);
		} else {
			this.tree.collapsePath(parent);
		}
	}

	private void addEmptyNode(DefaultMutableTreeNode node) {
		node.add(new DefaultMutableTreeNode("[There is no contents]"));
	}

	private void initTreeNode(DefaultMutableTreeNode parent, File f) {
		if (f == null) {
			return;
		}

		if (!f.exists()) {
			f.mkdir();
		}

		File[] list = this.getSortedFiles(f);
		if (list == null) {
			return;
		}
		for (int i = 0; i < list.length; i++) {
			if (list[i].isFile()) {
				parent.add(
					new DefaultMutableTreeNode(new FileUserObject(list[i])));
			} else if (list[i].isDirectory()) {
				DefaultMutableTreeNode dirNode =
					new DefaultMutableTreeNode(new FileUserObject(list[i]));
				parent.add(dirNode);
				this.initTreeNode(dirNode, list[i]);
				if (dirNode.getChildCount() == 0) {
					this.addEmptyNode(dirNode);
				}
			}
		}
	}

	private void reverse(File[] b) {
		int left = 0; // index of leftmost element
		int right = b.length - 1; // index of rightmost element

		while (left < right) {
			// exchange the left and right elements
			File temp = b[left];
			b[left] = b[right];
			b[right] = temp;

			// move the bounds toward the center
			left++;
			right--;
		}
	}

	private File[] getSortedFiles(File f) {
		if (f == null) {
			return null;
		}

		File[] list = f.listFiles();
		if (list == null) {
			return null;
		}
		TreeSet set = new TreeSet();
		for (int i = 0; i < list.length; i++) {
			set.add(list[i]);
		}

		list = (File[]) set.toArray(new File[0]);
		reverse(list);
		return list;
	}

	public DefaultMutableTreeNode getMatchNode(
		DefaultMutableTreeNode node,
		File file) {
		Object object = node.getUserObject();
		if (object == null) {
			return null;
		}

		if (object instanceof FileUserObject) {
			FileUserObject fileUserObject = (FileUserObject) object;
			File f = fileUserObject.getFile();
			try {
				if (f.getCanonicalPath().equals(file.getCanonicalPath())) {
					return node;
				}
			} catch (Exception ex) {
			}

			for (int i = 0; i < node.getChildCount(); i++) {
				DefaultMutableTreeNode currentNode =
					(DefaultMutableTreeNode) node.getChildAt(i);
				DefaultMutableTreeNode matchNode =
					getMatchNode(currentNode, file);
				if (matchNode == null) {
					continue;
				} else {
					return matchNode;
				}
			}
		}

		return null;
	}

	public void listen(Message message) {
		if (message == null) {
			return;
		}

		if (message instanceof HistoryFileMessage) {
			HistoryFileMessage fileMessage = (HistoryFileMessage) message;
			String filename = fileMessage.getFilename();
			File f = new File(filename);
			f = f.getParentFile();
			DefaultMutableTreeNode node = this.getMatchNode(this.root, f);
			if (node != null) {
				node.removeAllChildren();
				this.resetTreeNode(node, f);
				this.model.reload(node);
			} else {
				this.root.removeAllChildren();
				this.initTreeNode(this.root, new File(METADATA_DIR));
				this.model.reload(this.root);
				this.expandAll(true);

				node = this.getMatchNode(this.root, f);
				if (node != null) {
					node.removeAllChildren();
					this.resetTreeNode(node, f);
					this.model.reload(node);
				}
			}
		}
	}
}