package query;
import Config;
import Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import message.ConsoleMessage;
import message.MessageQueue;

public class QueryExecutor {
	private static final String CONFIG = "config.xml";
	private static Hashtable connections = new Hashtable();
	private static PreparedStatement ps;

	static {
		try {
			Database[] databases = Config.getDatabase();
			for (int i = 0; i < databases.length; i++) {
				Class.forName(databases[i].getDriver()).newInstance();
				MessageQueue.getInstance().sendMessage(
					new ConsoleMessage(databases[i].getDriver() + " loaded."));
				Connection con =
					DriverManager.getConnection(
						databases[i].getUrl(),
						databases[i].getUser(),
						databases[i].getPassword());
				connections.put(databases[i].getName(), con);
			}
		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
		}
	}

	private static Connection reconnection(String databaseName) {
		try {
			Database[] databases = Config.getDatabase();
			for (int i = 0; i < databases.length; i++) {
				if (databases[i].getName().equals(databaseName)) {
					Connection currentConnection =
						(Connection) connections.get(databases[i].getName());
					currentConnection.close();
					currentConnection = null;
					Connection newConnection =
						DriverManager.getConnection(
							databases[i].getUrl(),
							databases[i].getUser(),
							databases[i].getPassword());
					connections.put(databases[i].getName(), newConnection);
					return newConnection;
				}
			}
		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
		}
		return null;
	}

	public static Connection getConnection(String database) {
		Connection con = null;
		try {
			con = (Connection) connections.get(database);
		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
			con = reconnection(database);
			if (con != null) {
				MessageQueue.getInstance().sendMessage(
					new ConsoleMessage("reconnectd " + database));
			} else {
				MessageQueue.getInstance().sendMessage(
					new ConsoleMessage("reconnectd Connection is null"));
			}
		}
		return con;
	}

	private static StringBuffer getMappingQuery(
		StringBuffer query,
		String parameter) {
		int index = query.indexOf("?");
		query.replace(index, index + 1, "'" + parameter + "'");
		return query;
	}

	public static CResultSet getData(Query query) {
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		long start = System.currentTimeMillis();

		try {
			con = (Connection) connections.get(query.getDatabase());

		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
			con = reconnection(query.getDatabase());
			if (con != null) {
				MessageQueue.getInstance().sendMessage(
					new ConsoleMessage("reconnectd " + query.getDatabase()));
			} else {
				MessageQueue.getInstance().sendMessage(
					new ConsoleMessage("reconnectd Connection is null"));
			}
		}

		StringBuffer queryString = new StringBuffer(query.getQueryString());
		String[] parameter = query.getParameter();
		if (parameter != null) {
			for (int i = 0; i < parameter.length; i++) {
				queryString = getMappingQuery(queryString, parameter[i]);
			}
		}

		try {
			preparedStatement = con.prepareStatement(queryString.toString());
		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
		}

		try {
			if (preparedStatement != null) {
				ps = preparedStatement;
				rs = preparedStatement.executeQuery();
				if (rs != null) {
					CResultSet resultSet = CResultSet.instantiate(rs);
					SimpleDateFormat format =
						new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					query.setExecuteDate(format.format(new Date()));
					resultSet.setQuery(query);
					return resultSet;
				}
			}
		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception e) {
			}

			try {
				if (preparedStatement != null) {
					preparedStatement.close();
				}
			} catch (Exception e) {
			}

			ps = null;
			MessageQueue.getInstance().sendMessage(
				new ConsoleMessage(
					query.getDatabase()
						+ ":"
						+ query.getComment()
						+ ":"
						+ (System.currentTimeMillis() - start)
						+ "ms"));
		}
		return null;
	}

	public static void close() {
		Enumeration key = connections.keys();
		while (key.hasMoreElements()) {
			Connection con = (Connection) connections.get(key.nextElement());
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
				}
			}
		}
	}

	public static void cancel() {
		new Thread() {
			public void run() {
				if (ps != null) {
					try {
						ps.cancel();
						ps.close();
						ps = null;
					} catch (Exception e) {
					}
				}

			}
		}
		.start();
	}

	public static int execute(
		String databaseName,
		String query,
		Vector parameter) {
		Connection con = null;
		PreparedStatement preparedStatement = null;
		long start = System.currentTimeMillis();

		try {
			con = (Connection) connections.get(databaseName);
			preparedStatement = con.prepareStatement(query);
		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
			con = reconnection(databaseName);
			if (con != null) {
				MessageQueue.getInstance().sendMessage(
					new ConsoleMessage("reconnectd " + databaseName));
			} else {
				MessageQueue.getInstance().sendMessage(
					new ConsoleMessage("reconnectd Connection is null"));
			}
		}

		try {
			con.setAutoCommit(false);
			if (preparedStatement != null) {
				if (parameter != null) {
					for (int i = 0; i < parameter.size(); i++) {
						preparedStatement.setString(
							i + 1,
							parameter.get(i).toString());
					}
				}
				int rowCount = preparedStatement.executeUpdate();
				con.commit();
				return rowCount;
			}
		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
		} finally {
			try {
				if (preparedStatement != null) {
					preparedStatement.close();
				}
			} catch (Exception e) {
				MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
			}

			try {
				con.setAutoCommit(true);
			} catch (Exception e) {
				MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
			}
			MessageQueue.getInstance().sendMessage(
				new ConsoleMessage(
					databaseName
						+ ":"
						+ (System.currentTimeMillis() - start)
						+ "ms"));
		}
		return -1;
	}
}