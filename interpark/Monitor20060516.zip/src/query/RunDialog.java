package query;

import UIUtilities;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;

public class RunDialog extends JDialog {
	private ParameterTableModel model;
	private JTable table;

	public RunDialog(
		Container owner,
		String title,
		boolean modal,
		final Query[] query) {
		super(UIUtilities.getFrame(owner), title, modal);
		if (query[0].getParameter().length == 0) {
			Run.run(query, new String[0]);
			dispose();
			return;
		}

		JPanel panel = new JPanel(new BorderLayout());
		this.model = new ParameterTableModel();
		this.table = new JTable(this.model);

		int parameterCount = query[0].getParameter().length;
		String[] parameterName = query[0].getParameter();
		for (int i = 0; i < parameterCount; i++) {
			model.addParameter(parameterName[i]);
		}

		panel.add(new JScrollPane(this.table), BorderLayout.CENTER);
		JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JButton runButton = new JButton("run");
		runButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RunDialog.this.setVisible(false);
				String[] parameter = model.getParameter();
				if (parameter.length > 0) {
					if (table.isEditing()) {
						int editingRow = table.getEditingRow();
						int editingColumn = table.getEditingColumn();
						JTextField textField =
							(JTextField) table.getEditorComponent();
						String editedValue = textField.getText();
						table.editingStopped(new ChangeEvent(table));
						model.setValueAt(
							editedValue,
							editingRow,
							editingColumn);
						model.fireTableDataChanged();
					}
				}

				parameter = model.getParameter();
				for (int i = 0; i < parameter.length; i++) {
					if (parameter[i] == null
						|| parameter[i].trim().length() == 0) {
						JOptionPane.showMessageDialog(
							RunDialog.this,
							"Input parameter",
							"Error",
							JOptionPane.ERROR_MESSAGE);
						return;
					} else {
						parameter[i] = parameter[i].trim();
					}
				}

				Run.run(query, parameter);
				RunDialog.this.dispose();
			}
		});
		bottomPanel.add(runButton);
		JButton closeButton = new JButton("close");
		closeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RunDialog.this.dispose();
			}
		});
		bottomPanel.add(closeButton);
		panel.add(bottomPanel, BorderLayout.SOUTH);
		this.setContentPane(panel);
		this.setSize(400, 300);
	}	
}