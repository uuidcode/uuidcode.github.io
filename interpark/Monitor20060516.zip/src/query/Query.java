package query;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.List;

import message.ConsoleMessage;
import message.MessageQueue;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class Query implements Serializable, Comparable{
	private boolean chartable;
	private boolean reportable;
	private String database;
	private String type;
	private String date;
	private String count;
	private String[] groupBy;
	private String comment;
	private String queryString;
	private String[] parameter;
	private String filename;
	private String executeDate;
	
	public static Query[] getQuery(String filename) {
		try {
			SAXReader reader = new SAXReader();
			Document document = reader.read(filename);
			List list = document.selectNodes("/query/parameter");
			String[] parameter = new String[list.size()];
			for (int i = 0; i < list.size(); i++) {
				parameter[i] = ((Element) list.get(i)).getText();
			}
			list = document.selectNodes("/query/sql");
			Query[] query = new Query[list.size()];
			for (int i = 0; i < list.size(); i++) {
				query[i] = new Query(filename, (Element) list.get(i));
				query[i].setParameter(parameter);
			}
			return query;
		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
		}
		return null;
	}
	
	public static Query[] getQueryByXML(String xml) {
		try {
			SAXReader reader = new SAXReader();
			Document document = DocumentHelper.parseText(xml);
			List list = document.selectNodes("/query/parameter");
			String[] parameter = new String[list.size()];
			for (int i = 0; i < list.size(); i++) {
				parameter[i] = ((Element) list.get(i)).getText();
			}
			list = document.selectNodes("/query/sql");
			Query[] query = new Query[list.size()];
			for (int i = 0; i < list.size(); i++) {
				query[i] = new Query(null, (Element) list.get(i));
				query[i].setParameter(parameter);
			}
			return query;
		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
		}
		return null;
	}

	public Query(
		boolean reportable,
		boolean chartable,
		String type,
		String date,
		String count,
		String[] groupBy,
		String comment) {
		this.reportable = reportable;
		this.chartable = chartable;
		this.type = type;
		this.date = date;
		this.count = count;
		this.groupBy = groupBy;
		this.comment = comment;
	}

	public Query(String filename, Element element) {
		this.filename = filename;
		this.chartable = "true".equals(element.valueOf("chartable"));
		this.reportable = "true".equals(element.valueOf("reportable"));
		this.database = element.valueOf("database");
		this.type = element.valueOf("type");
		this.date = element.valueOf("date");
		this.count = element.valueOf("count");
		List list = element.selectNodes("groupBy");
		this.groupBy = new String[list.size()];
		for (int i = 0; i < list.size(); i++) {
			this.groupBy[i] = ((Element) list.get(i)).getText();
		}
		this.comment = element.valueOf("comment");
		this.queryString = element.valueOf("queryString");
		this.queryString = queryString.replaceAll("&lt;", "<");
		this.queryString = queryString.replaceAll("&gt;", ">");
		list = element.selectNodes("parameter");
		this.parameter = new String[list.size()];
		for (int i = 0; i < list.size(); i++) {
			this.parameter[i] = ((Element) list.get(i)).getText();
		}
	}

	public Query copy() throws Exception {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(baos);
		oos.writeObject(this);
		oos.close();
		
		ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
		ObjectInputStream ois = new ObjectInputStream(bais);
		Object object = ois.readObject();
		ois.close();
		
		return (Query) object;
	}
	
	public boolean isChartable() {
		return chartable;
	}

	public String getComment() {
		return comment;
	}

	public String getCount() {
		return count;
	}

	public String getDate() {
		return date;
	}

	public String getType() {
		return type;
	}

	public String[] getGroupBy() {
		return groupBy;
	}

	public String getQueryString() {
		return queryString;
	}

	public String[] getParameter() {
		return parameter;
	}

	public boolean isReportable() {
		return reportable;
	}

	public String getDatabase() {
		return database;
	}

	public void setParameter(String[] strings) {
		parameter = strings;
	}
	
	public void setComment(String string) {
		comment = string;
	}
	
	public String getFilename() {
		return this.filename;
	}

	public int compareTo(Object o) {
		if (o instanceof Query) {
			Query query = (Query) o;
			return this.filename.compareTo(query.getFilename());
		}
		return 0;
	}
	
	public boolean equals(Object object) {
		boolean isOK = false;
		if (object instanceof Query) {
			Query query = (Query) object;
			if (this.getFilename().equals(query.getFilename())) {
				if (this.parameter.length == query.getParameter().length) {
					if (this.parameter.length == 0) {
						isOK = true;
					}
					
					for (int i = 0; i < this.parameter.length; i++) {
						if (this.parameter[i].equals(query.getParameter()[i])) {
							isOK = true;
						} else {
							isOK = false;
							break;
						}
					}
				} else {
					isOK = false;
				}
			} else {
				isOK = false;
			}
		} else {
			isOK = false;
		}
		return isOK;
	}

	public String getExecuteDate() {
		return executeDate;
	}

	public void setExecuteDate(String string) {
		executeDate = string;
	}

	public void setFilename(String string) {
		filename = string;
	}

	public void setQueryString(String string) {
		queryString = string;
	}

}
