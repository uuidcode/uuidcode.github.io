package query;

import javax.swing.JPanel;

public class QueryInfoPanel extends JPanel {

}
