package query;
import java.awt.BorderLayout;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import javax.swing.JPanel;

import message.*;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.data.time.Day;
import org.jfree.data.time.Hour;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.TimeSeriesDataItem;

public class ResultSetChartPanel extends JPanel {
	private CResultSet[] rs;

	public ResultSetChartPanel(CResultSet rs) {
		this.rs = new CResultSet[1];
		this.rs[0] = rs;
		this.setupUI();
	}
	
	public ResultSetChartPanel(CResultSet[] rs) {
		this.rs = rs;
		this.setupUI();
	}

	public void setupUI() {
		this.setLayout(new BorderLayout());
		String title = null;
		String xAxis = null;
		String yAxis = null;
		TimeSeriesCollection XYdata = new TimeSeriesCollection();
		
		Vector totalResultSet = new Vector();
		String[] columnName = null;
		Query query = null;
		try {
			for (int i = 0; i < rs.length; i++) {
				if (rs[i] != null) {
					columnName = rs[i].getColumnName();
					query = rs[i].getQuery();
					String[] groupBy = rs[i].getQuery().getGroupBy();
					if (groupBy != null && groupBy.length > 0) {
						Hashtable classifiedData = new Hashtable();
						for (int j = 1; j <= rs[i].getRowCount(); j++) {
							rs[i].absolute(j);
							String key = "";
							for (int k = 0; k < groupBy.length; k++) {
								if (k != (groupBy.length - 1)) {
									key += rs[i].getString(groupBy[k]) + "_";
								} else {
									key += rs[i].getString(groupBy[k]);
								}
							}
							
							if (!classifiedData.containsKey(key)) {
								Vector newRows = new Vector();
								classifiedData.put(key, newRows);
								newRows.add(rs[i].getData().get(j - 1));
							} else {
								((Vector)classifiedData.get(key)).add(rs[i].getData().get(j - 1));
							}
						}
						
						Enumeration keys = classifiedData.keys();
						while (keys.hasMoreElements()) {
							String key = keys.nextElement().toString();
							Vector rows = (Vector) classifiedData.get(key);
							CResultSet newRS = new CResultSet(columnName, rows);
							Query newQuery = query.copy();
							newQuery.setComment(query.getComment() + ":" + key);
							newRS.setQuery(newQuery);
							totalResultSet.add(newRS);
						}
					} else {
						totalResultSet.add(rs[i]);
					}
				}
			}
			
			rs = (CResultSet[]) totalResultSet.toArray(new CResultSet[0]);
			for (int i = 0; i < rs.length; i++) {
				TimeSeries series = null;
				while (rs[i] != null && rs[i].next()) {
					String date = rs[i].getString(rs[i].getQuery().getDate());
					if ("day".equals(rs[i].getQuery().getType())) {
						if (series == null) {
							series = new TimeSeries(rs[i].getQuery().getComment(), Day.class);
						}
						
						Day day = new Day(Integer.parseInt(date.substring(6, 8), 10), 
						Integer.parseInt(date.substring(4, 6), 10), 
						Integer.parseInt(date.substring(0, 4), 10));
						TimeSeriesDataItem data = series.getDataItem(day);
						int value = Integer.parseInt(rs[i].getString(rs[i].getQuery().getCount()), 10);
						if (data == null) {
							series.add(day, new Integer(value));
						} else {
							series.update(day, new Integer(data.getValue().intValue() + value));
						}
					} else if ("hour".equals(rs[i].getQuery().getType())) {
						if (series == null) {
							series = new TimeSeries(rs[i].getQuery().getComment(), Hour.class);
						}
						Hour hour = new Hour(Integer.parseInt(date.substring(8, 10), 10),
						Integer.parseInt(date.substring(6, 8), 10), 
						Integer.parseInt(date.substring(4, 6), 10), 
						Integer.parseInt(date.substring(0, 4), 10));
						TimeSeriesDataItem data = series.getDataItem(hour);
						int value = Integer.parseInt(rs[i].getString(rs[i].getQuery().getCount()), 10);
						if (data == null) {
							series.add(hour, new Integer(value));
						} else {
							series.update(hour, new Integer(data.getValue().intValue() + value));
						}
					}
				}
				
				if (series != null) {
					XYdata.addSeries(series);
					title = "";
					xAxis = "date";
					yAxis = "count";
				}
			}
		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
		}
		JFreeChart chart =
			ChartFactory.createTimeSeriesChart(
				title,
				xAxis,
				yAxis,
				XYdata,
				true,
				true,
				true);
		
		DateAxis dateAxis = new DateAxis("date") {
			public DateFormat getDateFormatOverride() {
				return new SimpleDateFormat("MM/dd:hh"); 
			}
		};
		chart.getXYPlot().setDomainAxis(dateAxis);
		
		ChartPanel chartPanel = new ChartPanel(chart);
		this.add(chartPanel, BorderLayout.CENTER);
	}

}
