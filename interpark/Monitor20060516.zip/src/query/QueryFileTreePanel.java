package query;

import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.Vector;

import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.KeyStroke;
import javax.swing.filechooser.FileFilter;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

import message.FileMessage;
import message.Message;
import message.MessageListener;
import message.MessageQueue;
import message.OpenFileMessage;
import message.ResultSetMessage;
import action.CollapseAllAction;
import action.DeleteFileAction;
import action.ExpandAllAction;
import action.NewDirAction;
import action.NewFileAction;
import action.OpenFileAction;
import action.ReportAction;
import action.RunFileAction;

public class QueryFileTreePanel
	extends JPanel
	implements MessageListener { //, Reportable {
	public static final String SQL_DIR = "sql";
	public static final String SQL_EXT = ".sql";
	private DefaultTreeModel model;
	private DefaultMutableTreeNode root;
	private DragAndDropSupportableFileTree tree;
	private JPopupMenu popupMenu;
	private RunFileAction runAction;
	private OpenFileAction openFileAction;
	private NewFileAction newFileAction;
	private NewDirAction newDirAction;
	private DeleteFileAction deleteFileAction;
	private ExpandAllAction expandAllAction;
	private CollapseAllAction collapseAllAction;

	public QueryFileTreePanel() {
		this.setupUI();
		this.setupAction();
		this.setupKeyStroke();
		this.setupPopupMenu();
	}

	private File getQueryFile(TreePath path) {
		DefaultMutableTreeNode node =
			(DefaultMutableTreeNode) path.getLastPathComponent();
		if (node == null) {
			return null;
		}

		Object object = node.getUserObject();
		if (object == null) {
			return null;
		}

		if (!(object instanceof QueryFile)) {
			return null;
		}

		QueryFile queryFile = (QueryFile) object;
		return queryFile.getFile();
	}

	private void setupUI() {
		javax.swing.UIManager.put(
			"Tree.collapsedIcon",
			new ImageIcon("resource/image/tree_folder_collapsed.gif"));
		javax.swing.UIManager.put(
			"Tree.expandedIcon",
			new ImageIcon("resource/image/tree_folder_expanded.gif"));
		MessageQueue.getInstance().addListener(this);
		this.tree =
			new DragAndDropSupportableFileTree(
				new File("sql"),
				new FileFilter[] { new QueryFileFilter()});
		this.model = (DefaultTreeModel) this.tree.getModel();
		this.root = (DefaultMutableTreeNode) this.model.getRoot();
		this.setLayout(new BorderLayout());
		this.add(new JScrollPane(this.tree), BorderLayout.CENTER);
	}

	private void setupPopupMenu() {
		this.popupMenu = new JPopupMenu();
		this.popupMenu.add(this.runAction);
		this.popupMenu.add(this.openFileAction);
		this.popupMenu.add(this.newFileAction);
		this.popupMenu.add(this.newDirAction);
		this.popupMenu.add(this.deleteFileAction);

		this.tree.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent me) {
				showPopup(me);
			}

			public void mouseReleased(MouseEvent me) {
				showPopup(me);
			}

			public void showPopup(MouseEvent me) {
				if (me.isPopupTrigger()) {
					popupMenu.show(me.getComponent(), me.getX(), me.getY());
					runAction.setEnabled(false);
					openFileAction.setEnabled(false);
					newFileAction.setEnabled(true);
					newDirAction.setEnabled(false);
					deleteFileAction.setEnabled(false);

					DefaultMutableTreeNode node = getSelectedNode();

					if (node == null) {
						return;
					}

					if (node != null) {
						Object userObject = node.getUserObject();
						if (userObject != null
							&& userObject instanceof QueryFile) {
							QueryFile queryFile = (QueryFile) userObject;
							File file = queryFile.getFile();
							if (file != null && file.isFile()) {
								runAction.setEnabled(true);
								openFileAction.setEnabled(true);
								deleteFileAction.setEnabled(true);
							}

							if (file != null && file.isDirectory()) {
								newDirAction.setEnabled(true);
								deleteFileAction.setEnabled(true);
							}
						}
					}
				}
			}
		});
	}

	private void setupAction() {
		this.runAction = RunFileAction.getInstance();
		this.openFileAction = OpenFileAction.getInstance();
		this.newFileAction = NewFileAction.getInstance();
		this.newDirAction = NewDirAction.getInstance();
		this.deleteFileAction = DeleteFileAction.getInstance();
		this.expandAllAction = ExpandAllAction.getInstance();
		this.collapseAllAction = CollapseAllAction.getInstance();
	}

	private void setupKeyStroke() {
		KeyStroke keyStroke =
			(KeyStroke) this.runAction.getValue(Action.ACCELERATOR_KEY);
		this.tree.registerKeyboardAction(
			this.runAction,
			keyStroke,
			WHEN_FOCUSED);

		keyStroke =
			(KeyStroke) this.openFileAction.getValue(Action.ACCELERATOR_KEY);
		this.tree.registerKeyboardAction(
			this.openFileAction,
			keyStroke,
			WHEN_FOCUSED);

		keyStroke =
			(KeyStroke) this.newFileAction.getValue(Action.ACCELERATOR_KEY);
		this.tree.registerKeyboardAction(
			this.newFileAction,
			keyStroke,
			WHEN_FOCUSED);

		keyStroke =
			(KeyStroke) this.newDirAction.getValue(Action.ACCELERATOR_KEY);
		this.tree.registerKeyboardAction(
			this.newDirAction,
			keyStroke,
			WHEN_FOCUSED);

		keyStroke =
			(KeyStroke) this.deleteFileAction.getValue(Action.ACCELERATOR_KEY);
		this.tree.registerKeyboardAction(
			this.deleteFileAction,
			keyStroke,
			WHEN_FOCUSED);
	}

	public DefaultMutableTreeNode getSelectedNode() {
		TreePath path = tree.getSelectionPath();
		if (path == null) {
			return null;
		}

		Object object = path.getLastPathComponent();

		if (object != null && object instanceof DefaultMutableTreeNode) {
			return (DefaultMutableTreeNode) object;
		}

		return null;
	}

	public void listen(Message message) {
		if (message == null) {
			return;
		}

		// ���������
		if (message instanceof FileMessage) {
			FileMessage fileMessage = (FileMessage) message;
			File file = new File(fileMessage.getFilename());
			file = file.getParentFile();
			DefaultMutableTreeNode node =
				this.tree.getMatchNode(this.root, file);
			if (node != null) {
				node.removeAllChildren();
				this.tree.resetTreeNode(node, file);
				this.tree.reload(node);
				this.tree.expandAll(true);
			}
		} else if (message instanceof OpenFileAction) {
			DefaultMutableTreeNode node = this.getSelectedNode();
			if (node == null) {
				return;
			}
			QueryFile queryFile = (QueryFile) node.getUserObject();
			MessageQueue.getInstance().sendMessage(
				new OpenFileMessage(queryFile.getFile()));
		} else if (message instanceof RunFileAction) {
			new Thread() {
				public void run() {
					DefaultMutableTreeNode node = getSelectedNode();

					if (node == null) {
						return;
					}

					if (node != null) {
						Object userObject = node.getUserObject();
						if (userObject != null
							&& userObject instanceof QueryFile) {
							QueryFile queryFile = (QueryFile) userObject;
							File file = queryFile.getFile();
							if (file != null && file.isFile()) {
								Query[] query =
									Query.getQuery(file.getAbsolutePath());

								if (query == null) {
									return;
								}

								RunDialog runDialog =
									new RunDialog(
										QueryFileTreePanel.this,
										"Run",
										true,
										query);

								if (query[0] != null
									&& query[0].getParameter() != null
									&& query[0].getParameter().length != 0) {
									runDialog.show();
								}
							}
						}
					}
				}
			}
			.start();
		} else if (message instanceof DeleteFileAction) {

			DefaultMutableTreeNode node = getSelectedNode();
			if (node == null) {
				return;
			}

			Object object = node.getUserObject();
			if (object == null || !(object instanceof QueryFile)) {
				return;
			}
			QueryFile queryFile = (QueryFile) object;
			File file = queryFile.getFile();
			if (file != null && file.exists()) {
				if (JOptionPane
					.showConfirmDialog(
						QueryFileTreePanel.this,
						"Delete selected file?")
					== JOptionPane.YES_OPTION) {
					file.delete();
					node = (DefaultMutableTreeNode) node.getParent();
					node.removeAllChildren();
					this.tree.resetTreeNode(node, file.getParentFile());
					this.tree.reload(node);
					this.tree.expandAll(true);
				}
			}
		} else if (message instanceof NewDirAction) {
			DefaultMutableTreeNode node = getSelectedNode();
			if (node == null) {
				return;
			}
			QueryFile queryFile = (QueryFile) node.getUserObject();
			File file = queryFile.getFile();
			if (file.isFile()) {
				return;
			}
			NewDirDialog dialog =
				new NewDirDialog(this, "Make Directory", true, file);
			dialog.show();
		} else if (message instanceof ReportAction) {
			new Thread() {
				public void run() {
					File f = new File(SQL_DIR);
					Vector sqlFiles = new Vector();
					getSQLFile(sqlFiles, f);
					for (int i = 0; i < sqlFiles.size(); i++) {
						File file = (File) sqlFiles.get(i);
						Query[] currentQuerys =
							Query.getQuery(file.getAbsolutePath());
						Vector resultVector = new Vector();
						for (int j = 0; j < currentQuerys.length; j++) {
							if (currentQuerys[j].getParameter().length == 0
								&& currentQuerys[j].isReportable()) {
								resultVector.add(
									QueryExecutor.getData(currentQuerys[j]));

							}
						}
						MessageQueue.getInstance().sendMessage(
							new ResultSetMessage(
								(CResultSet[]) resultVector.toArray(
									new CResultSet[0])));
					}
				}
			}
			.start();
		}
	}

	private void getSQLFile(Vector sqlFiles, File f) {
		if (f.isDirectory()) {
			File[] list = f.listFiles();
			for (int i = 0; i < list.length; i++) {
				getSQLFile(sqlFiles, list[i]);
			}
		} else {
			if (f.getName().endsWith(".sql")) {
				sqlFiles.add(f);
			}
		}
	}
}
