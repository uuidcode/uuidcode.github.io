package query;

import java.awt.Point;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragGestureRecognizer;
import java.awt.dnd.DragSource;
import java.awt.dnd.DragSourceDragEvent;
import java.awt.dnd.DragSourceDropEvent;
import java.awt.dnd.DragSourceEvent;
import java.awt.dnd.DragSourceListener;
import java.awt.dnd.DragSourceMotionListener;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.io.File;
import java.util.Enumeration;
import java.util.TreeSet;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeExpansionListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeCellEditor;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import message.FileMessage;
import message.MessageQueue;

class DragAndDropSupportableFileTree
	extends JTree
	implements
		DragGestureListener,
		DragSourceListener,
		DragSourceMotionListener,
		DropTargetListener,
		TreeExpansionListener {
	private DefaultTreeModel model;
	private DefaultMutableTreeNode root;
	private File dir;
	private Vector filters = new Vector();

	public DragAndDropSupportableFileTree(File file, FileFilter[] filter) {
		this.dir = file;
		this.addFilter(filter);
		DragSource dragSource = DragSource.getDefaultDragSource();
		dragSource.addDragSourceListener(this);
		dragSource.addDragSourceMotionListener(this);
		DragGestureRecognizer recognizer =
			dragSource.createDefaultDragGestureRecognizer(
				this,
				DnDConstants.ACTION_COPY_OR_MOVE,
				this);
		DropTarget target =
			new DropTarget(this, DnDConstants.ACTION_COPY_OR_MOVE, this);
		this.setupModel();
		this.addTreeExpansionListener(this);
	}

	private void addFilter(FileFilter[] filter) {
		if (filter == null) {
			return;
		}

		for (int i = 0; i < filter.length; i++) {
			if (filter[i] != null) {
				this.filters.add(filter[i]);
			}
		}
	}

	private boolean accept(File file) {
		if (file.isDirectory()) {
			return true;
		}

		for (int i = 0; i < this.filters.size(); i++) {
			boolean isAccepted =
				((FileFilter) this.filters.get(i)).accept(file);
			if (isAccepted) {
				return true;
			}
		}

		return false;
	}

	private File[] getSortedFiles(File f) {
		File[] list = f.listFiles();
		TreeSet set = new TreeSet();
		for (int i = 0; i < list.length; i++) {
			set.add(list[i]);
		}

		list = (File[]) set.toArray(new File[0]);
		return list;
	}

	private void addEmptyNode(DefaultMutableTreeNode node) {
		node.add(new DefaultMutableTreeNode("[There is no contents]"));
	}

	private void initTreeNode(DefaultMutableTreeNode parent, File f) {
		File[] list = this.getSortedFiles(f);

		for (int i = 0; i < list.length; i++) {
			if (list[i].isFile() && this.accept(list[i])) {
				parent.add(new DefaultMutableTreeNode(new QueryFile(list[i])));
			} else if (list[i].isDirectory()) {
				DefaultMutableTreeNode dirNode =
					new DefaultMutableTreeNode(new QueryFile(list[i]));
				parent.add(dirNode);
				this.initTreeNode(dirNode, list[i]);
				if (dirNode.getChildCount() == 0) {
					this.addEmptyNode(dirNode);
				}
			}
		}
	}

	public String getFilename() {
		TreePath path = this.getSelectionPath();
		if (path == null) {
			return null;
		}
		DefaultMutableTreeNode node =
			(DefaultMutableTreeNode) path.getLastPathComponent();
		return ((QueryFile) node.getUserObject()).getFile().getAbsolutePath();
	}

	private File getQueryFile(TreePath path) {
		DefaultMutableTreeNode node =
			(DefaultMutableTreeNode) path.getLastPathComponent();
		if (node == null) {
			return null;
		}

		Object object = node.getUserObject();
		if (object == null) {
			return null;
		}

		if (!(object instanceof QueryFile)) {
			return null;
		}

		QueryFile queryFile = (QueryFile) object;
		return queryFile.getFile();
	}

	private void setupModel() {
		root = new DefaultMutableTreeNode(new QueryFile(this.dir));
		initTreeNode(root, this.dir);
		this.model = new DefaultTreeModel(root) {
			public void valueForPathChanged(TreePath path, Object newValue) {
				File file = getQueryFile(path);
				if (file == null) {
					return;
				}

				if (!file.exists()) {
					return;
				}

				File currentFile = file;
				file = file.getParentFile();
				if (!file.exists()) {
					return;
				}

				String ext = "";

				if (currentFile.isFile()) {
					String currentFileName = currentFile.getName();
					int index = currentFileName.lastIndexOf(".");
					if (index > 0) {
						ext = currentFileName.substring(index);
					}
				}

				File[] list = file.listFiles();
				for (int i = 0; i < list.length; i++) {
					if (list[i].getName().equals(newValue + ext)) {
						JOptionPane.showMessageDialog(
							DragAndDropSupportableFileTree.this,
							newValue + " exist",
							"Error",
							JOptionPane.ERROR_MESSAGE);
						return;
					}
				}

				File newFile = new File(file, newValue + ext);
				currentFile.renameTo(newFile);
				MessageQueue.getInstance().sendMessage(
					new FileMessage(newFile.getAbsolutePath()));
			}
		};
		this.setModel(this.model);
		DefaultTreeCellRenderer renderer =
			(DefaultTreeCellRenderer) this.getCellRenderer();
		TreeCellEditor editor = new LeafCellEditor(this, renderer);
		this.setCellEditor(editor);
		this.setEditable(true);
		renderer.setOpenIcon(new ImageIcon("resource/image/dir_open.gif"));
		renderer.setClosedIcon(new ImageIcon("resource/image/dir.gif"));
		renderer.setLeafIcon(new ImageIcon("resource/image/file.gif"));
		this.setRootVisible(false);
		this.expandAll(true);
		this.getSelectionModel().setSelectionMode(
			TreeSelectionModel.SINGLE_TREE_SELECTION);
	}

	public DefaultMutableTreeNode getTreeNode(TreePath path) {
		return (DefaultMutableTreeNode) (path.getLastPathComponent());
	}

	public void reload(DefaultMutableTreeNode node) {
		this.model.reload(node);
	}

	public void treeCollapsed(TreeExpansionEvent event) {
		DefaultMutableTreeNode node = getTreeNode(event.getPath());
		node.removeAllChildren();
		this.addEmptyNode(node);
		this.reload(node);
	}

	public void treeExpanded(TreeExpansionEvent event) {
		DefaultMutableTreeNode node = getTreeNode(event.getPath());
		node.removeAllChildren();
		this.resetTreeNode(node, ((QueryFile) node.getUserObject()).getFile());
		if (node.getChildCount() == 0) {
			this.addEmptyNode(node);
		}
		this.reload(node);
	}

	public void resetTreeNode(DefaultMutableTreeNode parent, File f) {
		File[] list = this.getSortedFiles(f);
		for (int i = 0; i < list.length; i++) {
			if (list[i].isFile() && this.accept(list[i])) {
				parent.add(new DefaultMutableTreeNode(new QueryFile(list[i])));
			} else if (list[i].isDirectory()) {
				this.initTreeNode(parent, list[i]);
			}
		}
	}

	public void expandAll(boolean expand) {
		expandAll(new TreePath(this.root), expand);
	}

	private void expandAll(TreePath parent, boolean expand) {
		TreeNode node = (TreeNode) parent.getLastPathComponent();
		if (node.getChildCount() >= 0) {
			for (Enumeration e = node.children(); e.hasMoreElements();) {
				TreeNode n = (TreeNode) e.nextElement();
				TreePath path = parent.pathByAddingChild(n);
				expandAll(path, expand);
			}
		}

		if (expand) {
			expandPath(parent);
		} else {
			collapsePath(parent);
		}
	}

	public DefaultMutableTreeNode getMatchNode(
		DefaultMutableTreeNode node,
		File file) {
		Object object = node.getUserObject();
		if (object == null || !(object instanceof QueryFile)) {
			return null;
		}

		QueryFile queryFile = (QueryFile) node.getUserObject();
		if (queryFile
			.getFile()
			.getAbsoluteFile()
			.equals(file.getAbsoluteFile())) {
			return node;
		}

		for (int i = 0; i < node.getChildCount(); i++) {
			DefaultMutableTreeNode currentNode =
				(DefaultMutableTreeNode) node.getChildAt(i);
			//if (!currentNode.isLeaf()) {
			DefaultMutableTreeNode matchNode = getMatchNode(currentNode, file);
			if (matchNode == null) {
				continue;
			} else {
				return matchNode;
			}
			//}
		}

		return null;
	}

	// DragGestureListener

	public void dragGestureRecognized(DragGestureEvent e) {
		String filename = this.getFilename();
		if (filename == null) {
			return;
		}
		e.startDrag(
			DragSource.DefaultCopyDrop,
			new StringSelection(filename),
			this);
	}

	// DragSourceListener

	public void dragDropEnd(DragSourceDropEvent e) {
		//System.out.println("dragSource-dragDropEnd");
	}

	public void dragEnter(DragSourceDragEvent e) {
		//System.out.println("dragSource-dragEnter");
	}

	public void dragExit(DragSourceEvent e) {
		//System.out.println("dragSource-dragExit");
	}

	public void dragOver(DragSourceDragEvent e) {
		//System.out.println("dragSource-dragOver");
	}
	public void dropActionChanged(DragSourceDragEvent e) {
		//System.out.println("dragSource-dropActionChanged");
	}

	// DropTargetListener
	public void dragEnter(DropTargetDragEvent e) {
		//System.out.println("dragTarget-dragEnter");

	}

	public void dragOver(DropTargetDragEvent e) {
		//System.out.println("dragTarget-dragOver");

	}

	public void dropActionChanged(DropTargetDragEvent e) {
		//System.out.println("dragTarget-dropActionChanged");

	}

	public void drop(DropTargetDropEvent e) {
		//System.out.println("dragTarget-drop");
		try {
			DataFlavor stringFlavor = DataFlavor.stringFlavor;
			Transferable tr = e.getTransferable();
			if (e.isDataFlavorSupported(stringFlavor)) {
				String filename = (String) tr.getTransferData(stringFlavor);
				File targetFile = new File(filename);
				e.acceptDrop(DnDConstants.ACTION_COPY_OR_MOVE);
				e.dropComplete(true);

				Point p = e.getLocation();
				TreePath path = this.getClosestPathForLocation(p.x, p.y);
				File destFile = this.getQueryFile(path);
				if (destFile == null) {
					return;
				}

				if (destFile.isFile()) {
					destFile = destFile.getParentFile();
				}

				if (destFile.equals(destFile.getParent())) {
					return;
				} else {
					File newFile = new File(destFile, targetFile.getName());
					if (newFile.exists()) {
						if (newFile.getParentFile().equals(destFile)) {
							return;
						} else {
							JOptionPane.showMessageDialog(
								this,
								newFile.getName() + " exist",
								"Error",
								JOptionPane.ERROR_MESSAGE);
							return;
						}
					} else {
						if (targetFile.renameTo(newFile)) {
							DefaultMutableTreeNode node =
								this.getMatchNode(this.root, destFile);

							if (node != null) {
								node.removeAllChildren();
								this.resetTreeNode(node, destFile);
								this.reload(node);
								TreePath currentPath = new TreePath(node);
								this.expandAll(currentPath, true);
							}

							node =
								this.getMatchNode(
									this.root,
									targetFile.getParentFile());

							if (node != null) {
								node.removeAllChildren();
								this.resetTreeNode(
									node,
									targetFile.getParentFile());
								if (node.getChildCount() == 0) {
									this.addEmptyNode(node);
								}

								this.reload(node);
								TreePath currentPath = new TreePath(node);
								this.expandAll(currentPath, true);
							}
						}
					}
				}
			} else {
				e.rejectDrop();
			}
		} catch (Exception ex) {
		}
	}

	public void dragExit(DropTargetEvent e) {
		//System.out.println("dragTarget-dragExit");
	}

	// DragSourceMotionListener
	public void dragMouseMoved(DragSourceDragEvent e) {
	}
}
