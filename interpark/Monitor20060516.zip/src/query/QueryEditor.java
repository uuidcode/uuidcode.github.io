package query;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;
import java.util.TreeSet;
import java.util.Vector;

import javax.swing.Action;
import javax.swing.JFileChooser;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.KeyStroke;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import message.ConsoleMessage;
import message.FileMessage;
import message.FrameAndFileMappingMessage;
import message.Message;
import message.MessageListener;
import message.MessageQueue;

import action.CommonAction;
import action.CopyAction;
import action.CutAction;
import action.ExplainPlanAction;
import action.PasteAction;
import action.CancelQueryAction;
import action.RedoAction;
import action.RunQueryAction;
import action.SaveAsFileAction;
import action.SaveFileAction;
import action.UndoAction;

public class QueryEditor extends JPanel implements MessageListener {
	private JInternalFrame frame;
	private QueryStylePane textPane;
	private String filename;
	private int undoIndex = -1;
	private JPopupMenu popupMenu;
	private Vector actionVector;
	private File currentDir;

	public QueryEditor() {
		this.setLayout(new BorderLayout());
		this.textPane = new QueryStylePane();
		this.textPane.setFont(new Font("Gulim", Font.PLAIN, 12));
		JScrollPane scrollPane = new JScrollPane(textPane);
		scrollPane.setRowHeaderView(new LineNumberView(textPane));
		this.add(scrollPane);
		this.setupAction();
		this.setupPopupMenuItem();
		this.setupKeyStroke();
		this.setupKeyListener();
		this.setupMouseListener();
		MessageQueue.getInstance().addListener(this);
		this.addAncestorListener(new AncestorListener() {
			public void ancestorAdded(AncestorEvent event) {
				MessageQueue.getInstance().addListener(QueryEditor.this);
			}

			public void ancestorMoved(AncestorEvent event) {
			}

			public void ancestorRemoved(AncestorEvent event) {
				MessageQueue.getInstance().removeListener(QueryEditor.this);
			}
		});
	}

	private void setupKeyListener() {
		this.textPane.addKeyListener(new KeyListener() {
			public void keyPressed(KeyEvent e) {
			}

			public void keyReleased(KeyEvent e) {
			}

			public void keyTyped(KeyEvent e) {
				if (e.getModifiers() == KeyEvent.CTRL_MASK) {
					return;
				}
				saveHistory();
				setStyle();
			}
		});
	}

	private void setupMouseListener() {
		this.textPane.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent me) {
				showPopup(me);
			}

			public void mouseReleased(MouseEvent me) {
				showPopup(me);
			}

			public void showPopup(MouseEvent me) {
				if (me.isPopupTrigger()) {
					popupMenu.show(me.getComponent(), me.getX(), me.getY());
				}
			}
		});
	}

	private void setupKeyStroke() {
		for (int i = 0; i < this.actionVector.size(); i++) {
			Action action = (Action) this.actionVector.get(i);

			KeyStroke keyStroke =
				(KeyStroke) action.getValue(Action.ACCELERATOR_KEY);
			this.textPane.registerKeyboardAction(
				action,
				keyStroke,
				WHEN_FOCUSED);
		}
	}

	private void setupAction() {
		this.actionVector = new Vector();
		this.actionVector.add(RunQueryAction.getInstance());
		this.actionVector.add(ExplainPlanAction.getInstance());
		this.actionVector.add(CancelQueryAction.getInstance());
		this.actionVector.add(SaveFileAction.getInstance());
		this.actionVector.add(SaveAsFileAction.getInstance());
		this.actionVector.add(CutAction.getInstance());
		this.actionVector.add(CopyAction.getInstance());
		this.actionVector.add(PasteAction.getInstance());
		this.actionVector.add(UndoAction.getInstance());
		this.actionVector.add(RedoAction.getInstance());
	}

	private String[] getKeyword() {
		return new String[] {
			"select",
			"from",
			"where",
			"and",
			"or",
			"group",
			"order",
			"by",
			"union",
			"all",
			"case",
			"when",
			"else",
			"then",
			"end",
			"minuse",
			"exists",
			"null",
			"not",
			"in"};
	}

	private String[] getSymbol() {
		return new String[] { "&lgt;", "&gt;", "=", "(", ")", "*", "+", "-", "/" };
	}

	private boolean isTerminal(char c) {
		return c == '\r' || c == '\n' || c == ' ' || c == '\t';
	}

	private void setStyle(StyledDocument document, String query, int start) {
		query = query.toLowerCase();
		int endIndex = query.indexOf("<", start);
		SimpleAttributeSet keywordSet = new SimpleAttributeSet();
		StyleConstants.setForeground(keywordSet, Color.BLUE);
		//StyleConstants.setBold(keywordSet, true);

		SimpleAttributeSet commentSet = new SimpleAttributeSet();
		StyleConstants.setForeground(commentSet, Color.GREEN);
		//StyleConstants.setBold(commentSet, true);

		SimpleAttributeSet stringSet = new SimpleAttributeSet();
		StyleConstants.setForeground(stringSet, Color.RED);
		//StyleConstants.setBold(commentSet, true);

		String[] keyword = this.getKeyword();
		for (int i = 0; i < keyword.length; i++) {
			int currentIndex = start;
			while (true) {
				currentIndex = query.indexOf(keyword[i], currentIndex);
				if (currentIndex < 0) {
					break;
				}

				if (currentIndex < endIndex) {
					if (isTerminal(query.charAt(currentIndex - 1))
						&& isTerminal(
							query.charAt(
								currentIndex + keyword[i].length()))) {
						document.setCharacterAttributes(
							currentIndex,
							keyword[i].length(),
							keywordSet,
							true);
					}
					currentIndex += keyword[i].length();
				} else {
					break;
				}
			}
		}

		String[] symbol = this.getSymbol();
		for (int i = 0; i < symbol.length; i++) {
			int currentIndex = start;
			while (true) {
				currentIndex = query.indexOf(symbol[i], currentIndex);
				if (currentIndex < 0) {
					break;
				}

				if (currentIndex < endIndex) {
					document.setCharacterAttributes(
						currentIndex,
						symbol[i].length(),
						keywordSet,
						true);
					currentIndex += symbol[i].length();
				} else {
					break;
				}
			}
		}

		int currentIndex = start;
		while (true) {
			int commentStartIndex = 0;
			currentIndex = query.indexOf("/*", currentIndex);
			if (currentIndex < 0) {
				break;
			}

			commentStartIndex = currentIndex;
			currentIndex = query.indexOf("*/", currentIndex);
			if (currentIndex > 0 && currentIndex < endIndex) {
				document.setCharacterAttributes(
					commentStartIndex,
					currentIndex - commentStartIndex + 2,
					commentSet,
					true);
				currentIndex += 2;
			} else {
				break;
			}
		}

		currentIndex = start;
		while (true) {
			int commentStartIndex = 0;
			currentIndex = query.indexOf("--", currentIndex);
			if (currentIndex < 0) {
				break;
			}

			commentStartIndex = currentIndex;
			currentIndex = query.indexOf("\n", currentIndex);
			if (currentIndex > 0 && currentIndex < endIndex) {
				document.setCharacterAttributes(
					commentStartIndex,
					currentIndex - commentStartIndex,
					commentSet,
					true);
				currentIndex += 1;
			} else {
				break;
			}
		}

		currentIndex = start;
		while (true) {
			int commentStartIndex = 0;
			currentIndex = query.indexOf("'", currentIndex);
			if (currentIndex < 0) {
				break;
			}

			commentStartIndex = currentIndex;
			currentIndex = query.indexOf("'", currentIndex + 1);
			if (currentIndex > 0 && currentIndex < endIndex) {
				document.setCharacterAttributes(
					commentStartIndex,
					currentIndex - commentStartIndex,
					stringSet,
					true);
				currentIndex += 1;
			} else {
				break;
			}
		}
	}

	private void setStyle() {
		StyledDocument document = this.textPane.getStyledDocument();
		String queryText = this.textPane.getText();
		int startIndex = 0;
		int endIndex = 0;

		SimpleAttributeSet tagSet = new SimpleAttributeSet();
		StyleConstants.setForeground(tagSet, Color.BLACK);
		StyleConstants.setBold(tagSet, true);

		do {
			startIndex = queryText.indexOf("<", endIndex);
			endIndex = queryText.indexOf(">", startIndex);

			if (startIndex >= 0 && endIndex >= 0) {
				document.setCharacterAttributes(
					startIndex,
					endIndex - startIndex + 1,
					tagSet,
					true);

				String token = queryText.substring(startIndex, endIndex + 1);
				if (token.equals("<queryString>")) {
					setStyle(document, queryText, endIndex + 1);
				}
			}
		} while (startIndex >= 0 && endIndex >= 0);
	}

	private void setupPopupMenuItem() {
		this.popupMenu = new JPopupMenu();
		this.textPane.add(this.popupMenu);
		for (int i = 0; i < this.actionVector.size(); i++) {
			JMenuItemEx item =
				new JMenuItemEx((Action) this.actionVector.get(i));
			item.setInfo(this.textPane);
			this.popupMenu.add(item);
		}
	}

	private File[] getHistoryFiles() {
		String cash = String.valueOf(QueryEditor.this.hashCode());
		File f = new File(".cash/" + cash);
		File[] files = f.listFiles();
		TreeSet treeSet = new TreeSet();
		for (int i = 0; i < files.length; i++) {
			treeSet.add(files[i]);
		}
		return (File[]) treeSet.toArray(new File[0]);
	}

	private TextHistory[] getTextHistory() {
		File[] files = this.getHistoryFiles();
		TextHistory[] history = new TextHistory[files.length];
		for (int i = 0; i < files.length; i++) {
			ObjectInputStream ois = null;
			try {
				ois = new ObjectInputStream(new FileInputStream(files[i]));
				history[i] = (TextHistory) ois.readObject();
			} catch (Exception e) {
			} finally {
				if (ois != null) {
					try {
						ois.close();
					} catch (Exception e) {
					}
				}
			}
		}
		return history;
	}

	private void saveHistory() {
		String cash = String.valueOf(QueryEditor.this.hashCode());
		File f = new File(".cash/" + cash);
		f.mkdirs();
		File currentFile =
			new File(f, String.valueOf(System.currentTimeMillis()));
		TextHistory textHiostory =
			new TextHistory(textPane.getText(), textPane.getCaretPosition());

		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(new FileOutputStream(currentFile));
			oos.writeObject(textHiostory);
		} catch (Exception e) {
		} finally {
			if (oos != null) {
				try {
					oos.close();
				} catch (Exception e) {
				}
			}
		}
	}

	private void save(String filename) {
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(filename));
			String text = this.textPane.getText();
			writer.write(text);
		} catch (Exception e) {
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (Exception e) {

				}
			}
		}
	}

	private void setTextByFile(String filename) {
		BufferedReader reader = null;
		StringBuffer buffer = new StringBuffer();
		try {
			reader = new BufferedReader(new FileReader(filename));
			String line = null;
			while ((line = reader.readLine()) != null) {
				buffer.append(line + "\n");
			}
			String text = buffer.toString();
			text = text.replaceAll("\t", "  ");
			this.textPane.setText(text);
		} catch (Exception e) {
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (Exception e) {

				}
			}
		}
	}

	public String getFilename() {
		return this.filename;
	}

	public String getText() {
		return this.textPane.getText();
	}

	public void setText(String text) {
		this.textPane.setText(text);
		this.saveHistory();
		this.setStyle();
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public void readFile(String filename) {
		this.filename = filename;
		this.setTextByFile(this.filename);
		this.textPane.setCaretPosition(0);
		this.textPane.getCaret().setVisible(true);
		this.textPane.setFocusable(true);
		this.saveHistory();
		this.setStyle();
	}

	public void undo() {
		TextHistory[] histories = this.getTextHistory();
		if (this.undoIndex == -1) {
			this.undoIndex = histories.length - 1;
		}
		undoIndex--;
		if (this.undoIndex == -1) {
			this.undoIndex = histories.length - 1;
		}
		this.textPane.setText(histories[this.undoIndex].getText());
		this.textPane.setCaretPosition(histories[undoIndex].getCaretPosition());
		this.textPane.getCaret().setVisible(true);
		this.setStyle();
	}

	public void redo() {
		TextHistory[] histories = this.getTextHistory();
		if (this.undoIndex == -1) {
			this.undoIndex = histories.length - 1;
		}

		undoIndex++;
		if (this.undoIndex >= histories.length) {
			return;
		}

		this.textPane.setText(histories[this.undoIndex].getText());
		this.textPane.setCaretPosition(histories[undoIndex].getCaretPosition());
		this.textPane.getCaret().setVisible(true);
		this.setStyle();
	}

	public void copy() {
		textPane.copy();
		this.saveHistory();
		this.setStyle();
	}

	public void cut() {
		textPane.cut();
		this.saveHistory();
		this.setStyle();
	}

	public void paste() {
		textPane.paste();
		this.saveHistory();
		this.setStyle();
	}

	public void save() {
		if (this.filename == null) {
			File f = null;

			JFileChooser fileChooser = null;
			if (this.currentDir != null) {
				fileChooser = new JFileChooser(this.currentDir);
			} else {
				fileChooser = new JFileChooser(".");
			}

			fileChooser.setFileFilter(new QueryFileFilter());
			if (JFileChooser.APPROVE_OPTION
				== fileChooser.showSaveDialog(this)) {
				f = fileChooser.getSelectedFile();
			}

			if (f == null) {
				return;
			} else {
				this.filename = f.getAbsolutePath();
				if (!this.filename.endsWith(".sql")) {
					this.filename += ".sql";
				}
			}
		}
		save(this.filename, this.getText());
		MessageQueue.getInstance().sendMessage(
			new ConsoleMessage(this.filename + " is saved."));
		/**
		 * �űԷ� �ۼ��� ������ ����ɶ�
		 * TabbedDesktop���� listening 
		 */
		MessageQueue.getInstance().sendMessage(
			new FrameAndFileMappingMessage(this.frame, this.filename));
		MessageQueue.getInstance().sendMessage(new FileMessage(this.filename));
	}

	public void saveAs() {
		File f = null;
		JFileChooser fileChooser = new JFileChooser(".");
		fileChooser.setFileFilter(new QueryFileFilter());
		if (JFileChooser.APPROVE_OPTION == fileChooser.showSaveDialog(this)) {
			f = fileChooser.getSelectedFile();
		}

		if (f == null) {
			return;
		} else {
			this.filename = f.getAbsolutePath();
			if (!this.filename.endsWith(QueryFileTreePanel.SQL_EXT)) {
				this.filename += QueryFileTreePanel.SQL_EXT;
			};
		}

		save(this.filename, this.getText());
		MessageQueue.getInstance().sendMessage(new FileMessage(this.filename));
	}

	private void save(String filename, String text) {
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(filename));
			writer.write(text);
		} catch (Exception ex) {
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (Exception ex) {

				}
			}
		}
	}

	private String getSelectedText() {
		String selectedText = textPane.getSelectedText();
		if (selectedText == null) {
			String text = getText();
			int position = textPane.getCaret().getDot();
			int endPosition = text.indexOf("\n\n", position);
			if (endPosition < 0) {
				endPosition = text.indexOf("</queryString>", position);
			}
			String temp = text.substring(0, position);
			int startPosition = temp.lastIndexOf("\n\n");
			if (startPosition < 0) {
				String keyword = "<queryString>";
				startPosition = temp.lastIndexOf(keyword);
				if (startPosition > 0) {
					startPosition += keyword.length();
				}
			} else {
				startPosition += 2;
			}
			selectedText = text.substring(startPosition, endPosition);
			selectedText = selectedText.trim();
		}
		return selectedText;
	}

	private Query[] getCurrentQuery(String text) {
		Document document = null;
		try {
			document = DocumentHelper.parseText(getText());
		} catch (Exception e) {
			JOptionPane.showMessageDialog(
				QueryEditor.this,
				e.getMessage(),
				"Error",
				JOptionPane.ERROR_MESSAGE);
			return null;
		}

		List list = document.selectNodes("/query/sql");
		text = text.replaceAll("&lt;", "<");
		text = text.replaceAll("&gt;", ">");
		for (int i = 0; i < list.size(); i++) {
			Element element = (Element) list.get(i);
			System.out.println(">>> " + element.valueOf("queryString"));
			if (element.valueOf("queryString").indexOf(text) >= 0) {
				Element queryStringElement = element.element("queryString");
				queryStringElement.setText(text);
				Query[] query = new Query[1];
				query[0] = new Query(null, element);
				return query;
			}
		}
		return null;
	}

	public void listen(Message message) {
		if (message == null) {
			return;
		}

		if (message instanceof CommonAction) {
			CommonAction action = (CommonAction) message;
			if (this.textPane.hashCode() != action.getSourceHashCode()) {
				return;
			}
		} else {
			return;
		}

		if (message instanceof CopyAction) {
			this.copy();
		} else if (message instanceof CutAction) {
			this.cut();
		} else if (message instanceof PasteAction) {
			this.paste();
		} else if (message instanceof SaveFileAction) {
			this.save();
		} else if (message instanceof SaveAsFileAction) {
			this.saveAs();
		} else if (message instanceof UndoAction) {
			this.undo();
		} else if (message instanceof RedoAction) {
			this.redo();
		} else if (message instanceof RunQueryAction) {
			new Thread() {
				public void run() {
					String selectedText = getSelectedText();
					System.out.println(">>> " + selectedText);
					Query[] query = getCurrentQuery(selectedText);

					if (query == null) {
						System.out.println("query is null.");
						return;
					}

					RunDialog runDialog =
						new RunDialog(QueryEditor.this, "Run", true, query);

					if (query[0] != null
						&& query[0].getParameter() != null
						&& query[0].getParameter().length != 0) {
						runDialog.show();
					}
				}
			}
			.start();
		} else if (message instanceof ExplainPlanAction) {
			new Thread() {
				public void run() {
					String sessionId =
						String.valueOf(System.currentTimeMillis());
					StringBuffer sql = new StringBuffer();
					String selectedText = getSelectedText();
					selectedText = selectedText.replaceAll("&gt;", ">");
					selectedText = selectedText.replaceAll("&lt;", "<");
					sql.append(
						"EXPLAIN PLAN set statement_id = '"
							+ sessionId
							+ "' for ");
					sql.append(selectedText);

					StringBuffer planTableSql = new StringBuffer();
					planTableSql.append("select                                                              \n");
					planTableSql.append("	rpad(' ',2*level) ||                                               \n");
					planTableSql.append("	operation || ' ' ||                                                \n");
					planTableSql.append("	decode(optimizer,null,null,                                        \n");
					planTableSql.append("		'(' || lower(optimizer) || ') '                                  \n");
					planTableSql.append("	)  ||                                                              \n");
					planTableSql.append("	object_type || ' ' ||                                              \n");
					planTableSql.append("	object_owner || ' ' ||                                             \n");
					planTableSql.append("	object_name || ' ' ||                                              \n");
					planTableSql.append("	decode(options,null,null,'('||lower(options)||') ') ||             \n");
					planTableSql.append("	decode(search_columns, null,null,                                  \n");
					planTableSql.append("		'(Columns ' || search_columns || ' '                             \n");
					planTableSql.append("	)  ||                                                              \n");
					planTableSql.append("	other_tag || ' ' ||                                                \n");
					planTableSql.append("	decode(partition_id,null,null,                                     \n");
					planTableSql.append("		'Pt id: ' || partition_id || ' '                                 \n");
					planTableSql.append("	)  ||                                                              \n");
					planTableSql.append("	decode(partition_start,null,null,                                  \n");
					planTableSql.append("		'Pt Range: ' || partition_start || ' - ' ||                      \n");
					planTableSql.append("		partition_stop || ' '                                            \n");
					planTableSql.append("	) ||                                                               \n");
					planTableSql.append("	decode(cost,null,null,                                             \n");
					planTableSql.append("		'Cost (' || cost || ',' || cardinality || ',' || bytes || ')'    \n");
					planTableSql.append("	)                                                                  \n");
					planTableSql.append("		plan                                                             \n");
					planTableSql.append("from                                                                \n");
					planTableSql.append("	plan_table                                                         \n");
					planTableSql.append("connect by                                                          \n");
					planTableSql.append("	prior id = parent_id and statement_id = '" + sessionId + "'       \n");
					planTableSql.append("start with                                                          \n");
					planTableSql.append("	id = 0 and statement_id = '" + sessionId + "'                      \n");
					planTableSql.append("order by                                                            \n");
					planTableSql.append("	id                                                                 \n");

					Query[] query = getCurrentQuery(selectedText);
					QueryExecutor.execute(
						query[0].getDatabase(),
						sql.toString(),
						null);
					System.out.println("1");
					
					query[0].setQueryString(planTableSql.toString());
					RunDialog runDialog =
						new RunDialog(QueryEditor.this, "Run", true, query);
					System.out.println("2");
					
					QueryExecutor.execute(
						query[0].getDatabase(),
						"delete from plan_table where statement_id = '"
							+ sessionId
							+ "'",
						null);
					System.out.println("3");
				}
			}
			.start();
		}
	}

	public JInternalFrame getFrame() {
		return frame;
	}

	public void setFrame(JInternalFrame frame) {
		this.frame = frame;
	}

	public File getCurrentDir() {
		return currentDir;
	}

	public void setCurrentDir(File file) {
		currentDir = file;
	}

}
