package query;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class QueryReader {
	public static Query[] getSQL(String filename) throws Exception {
		SAXReader reader = new SAXReader();
		Document document = reader.read(filename);
		List list = document.selectNodes("/query/sql");
		String[] sql = new String[list.size()];
		Query[] query = new Query[list.size()];
		for (int i = 0; i < list.size(); i++) {
			Element element = (Element) list.get(i);
			query[i] = new Query(filename, element);
		}
		return query;
	}
}