package query;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Vector;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;

import message.MessageQueue;
import message.ResultSetMessage;

public class CResultSetInternalFrame extends JInternalFrame {
	private static final int ROW_HEIGHT = 16;
	private CResultSet[] rs;
	private String uniqueValue = String.valueOf(System.currentTimeMillis());
	
	public CResultSetInternalFrame(CResultSet[] resultSet) {
		super("", true, true, true, false);
		this.setFrameIcon(new ImageIcon("resource/image/result.gif"));
		//this.setUI(new MyInternalFrameUI(this));
		this.rs = resultSet;
		try {
			Vector chartableRSVector = new Vector();
			JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.LEFT);
			JPanel panel = new JPanel(new GridLayoutEx(rs.length));
			int totalRow = 0;
			for (int i = 0 ; i < rs.length; i++) {
				if (rs[i] != null) {
					totalRow += rs[i].getRowCount();
				}
			}
			panel.setPreferredSize(new Dimension(1000, rs.length*65 + totalRow*ROW_HEIGHT));
			tabbedPane.addTab("��ü", new JScrollPane(panel));
			for (int i = 0; i < rs.length; i++) {
				if (rs[i] != null) {
					JPanel resultsetPanel = new JPanel(new BorderLayout());
					resultsetPanel.setPreferredSize(new Dimension(1000, 60 + rs[i].getRowCount()*ROW_HEIGHT));
					JPanel headerPanel = getHeaderPanel(i);
					resultsetPanel.add(headerPanel, BorderLayout.NORTH);
					JTable table = new ResultSetTable(rs[i]);
					resultsetPanel.add(
						new JScrollPane(table),
						BorderLayout.CENTER);
					panel.add(resultsetPanel);
					
					JPanel subPanel = new JPanel(new BorderLayout());
					subPanel.add(
						new JScrollPane(new ResultSetTable(rs[i])),
						BorderLayout.CENTER);
	
					if (rs.length != 1) {
						tabbedPane.addTab(rs[i].getQuery().getComment(), subPanel);
					}
	
					if (rs[i].getQuery().isChartable()) {
						chartableRSVector.add(rs[i]);
					}
					title = rs[i].getQuery().getFilename();
					if (title == null) {
						title = "New";
					}
					int index = title.lastIndexOf(File.separator);
					if (index > 0) {
						title = title.substring(index + 1);
						if (title.toLowerCase().endsWith(".sql")) {
							title = title.substring(0, title.length() - 4);
						}
					}
				}
			}
			setTitle(title);

			JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
			splitPane.setOneTouchExpandable(true);
			splitPane.setDividerSize(10);
			splitPane.setLeftComponent(tabbedPane);
			if (chartableRSVector.size() > 0) {
				splitPane.setRightComponent(
					new ResultSetChartPanel(
						(CResultSet[]) chartableRSVector.toArray(
							new CResultSet[0])));
			}
			setContentPane(splitPane);
			setSize(400, 400);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private JPanel getHeaderPanel(int i) {
		JPanel headerPanel =
			new JPanel(new FlowLayout(FlowLayout.LEFT));
		headerPanel.add(
			new JLabel(
				rs[i].getQuery().getComment()
					+ " [total row: "
					+ rs[i].getRowCount()
					+ "]"));
		
		JButton refreshButton = getRefreshButton();
		headerPanel.add(refreshButton);
		JButton newButton = getNewButton(i);
		headerPanel.add(newButton);
		return headerPanel;
	}

	private JButton getNewButton(int i) {
		final int currentIndex = i;
		Icon newIcon = new ImageIcon("resource/image/newOpen_disable.gif");
		JButton newButton = new JButton();
		newButton.setIcon(newIcon);
		newButton.setToolTipText("new");
		newButton.setBorderPainted(false);
		newButton.setContentAreaFilled(false);
		newButton.setPreferredSize(new Dimension(newIcon.getIconWidth(), newIcon.getIconHeight()));
		newButton.setRolloverEnabled(true);
		newButton.setRolloverIcon(new ImageIcon("resource/image/newOpen_enable.gif"));
		newButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Thread() {
					public void run() {
						Vector queries = new Vector();
						for (int i = 0; i < rs.length; i++) {
							queries.add(rs[i].getQuery());
						}
						Query[] query =
							(Query[]) queries.toArray(new Query[0]);
						Vector resultsetVector = new Vector();
						for (int i = 0; i < query.length; i++) {
							if (currentIndex == i) {
								resultsetVector.add(
									QueryExecutor.getData(query[i]));
							}
						}
		
						MessageQueue.getInstance().sendMessage(
							new ResultSetMessage((CResultSet[])resultsetVector.toArray(new CResultSet[0])));
					}
				}
				.start();
			}
		});
		return newButton;
	}

	private JButton getRefreshButton() {
		Icon refreshIcon = new ImageIcon("resource/image/refresh_disable.gif");
		JButton refresh = new JButton();
		refresh.setIcon(refreshIcon);
		refresh.setToolTipText("refresh");
		refresh.setBorderPainted(false);
		refresh.setContentAreaFilled(false);
		refresh.setPreferredSize(new Dimension(refreshIcon.getIconWidth(), refreshIcon.getIconHeight()));
		refresh.setRolloverEnabled(true);
		refresh.setRolloverIcon(new ImageIcon("resource/image/refresh_enable.gif"));
		refresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Thread() {
					public void run() {
						Vector queries = new Vector();
						for (int i = 0; i < rs.length; i++) {
							queries.add(rs[i].getQuery());
						}
						Query[] query =
							(Query[]) queries.toArray(new Query[0]);
						Vector resultsetVector = new Vector();
						for (int i = 0; i < query.length; i++) {
							resultsetVector.add(
								QueryExecutor.getData(query[i]));
						}
		
						MessageQueue.getInstance().sendMessage(
							new ResultSetMessage((CResultSet[])resultsetVector.toArray(new CResultSet[0])));
					}
				}
				.start();
			}
		});
		return refresh;
	}

	public String getUniqueValue() {
		return uniqueValue;
	}

	public String[] getParameters() {
		return this.rs[0].getQuery().getParameter();
	}

	public String getExecuteDate() {
		return this.rs[0].getQuery().getExecuteDate();
	}
}
