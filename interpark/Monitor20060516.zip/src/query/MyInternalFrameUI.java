package query;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalInternalFrameUI;

public class MyInternalFrameUI extends MetalInternalFrameUI {
	public MyInternalFrameUI(final JInternalFrame internal) {
		super(internal);
	}

	public static ComponentUI createUI(final JComponent internal) {
		return new MyInternalFrameUI((JInternalFrame) internal);
	}

	protected JComponent createNorthPane(final JInternalFrame internal) {
		JLabel titleLabel = new JLabel(internal.getTitle());
		titleLabel.setForeground(Color.BLACK);

		//create button shown on titlebar
		JButton myButton = new JButton("Press");

		myButton.setForeground(Color.BLACK);
		myButton.setBackground(Color.LIGHT_GRAY);

		//create panel and add titlleLabel & button into it
		JPanel customTitlePanel = new JPanel();
		customTitlePanel.setBackground(Color.LIGHT_GRAY);
		customTitlePanel.setLayout(new BorderLayout());
		customTitlePanel.add(titleLabel, BorderLayout.WEST);
		customTitlePanel.add(myButton, BorderLayout.EAST);
		return customTitlePanel;
	}
}
