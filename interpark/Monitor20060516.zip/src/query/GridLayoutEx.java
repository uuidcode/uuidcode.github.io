package query;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager;

public class GridLayoutEx implements LayoutManager, java.io.Serializable {
	int rows;
	int cols = 1;
	int vgap = 5;

	public GridLayoutEx(int rows) {
		this.rows = rows;
	}

	public int getRows() {
		return rows;
	}

	public Dimension preferredLayoutSize(Container parent) {
		synchronized (parent.getTreeLock()) {
			Insets insets = parent.getInsets();
			int ncomponents = parent.getComponentCount();
			int nrows = rows;
			int ncols = cols;

			if (nrows > 0) {
				ncols = (ncomponents + nrows - 1) / nrows;
			} else {
				nrows = (ncomponents + ncols - 1) / ncols;
			}
			int w = 0;
			int h = 0;
			for (int i = 0; i < ncomponents; i++) {
				Component comp = parent.getComponent(i);
				Dimension d = comp.getPreferredSize();
				if (w < d.width) {
					w = d.width;
				}
				if (h < d.height) {
					h = d.height;
				}
			}
			return new Dimension(
				insets.left + insets.right + ncols * w,
				insets.top + insets.bottom + nrows * h + (nrows - 1) * vgap);
		}
	}

	public Dimension minimumLayoutSize(Container parent) {
		synchronized (parent.getTreeLock()) {
			Insets insets = parent.getInsets();
			int ncomponents = parent.getComponentCount();
			int nrows = rows;
			int ncols = cols;

			if (nrows > 0) {
				ncols = (ncomponents + nrows - 1) / nrows;
			} else {
				nrows = (ncomponents + ncols - 1) / ncols;
			}
			int w = 0;
			int h = 0;
			for (int i = 0; i < ncomponents; i++) {
				Component comp = parent.getComponent(i);
				Dimension d = comp.getMinimumSize();
				if (w < d.width) {
					w = d.width;
				}
				if (h < d.height) {
					h = d.height;
				}
			}
			return new Dimension(
				insets.left + insets.right + ncols * w + (ncols - 1),
				insets.top + insets.bottom + nrows * h + (nrows - 1));
		}
	}

	public void layoutContainer(Container parent) {
		synchronized (parent.getTreeLock()) {
			Insets insets = parent.getInsets();
			int ncomponents = parent.getComponentCount();
			int nrows = rows;
			int ncols = cols;
			boolean ltr = parent.getComponentOrientation().isLeftToRight();

			if (ncomponents == 0) {
				return;
			}
			if (nrows > 0) {
				ncols = (ncomponents + nrows - 1) / nrows;
			} else {
				nrows = (ncomponents + ncols - 1) / ncols;
			}
			int w = parent.getWidth() - (insets.left + insets.right);
			int h = parent.getHeight() - (insets.top + insets.bottom);
			w = w / ncols;
			h = insets.top;
			
			if (ltr) {
				for (int c = 0, x = insets.left; c < ncols; c++, x += w) {
					for (int r = 0, y = insets.top; r < nrows; r++) {
						int i = r * ncols + c;
						if (i < ncomponents) {
							Component component = parent.getComponent(i);
							int preperredHeight = (int) component.getPreferredSize().getHeight();
							parent.getComponent(i).setBounds(x, y, w, preperredHeight);
							y += preperredHeight;
							y += vgap;
						}
					}
				}
			} else {
				for (int c = 0, x = parent.getWidth() - insets.right - w;
					c < ncols;
					c++, x -= w) {
					for (int r = 0, y = insets.top; r < nrows; r++) {
						int i = r * ncols + c;
						if (i < ncomponents) {
							Component component = parent.getComponent(i);
							int preperredHeight = (int) component.getPreferredSize().getHeight();
							parent.getComponent(i).setBounds(x, y, w, preperredHeight);
							y += preperredHeight;
							y += vgap;
						}
					}
				}
			}
		}
	}

	public String toString() {
		return getClass().getName() + "[rows=" + rows + "]";
	}

	public void removeLayoutComponent(Component comp) {

	}

	public void addLayoutComponent(String name, Component comp) {

	}
}
