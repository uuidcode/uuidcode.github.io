package query;

import java.io.File;

import javax.swing.filechooser.FileFilter;

public class QueryFileFilter extends FileFilter {
	public final static String EXT = ".sql";
	
	public boolean accept(File f) {
		if (f.isDirectory()) {
			return true;
		}
		
		return f.getName().toLowerCase().endsWith(EXT);
	}

	public String getDescription() {
		return EXT.substring(1);
	}
}
