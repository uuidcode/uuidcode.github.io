package query;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.io.File;

import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;

import action.ArrangeFrameAction;

import message.FrameAndFileMappingMessage;
import message.Message;
import message.MessageListener;
import message.MessageQueue;

public class TabbedDesktop extends JPanel implements MessageListener {
	public static final String FILE_PROPERTY = "File";
	private JDesktopPane desktopPane;
	private JTabbedPane tabbedPane;

	public TabbedDesktop() {
		super(new BorderLayout());
		this.desktopPane = new JDesktopPane();
		this.tabbedPane = new JTabbedPane();
		this.tabbedPane.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
		this.tabbedPane.setPreferredSize(new Dimension(800, 30));
		this.tabbedPane.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				selectFrame();
			}

		});
		this.add(this.tabbedPane, BorderLayout.NORTH);
		this.add(this.desktopPane, BorderLayout.CENTER);
		MessageQueue.getInstance().addListener(this);
		DropTarget newTarget =	new DropTarget(this, DnDConstants.ACTION_COPY_OR_MOVE, new TabbedDesktopDropTargetListener(this));
	}

	private void selectFrame() {
		Component selectedComponenet = tabbedPane.getSelectedComponent();
		if (selectedComponenet != null
			&& selectedComponenet instanceof JLabel) {
			JLabel label = (JLabel) selectedComponenet;
			for (int i = 0; i < desktopPane.getComponentCount(); i++) {
				Component component = desktopPane.getComponent(i);
				if (component instanceof JInternalFrame) {
					JInternalFrame f = (JInternalFrame) component;
					if (label.getName().equals(String.valueOf(f.hashCode()))) {
						f.setFocusable(true);
						f.setVisible(true);
						try {
							f.setSelected(true);
						} catch (Exception ex) {
						}
						break;
					}
				}
			}
		}
	}

	private void selectFrame(String filename) {
		for (int i = 0; i < desktopPane.getComponentCount(); i++) {
			Component component = desktopPane.getComponent(i);
			if (component instanceof JInternalFrame) {
				JInternalFrame f = (JInternalFrame) component;
				Object object = f.getClientProperty(FILE_PROPERTY);
				if (object != null && object instanceof String) {
					if (filename.equals(object.toString())) {
						f.setFocusable(true);
						f.setVisible(true);
						try {
							f.setSelected(true);
						} catch (Exception ex) {
						}
						break;
					}
				}
			}
		}
	}

	private void selectTab(JInternalFrame frame) {
		for (int i = 0; i < tabbedPane.getTabCount(); i++) {
			Component compoenent = tabbedPane.getComponentAt(i);
			if (compoenent instanceof JLabel) {
				JLabel label = (JLabel) compoenent;
				if (label.getName().equals(String.valueOf(frame.hashCode()))) {
					tabbedPane.setSelectedIndex(i);
				}
			}
		}
	}

	private void removeTab(JInternalFrame frame) {
		for (int i = 0; i < tabbedPane.getTabCount(); i++) {
			Component compoenent = tabbedPane.getComponentAt(i);
			if (compoenent instanceof JLabel) {
				JLabel label = (JLabel) compoenent;
				if (label.getName().equals(String.valueOf(frame.hashCode()))) {
					tabbedPane.removeTabAt(i);
					break;
				}
			}
		}
	}

	private boolean isOpened(String filename) {
		for (int i = 0; i < tabbedPane.getTabCount(); i++) {
			Component compoenent = tabbedPane.getComponentAt(i);
			if (compoenent instanceof JLabel) {
				JLabel label = (JLabel) compoenent;
				Object object = label.getClientProperty(FILE_PROPERTY);
				if (object != null && object instanceof String) {
					if (filename.equals(object.toString())) {
						return true;
					}
				}
			}
		}
		return false;
	}

	public void addFrame(final JInternalFrame frame) {
		Object object = frame.getClientProperty(FILE_PROPERTY);
		String filename = null;
		if (object != null && object instanceof String) {
			filename = (String) object;
			if (filename != null) {
				if (isOpened(filename)) {
					selectFrame(filename);
					frame.dispose();
					return;
				}
			}
		}

		frame.addInternalFrameListener(new InternalFrameListener() {
			public void internalFrameActivated(InternalFrameEvent e) {
				selectTab(e.getInternalFrame());
			}

			public void internalFrameClosed(InternalFrameEvent e) {
				removeTab(e.getInternalFrame());
				selectFrame();
			}

			public void internalFrameClosing(InternalFrameEvent e) {
			}

			public void internalFrameDeactivated(InternalFrameEvent e) {
			}

			public void internalFrameDeiconified(InternalFrameEvent e) {
			}

			public void internalFrameIconified(InternalFrameEvent e) {
			}

			public void internalFrameOpened(InternalFrameEvent arg0) {
			}
		});
		desktopPane.add(frame.getTitle(), frame);
		JLabel label = new JLabel();
		label.setName(String.valueOf(frame.hashCode()));
		if (filename != null) {
			label.putClientProperty(FILE_PROPERTY, filename);
		}
		tabbedPane.addTab(frame.getTitle(), label);
		frame.show();
	}

	public void closeAllFrame() {
		this.desktopPane.removeAll();
		this.tabbedPane.removeAll();
		this.desktopPane.revalidate();
		this.tabbedPane.revalidate();
		this.desktopPane.repaint();
		this.tabbedPane.repaint();
	}

	public void listen(Message message) {
		if (message == null) {
			return;
		}

		/**
		 * ���Ӱ� �ۼ��� ������ ����� ��
		 */
		if (message instanceof FrameAndFileMappingMessage) {
			FrameAndFileMappingMessage m = (FrameAndFileMappingMessage) message;
			for (int i = 0; i < tabbedPane.getTabCount(); i++) {
				Component compoenent = tabbedPane.getComponentAt(i);
				if (compoenent instanceof JLabel) {
					JLabel label = (JLabel) compoenent;
					if (label.getName().equals(String.valueOf(m.getFrame().hashCode()))) {
						
						String title = m.getFilename();
						int index = title.lastIndexOf(File.separator);
						if (index > 0) {
							title = title.substring(index + 1);
						}
									
						this.tabbedPane.setTitleAt(i, title);
						m.getFrame().setTitle(title);
						return;
					}
				}
			}
		} else if (message instanceof ArrangeFrameAction) {
			arrangeInterFrame();
		}
	}
	
	public void arrangeInterFrame() {
		JInternalFrame[] internalFrames = desktopPane.getAllFrames();
		int count = internalFrames.length;
	
		if(count == 0) {
			return;
		}
	
		int floorSquare = (int) Math.floor(Math.sqrt(count));
		int perX = desktopPane.getWidth()/floorSquare;
		int perY = desktopPane.getHeight()/floorSquare;
	
		int[] rowCount = new int[floorSquare];
		for(int i = 0; i < count; i++) {
			rowCount[floorSquare - 1 - (i%floorSquare)]++;
		}
	
		int currentColumn = 0;
		int currentRow = 0;
		for(int i = 0; i < count; i++) {
			perY = desktopPane.getHeight()/rowCount[currentColumn];
			internalFrames[i].setBounds(perX*currentColumn, perY*currentRow, perX, perY);
							
			if(currentRow == (rowCount[currentColumn] - 1)) {
				currentRow = 0;
				currentColumn++;
			} else {
				currentRow++;
			}
		}
	}
}