package query;
import java.util.Vector;

import javax.swing.table.DefaultTableModel;

public class ResultSetModel extends DefaultTableModel {
	public ResultSetModel(CResultSet rs) throws Exception {
		if (rs != null) {
			this.setColumnHeader(rs);		
			this.dataVector = rs.getData();			
			this.fireTableDataChanged();
		}		
	}
		
	public void setColumnHeader(CResultSet rs) throws Exception {
		this.columnIdentifiers = new Vector();
		for (int i = 0; i < rs.getColumnCount(); i++) {
			this.columnIdentifiers.add(rs.getColumnName(i + 1));
		}
	}
}
