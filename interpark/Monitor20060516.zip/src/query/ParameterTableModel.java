package query;
import java.util.Vector;

import javax.swing.table.DefaultTableModel;

public class ParameterTableModel extends DefaultTableModel {
	public ParameterTableModel() {
		this.addColumn("Name");
		this.addColumn("Value");	
	}
	
	public void removeAllRow() {
		this.dataVector.removeAllElements();
		this.fireTableDataChanged();
	}

	public boolean isCellEditable(int row, int column) {
		return column != 0;
	}
	
	public void addParameter(String name) {
		Object[] row = new Object[2];
		row[0] = name;
		row[1] = "";
		this.addRow(row);
	}
	
	public String[] getParameter() {
		Vector value = new Vector();
		for (int i = 0; i < this.getRowCount(); i++) {
			value.add(this.getValueAt(i, 1));	
		}
		
		return (String[]) value.toArray(new String[0]);
	}
}