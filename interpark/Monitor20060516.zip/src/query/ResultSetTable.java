package query;
import Config;
import UIUtilities;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import javax.swing.DefaultCellEditor;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToolTip;
import javax.swing.table.TableCellRenderer;

import action.RunETaxAction;
import action.RunETaxAdminAction;
import action.RunETaxTestAction;
import action.RunIPSSAction;
import action.RunIPSSProAction;
import action.RunInterparkAction;

import message.MessageQueue;
import message.ResultSetMessage;

public class ResultSetTable extends JTable {
	private CResultSet rs;

	public ResultSetTable(CResultSet rs) throws Exception {
		super(new ResultSetModel(rs));
		this.rs = rs;
		this.getTableHeader().setReorderingAllowed(false);
		this.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

		DefaultCellEditor editor =
			(DefaultCellEditor) this.getDefaultEditor(Object.class);
		JTextField textField = (JTextField) editor.getComponent();
		textField.addMouseListener(new MouseAdapterForEditor(textField));

		CResultSet codeRs = Config.getCodeRs();

		for (int i = 0; codeRs != null && i < getColumnCount(); i++) {
			IndexableCellRenderer renderer = new IndexableCellRenderer(i);

			Hashtable codeHashtable = new Hashtable();
			StringBuffer tooltip = new StringBuffer();
			String columnName = "";
			String code = "";
			String codeName = "";

			for (int j = 0; j < codeRs.getRowCount(); j++) {
				codeRs.absolute(j + 1);
				if (codeRs
					.getString(1)
					.endsWith(getColumnName(i).toLowerCase())) {
					columnName = codeRs.getString(1);
					code = codeRs.getString(2);
					codeName = codeRs.getString(3);
					String key = columnName + ":" + code + ":" + codeName;
					if (codeHashtable.containsKey(key)) {
						Vector codeVector = (Vector) codeHashtable.get(key);
						codeVector.add(
							codeRs.getString(4) + ":" + codeRs.getString(5));
					} else {
						Vector codeVector = new Vector();
						codeVector.add(
							codeRs.getString(4) + ":" + codeRs.getString(5));
						codeHashtable.put(key, codeVector);
					}
				}
			}

			Enumeration enum = codeHashtable.keys();
			while (enum.hasMoreElements()) {
				Object key = enum.nextElement();
				Vector codeVector = (Vector) codeHashtable.get(key);
				tooltip.append(key + "\n");
				for (int j = 0; j < codeVector.size(); j++) {
					tooltip.append(codeVector.get(j) + "\n");
				}

				if (enum.hasMoreElements()) {
					tooltip.append("---------------------------------\n");
				}
			}

			if (tooltip.length() > 0) {
				JMultiLineToolTip multiLineTooltip = new JMultiLineToolTip();
				multiLineTooltip.setComponent(renderer);
				renderer.setToolTipText(tooltip.toString());

			}

			getColumnModel().getColumn(i).setCellRenderer(renderer);
		}

		UIUtilities.fixColumnSize(this);
	}

	public Component prepareRenderer(
		TableCellRenderer renderer,
		int row,
		int column) {
		Component c = super.prepareRenderer(renderer, row, column);

		if (c != null && c instanceof IndexableCellRenderer) {
			IndexableCellRenderer indexableRenderer = (IndexableCellRenderer) c;
			indexableRenderer.setToolTipText(
				indexableRenderer.getToolTipText());
		}

		return c;
	}

	public JToolTip createToolTip() {
		return new JMultiLineToolTip();
	}

	class MouseAdapterForEditor extends MouseAdapter {
		private JTextField textField;
		private JPopupMenu popupMenu = new JPopupMenu();
		private JMenuItem executeMenuItem;

		public MouseAdapterForEditor(JTextField textField) {
			this.textField = textField;
		}

		private void addMenuItem(File f) {
			File[] list = f.listFiles();
			for (int i = 0; i < list.length; i++) {
				if (list[i].isFile() && list[i].getName().endsWith(".sql")) {
					final QueryFile queryFile = new QueryFile(list[i]);
					final Query[] query =
						Query.getQuery(queryFile.getFile().getAbsolutePath());
					if (query != null
						&& query[0].getDatabase().equals("milti")
						&& query[0].getParameter().length == 1) {
						JMenuItem menuItem =
							new JMenuItem(queryFile.toString());
						menuItem.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent ae) {
								new Thread() {
									public void run() {

										Vector resultsetVector = new Vector();
										for (int i = 0;
											i < query.length;
											i++) {
											query[i].setParameter(
												new String[] {
													textField
														.getSelectedText()});
											resultsetVector.add(
												QueryExecutor.getData(
													query[i]));
										}
										MessageQueue.getInstance().sendMessage(
											new ResultSetMessage(
												(
													CResultSet[]) resultsetVector
														.toArray(
													new CResultSet[0])));
									}
								}
								.start();
							}
						});
						popupMenu.add(menuItem);
					}
				} else if (list[i].isDirectory()) {
					addMenuItem(list[i]);
				}
			}
		}

		public void mousePressed(MouseEvent me) {
			showPopup(me);
		}

		public void mouseReleased(MouseEvent me) {
			showPopup(me);
		}

		public void showPopup(MouseEvent me) {
			if (me.isPopupTrigger()) {
				this.popupMenu.removeAll();
				RunIPSSAction ipssAction = RunIPSSAction.getInstance();
				ipssAction.setMemNo(textField.getText());
				this.popupMenu.add(ipssAction);
				RunIPSSProAction ipssProAction = RunIPSSProAction.getInstance();
				ipssProAction.setMemNo(textField.getText());
				this.popupMenu.add(ipssProAction);
				RunInterparkAction interparkAction =
					RunInterparkAction.getInstance();
				interparkAction.setMemNo(textField.getText());
				this.popupMenu.add(interparkAction);
				RunETaxAdminAction eTaxAdminAction =
					RunETaxAdminAction.getInstance();
				eTaxAdminAction.setMemNo(textField.getText());
				this.popupMenu.add(eTaxAdminAction);
				RunETaxAction eTaxAction = RunETaxAction.getInstance();
				eTaxAction.setMemNo(textField.getText());
				this.popupMenu.add(eTaxAction);
				RunETaxTestAction eTaxTestAction = RunETaxTestAction.getInstance();
				eTaxTestAction.setMemNo(textField.getText());
				this.popupMenu.add(eTaxTestAction);
				this.popupMenu.addSeparator();
				this.addMenuItem(new File("sql"));
				this.popupMenu.revalidate();
				this.popupMenu.repaint();
				this.popupMenu.show(me.getComponent(), me.getX(), me.getY());
			}
		}
	}
}
