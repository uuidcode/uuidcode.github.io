package query;

import java.awt.Container;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.io.File;

public class TabbedDesktopDropTargetListener implements DropTargetListener {
	private Container panel;
	
	public TabbedDesktopDropTargetListener(Container panel) {
		this.panel = panel;	
	}

	public void dragEnter(DropTargetDragEvent e) {
	}

	public void dragOver(DropTargetDragEvent e) {
	}

	public void dropActionChanged(DropTargetDragEvent e) {
	}

	public void drop(DropTargetDropEvent e) {
		try {
			DataFlavor stringFlavor = DataFlavor.stringFlavor;
			Transferable tr = e.getTransferable();
			if (e.isDataFlavorSupported(stringFlavor)) {
				String filename = (String) tr.getTransferData(stringFlavor);
				File file = new File(filename);
				if (file.isDirectory()) {
					return;
				}
				e.acceptDrop(DnDConstants.ACTION_COPY_OR_MOVE);
				e.dropComplete(true);
				Query[] query = Query.getQuery(file.getAbsolutePath());

				if (query == null) {
					return;
				}

				RunDialog runDialog =
					new RunDialog(panel, "Run", true, query);

				if (query[0] != null
					&& query[0].getParameter() != null
					&& query[0].getParameter().length != 0) {
					runDialog.show();
				}
			} else {
				e.rejectDrop();
			}
		} catch (Exception ex) {
		}
	}

	public void dragExit(DropTargetEvent e) {
	}
}