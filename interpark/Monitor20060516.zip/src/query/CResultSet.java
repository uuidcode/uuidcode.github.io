package query;
import java.util.Vector;
import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
 
public class CResultSet implements Serializable {
	final private Vector m_rows;
	final private String[] m_columnNames;
	private int m_currentRowNumber;
	private Query query;
	
	public CResultSet(String[] columnNames, Vector rows) {
		m_columnNames = columnNames;
		m_rows = rows;
		m_currentRowNumber = 0;
	}
		
	public static CResultSet instantiate(ResultSet rs) {
		if(rs == null)
			return null;
		
		try
		{
			String[] columnNames = null;
			Vector rows = null;
			int columnCount;
			ResultSetMetaData rsmd;
			
			// first, get column information...
			rsmd = rs.getMetaData();
			columnCount = rsmd.getColumnCount();
			columnNames = new String[columnCount];
			for(int i = 0; i < columnCount ; i++)
				columnNames[i] = rsmd.getColumnName(i+1);
		
			// second, make rows and close ResultSet
			rows = new Vector();
			while(rs.next())
			{
				Vector row = new Vector();
				for(int i = 0; i < columnCount ; i++) {
					row.add(rs.getString(i+1));
				}
				rows.addElement(row);
			}
			
			// return CResultSet instance...
			return new CResultSet(columnNames, rows);
		}
		catch(Exception e)
		{
			System.err.println("CResultSet.instantiate "+e.getMessage());
			return null;
		}
		finally
		{
			try { rs.close(); } catch(Exception e) {}
		}
	}

	public boolean absolute(int rowNumber)
	{
		if((rowNumber < 0) || (rowNumber > getRowCount()))
			return false;
		
		m_currentRowNumber = rowNumber;
		return true;
	}

	public boolean first()
	{
		return absolute(0);
	}

	public boolean last() {
		return absolute(getRowCount());
	}

	public boolean next() {
		return absolute(m_currentRowNumber + 1);
	}

	public boolean previous() {
		if(m_currentRowNumber == 1) return false;
		return absolute(m_currentRowNumber - 1);
	}

	public String getString(int columnIndex) {
		try
		{
			String s = getField(m_currentRowNumber, columnIndex);
			return (s == null) ? "" : s;
		}
		catch(Exception e)
		{
			System.err.println("CResultSet.getString "+e.getMessage());
			return "";
		}
	}

	public String getString(String columnName) {
		return getString(findColumn(columnName));
	}

	public double getDouble(int columnIndex) {
		try
		{
			String s = getField(m_currentRowNumber, columnIndex);
			return (s == null || s.equals("")) ? 0.0D : Double.parseDouble(s);
		}
		catch(Exception e)
		{
			System.err.println("CResultSet.getDouble "+e.getMessage());
			return -1.0D;
		}
	}
	
	public double getDouble(String columnName) {
		return getDouble(findColumn(columnName));
	}

	public float getFloat(int columnIndex) {
		return (float)getDouble(columnIndex);
	}

	public float getFloat(String columnName) {
		return getFloat(findColumn(columnName));
	}

	public long getLong(int columnIndex) {
		return (long)getDouble(columnIndex);
	}

	public long getLong(String columnName) {
		return getLong(findColumn(columnName));
	}
	
	public int getInt(int columnIndex) {
		return (int)getLong(columnIndex);
	}

	public int getInt(String columnName) {
		return getInt(findColumn(columnName));
	}

	public short getShort(int columnIndex) {
		return (short)(int)getLong(columnIndex);
	}

	public short getShort(String columnName) {
		return getShort(findColumn(columnName));
	}

	public int findColumn(String columnName) {
		for(int i = 0 ; i < getColumnCount() ; i++)
		{
			if(columnName.equalsIgnoreCase(m_columnNames[i]) == true)
				return (i + 1);
		}
		System.err.println("CResultSet.findColumn Column name '" + columnName + "' is not found");
		return 0; // not found
	}

	public int getColumnCount() {
		return m_columnNames.length;
	}
	
	public String getColumnName(int i) {
		if(i>0) i --;
		return m_columnNames[i];
	}	
	
	public int getRowCount() {
		return m_rows.size();
	}
	
	public int getRow() {
		return m_currentRowNumber;
	}
	
	public void close() {
		m_rows.removeAllElements();
	}

	private String getField(int rowNumber, int columnIndex)	throws Exception {
		return (String) ((Vector) m_rows.elementAt(rowNumber-1)).get(columnIndex-1);
	}
	
	public Vector getData() {
		return this.m_rows;
	}

	public Query getQuery() {
		return query;
	}

	public void setQuery(Query query) {
		this.query = query;
	}
	
	public String[] getColumnName() {
		return this.m_columnNames;
	}
}