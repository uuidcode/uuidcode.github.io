package query;
import java.io.File;

public class QueryFile {
	private File file;
	
	public QueryFile(File file) {
		this.file = file;
	}
	
	public String toString() {
		if (this.file.isFile()) {
			String filename = this.file.getName();
			return filename.substring(0, filename.length() - 4);
		} else {
			return this.file.getName();
		}	
	}

	public File getFile() {
		return file;
	}
}