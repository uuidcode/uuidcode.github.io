package query;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Vector;

import message.ConsoleMessage;
import message.HistoryMessage;
import message.MessageQueue;

public class QueryHistory {
	private final static String HISTORY = ".history";
	private Query[] query;
	
	public QueryHistory(Query[] query) {
		this.query = query;	
	}

	public Query[] getQuery() {
		return query;
	}
	
	public static void remove(int row) {
		Vector queryVector = getHistoryQuery();
		queryVector.remove(queryVector.size() - row - 1);
		save(queryVector);
		read();
	}
	
	private static void save(Vector queryVector) {
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(HISTORY, false));
			for (int i = 0; i < queryVector.size(); i++) {
				Query[] currentQuery = (Query[]) queryVector.get(i);
				StringBuffer value = new StringBuffer();
				value.append(currentQuery[0].getExecuteDate());
				value.append(";");
				value.append(currentQuery[0].getFilename());
				String[] parameter = currentQuery[0].getParameter();
				for (int j = 0; j < parameter.length; j++) {
					value.append(";");
					value.append(parameter[j]);
				}
				value.append("\r\n");
				writer.write(value.toString());
			}			
		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (Exception e) {
				}
			}
		}
	}	
	
	public void save() {
		Vector queryVector = getHistoryQuery();
		
//		boolean hasSameQuery = false;
//		for (int i = 0; i < queryVector.size(); i++) {
//			Query[] currentQuery = (Query[]) queryVector.get(i);
//			if (currentQuery.length == this.query.length) {
//				boolean isSame = false;
//				for (int j = 0; j < currentQuery.length; j++) {
//					if (currentQuery[j].equals(this.query[j])) {
//						isSame = true;
//						break;
//					} else {
//						isSame = false;
//					}
//				}
//				
//				if (isSame) {
//					queryVector.remove(i);
//					queryVector.add(this.query);
//					hasSameQuery = true;
//				}
//			}
//		}			
//		
//		if (!hasSameQuery) {
//			queryVector.add(this.query);
//		}
		
		queryVector.add(this.query);
		save(queryVector);
		read();
	}
	
	private static Vector getHistoryQuery() {
		BufferedReader reader = null;
		Vector queryVector = new Vector();
		try {
			reader = new BufferedReader(new FileReader(HISTORY));
			String line = null;
			while ((line = reader.readLine()) != null) {
				Query[] currentQuery = getQuery(line);
				queryVector.add(currentQuery);
			}
		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
		} finally {
			if (reader != null) {
				try {
					reader.close();		 
				} catch (Exception e) {
				}
			}
		}
		return queryVector;
	}

	public static Query[] getQuery(String line) {
		String[] value = line.split(";");
		String executeDate = value[0];
		String filename = value[1];
		int parameterIndex = 2;
		
		Query[] currentQuery = Query.getQuery(filename);
		Vector parameter = new Vector();
		for (int i = parameterIndex; i < value.length; i++) {
			parameter.add(value[i]);
		}
		
		for (int i = 0; i < currentQuery.length; i++) {
			currentQuery[i].setParameter((String[]) parameter.toArray(new String[0]));
			currentQuery[i].setExecuteDate(executeDate);
			currentQuery[i].setFilename(filename);
		}
		return currentQuery;
	}
	
	public static void read() {
		Vector queryVector = getHistoryQuery();
		MessageQueue.getInstance().sendMessage(new HistoryMessage(queryVector));
	}
	
	public String toString() {
		StringBuffer value = new StringBuffer();
		value.append(this.query[0].getExecuteDate());
		value.append(";");
		value.append(this.query[0].getFilename());
		
		String[] parameter = this.query[0].getParameter();
		for (int j = 0 ; j < parameter.length; j++) {
			value.append(";");
			value.append(parameter[j]);
		}
		return value.toString();
	}
}
