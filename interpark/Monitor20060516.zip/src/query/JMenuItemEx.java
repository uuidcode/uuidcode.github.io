package query;

import javax.swing.Action;
import javax.swing.JMenuItem;

public class JMenuItemEx extends JMenuItem {
	private Object info;
	
	public JMenuItemEx(Action action) {
		super(action);
	}
	
	/**
	 * @return
	 */
	public Object getInfo() {
		return info;
	}

	/**
	 * @param object
	 */
	public void setInfo(Object object) {
		info = object;
	}

}
