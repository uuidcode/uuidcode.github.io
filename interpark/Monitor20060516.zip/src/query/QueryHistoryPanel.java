package query;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Vector;

import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import message.HistoryMessage;
import message.Message;
import message.MessageListener;
import message.MessageQueue;

public class QueryHistoryPanel extends JPanel implements MessageListener {
	private DefaultTableModel model;
	private JScrollPane scrollPane;
	private JTable table;

	public QueryHistoryPanel() {
		this.setLayout(new BorderLayout());
		model = new DefaultTableModel() {
			public void setValueAt(Object value, int row, int column) {
				Query[] query = QueryHistory.getQuery(value.toString());
				QueryHistory queryHistory = new QueryHistory(query);
				queryHistory.save();
			}	
		};
		this.model.addColumn("History");
		this.table = new JTable(model);
		this.scrollPane = new JScrollPane(this.table);
		this.add(scrollPane, BorderLayout.CENTER);
		MessageQueue.getInstance().addListener(this);
		this.table.addMouseListener(new MouseAdapterForPopup(this.table));
	}

	public void listen(Message message) {
		if (message instanceof HistoryMessage) {
			HistoryMessage historyMessage = (HistoryMessage) message;
			Vector queryVector = historyMessage.getQueryVector();
			model.getDataVector().removeAllElements();
			model.fireTableDataChanged();
			for (int i = (queryVector.size() - 1); i >= 0; i--) {
				final Query[] query = (Query[]) queryVector.get(i);
				QueryHistory queryHistory = new QueryHistory(query);
				this.model.addRow(new Object[] { queryHistory });
			}
		}
	}
	
	class MouseAdapterForPopup extends MouseAdapter {
		private JPopupMenu popupMenu = new JPopupMenu();
		private JTable table;
		private JMenuItem executeMenuItem;
		private JMenuItem removeMenuItem;
		public MouseAdapterForPopup(
			JTable currentTable) {
			this.table = currentTable;
			executeMenuItem = new JMenuItem("execute");
			executeMenuItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					if (table.getSelectedRow() >= 0) {
						final Object object = model.getValueAt(table.getSelectedRow(), 0);
						if (object instanceof QueryHistory) {
							new Thread() {
								public void run() {
									QueryHistory queryHistory = (QueryHistory) object;
									Query[] query = queryHistory.getQuery();
									Run.run(query);
								}
							}.start();
						}
					}
					
				}
			});
			popupMenu.add(executeMenuItem);
			
			removeMenuItem = new JMenuItem("remove");
			removeMenuItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					if (table.getSelectedRow() >= 0) {
						QueryHistory.remove(table.getSelectedRow());
					}
				}
			});
			popupMenu.add(removeMenuItem);
			table.add(popupMenu);
		}

		public void mousePressed(MouseEvent me) {
			showPopup(me);
		}

		public void mouseReleased(MouseEvent me) {
			showPopup(me);
		}

		public void showPopup(MouseEvent me) {
			if (me.isPopupTrigger()) {
				popupMenu.show(me.getComponent(), me.getX(), me.getY());
			}
		}
	}
}