package query;

import javax.swing.table.DefaultTableCellRenderer;

public class IndexableCellRenderer extends DefaultTableCellRenderer {
	private int column;
	
	public IndexableCellRenderer(int column) {
		this.column = column;
	}

	public int getColumn() {
		return column;
	}
}
