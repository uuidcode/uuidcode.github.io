package query;

import UIUtilities;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import message.FileMessage;
import message.MessageQueue;

public class NewDirDialog extends JDialog {
	private ParameterTableModel model;

	public NewDirDialog(Container owner, String title, boolean modal, final File f) {
		super(UIUtilities.getFrame(owner), title, modal);
		if (f == null || f.isFile()) {
			this.dispose();
			return;
		}

		this.setTitle("Make Directory");
		JPanel panel = new JPanel(new BorderLayout());
		final JTextField dirTextField = new JTextField();
		panel.add(dirTextField, BorderLayout.CENTER);

		JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JButton runButton = new JButton("make");
		runButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				File newFile = new File(f, dirTextField.getText());
				if (newFile.exists()) {
					JOptionPane.showMessageDialog(
					NewDirDialog.this,
						dirTextField.getText() + " exists.",
						"Error",
						JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				newFile.mkdir();
				MessageQueue.getInstance().sendMessage(new FileMessage(newFile.getAbsolutePath()));
				dispose();
			}
		});
		bottomPanel.add(runButton);
		JButton closeButton = new JButton("close");
		closeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NewDirDialog.this.dispose();
			}
		});
		bottomPanel.add(closeButton);
		panel.add(bottomPanel, BorderLayout.SOUTH);
		this.setContentPane(panel);
		this.setSize(300, 80);
	}
}
