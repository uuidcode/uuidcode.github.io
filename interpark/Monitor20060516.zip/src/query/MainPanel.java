package query;

import java.awt.BorderLayout;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JSplitPane;

import action.CloseAllFileAction;
import action.ExitAction;
import action.NewFileAction;

import message.CurrentDirMessage;
import message.Message;
import message.MessageListener;
import message.MessageQueue;
import message.OpenFileMessage;
import message.ResultSetMessage;

public class MainPanel
	extends JPanel
	implements MessageListener {//, Reportable {
	private QueryFileTreePanel queryFileTreePanel;
	private TabbedDesktop desktop;
	private File currentDir;
	
	public MainPanel(CResultSet rs) throws Exception {
		super();
		this.desktop = new TabbedDesktop();
		this.setLayout(new BorderLayout());
		this.queryFileTreePanel = new QueryFileTreePanel();
		JSplitPane splitPane = new JSplitPane();
		splitPane.setLeftComponent(queryFileTreePanel);
		splitPane.setRightComponent(this.desktop);
		splitPane.setDividerSize(5);
		splitPane.setDividerLocation(300);
		//splitPane.setOneTouchExpandable(true);
		this.add(splitPane, BorderLayout.CENTER);
		MessageQueue.getInstance().addListener(this);
	}
	
	public synchronized void listen(Message message) {
		if (message == null) {
			return;
		}
		
		if (message instanceof ResultSetMessage) {
			ResultSetMessage resultSetMessage = (ResultSetMessage) message;
			CResultSet[] rs = resultSetMessage.getRs();
			if (rs != null && rs.length > 0 && rs[0] != null) {
				CResultSetInternalFrame frame = new CResultSetInternalFrame(rs);
				this.desktop.addFrame(frame);
			}
		} else if (message instanceof CloseAllFileAction) {
			this.desktop.closeAllFrame();
		} else if (message instanceof NewFileAction) {
			// �ű�����
			JInternalFrame f = new JInternalFrame("New", true, true, true, false);
			f.setFrameIcon(new ImageIcon("resource/image/new.gif"));
			QueryEditor editor = new QueryEditor();
			editor.setFrame(f);
			StringBuffer buffer = new StringBuffer();
			buffer.append("<?xml version=\"1.0\" encoding=\"euc-kr\"?>\n");
			buffer.append("<query>\n");	
			buffer.append("<sql>\n");
			buffer.append("<database>database</database>\n");
			buffer.append("<comment>comment</comment>\n");
			buffer.append("<reportable>false</reportable>\n");
			buffer.append("<chartable>false</chartable>\n");
			buffer.append("<queryString>\n");
			buffer.append("</queryString>\n");
			buffer.append("</sql>\n");
			buffer.append("<parameter>parameter</parameter>\n");
			buffer.append("</query>\n");
			editor.setText(buffer.toString());
			editor.setCurrentDir(this.currentDir);
			f.setContentPane(editor);
			f.setSize(400, 400);
			this.desktop.addFrame(f);
		} else if (message instanceof OpenFileMessage) {
			OpenFileMessage openFileMessage = (OpenFileMessage) message;
			String filename = openFileMessage.getFile().getAbsolutePath();
			
			String title = filename;
			int index = title.lastIndexOf(File.separator);
			if (index > 0) {
				title = title.substring(index + 1);
			}			
			JInternalFrame f = new JInternalFrame(title, true, true, true, false);
			f.setFrameIcon(new ImageIcon("resource/image/new.gif"));
			QueryEditor editor = new QueryEditor();
			editor.readFile(filename);
			editor.setFrame(f);
			f.setContentPane(editor);
			f.setSize(400, 400);
			this.desktop.addFrame(f);
		} else if (message instanceof CurrentDirMessage) {
			this.currentDir = ((CurrentDirMessage) message).getDir();
		} else if (message instanceof ExitAction) {
			System.exit(0);
		}
	}
}