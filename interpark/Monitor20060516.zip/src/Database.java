public class Database {
	private String name;
	private String url;
	private String driver;
	private String user;
	private String password;

	public Database(
		String name,
		String url,
		String driver,
		String user,
		String passwrod) {
		this.name = name;
		this.url = url;
		this.driver = driver;
		this.user = user;
		this.password = passwrod;
	}	

	public String getDriver() {
		return driver;
	}

	public String getPassword() {
		return password;
	}

	public String getUrl() {
		return url;
	}

	public String getUser() {
		return user;
	}

	public void setDriver(String string) {
		driver = string;
	}

	public void setPassword(String string) {
		password = string;
	}

	public void setUrl(String string) {
		url = string;
	}

	public void setUser(String string) {
		user = string;
	}

	public String getName() {
		return name;
	}

	public void setName(String string) {
		name = string;
	}

}
