import java.awt.BorderLayout;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

import query.*;

public class CatalogPanel extends JPanel {
	private String databaseName;

	public CatalogPanel(String databaseName) {
		this.databaseName = databaseName;
		this.setupUI();
	}

	private void setupUI() {
		ResultSet rs = null;
		try {
			Connection con = QueryExecutor.getConnection(this.databaseName);
			DatabaseMetaData metaData = con.getMetaData();
			rs = metaData.getCatalogs();
			this.setLayout(new BorderLayout());
			this.add(
				new JScrollPane(
					new ResultSetTable(
						CResultSet.instantiate(rs))),
				BorderLayout.CENTER);
		} catch (Exception e) {

		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
				}
			}
		}
	}
}
