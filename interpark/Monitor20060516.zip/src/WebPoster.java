import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class WebPoster {
	private final static String CRLF = "\r\n";

	private URL url;
	private URLConnection connector;
	private String boundary;
	private String description;
	private BufferedWriter writer;
	private BufferedReader reader;
	private StringBuffer content;
	private boolean debug = false;

	public WebPoster(String query) throws MalformedURLException {
		url = new URL(query);
		content = new StringBuffer();
	}

	public void connect() throws Exception {		
		boundary = "--------------------" + System.currentTimeMillis();

		try {
			if (!debug) {
				connector = url.openConnection();
				connector.setDoOutput(true);
				connector.setDoInput(true);
				connector.setUseCaches(false);
				connector.setRequestProperty(
					"Content-Type",
					"multipart/form-data; boundary=" + boundary);
				writer =
					new BufferedWriter(
						new OutputStreamWriter(connector.getOutputStream()));
			}
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	public void add(String name, String value) {
		content.append("--" + boundary + CRLF);
		content.append(
			"Content-Disposition: form-data; name=\""
				+ name
				+ "\""
				+ CRLF
				+ CRLF
				+ value
				+ CRLF);
	}

	public String post() {
		content.append("--" + boundary + "--" + CRLF);

		try {
			if (debug) {
				System.out.println(content);
			} else {
				writer.write(content.toString());
				writer.flush();
				writer.close();
				
				reader =
					new BufferedReader(
						new InputStreamReader(connector.getInputStream()));
				String line = "";

				StringWriter out = new StringWriter();
				while ((line = reader.readLine()) != null) {
					out.write(line + CRLF);
				}
				out.flush();
				out.close();
				reader.close();
				return out.toString();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public void setDebug(boolean debug) {
		this.debug = debug;
	}
}