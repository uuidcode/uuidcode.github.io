import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class LoadedClassesPanel extends JPanel {
	private DefaultTableModel model;
	private JTable table;

	public LoadedClassesPanel() {
		this.setupUI();
	}

	private void setupUI() {
		this.setLayout(new BorderLayout());
		this.model = new DefaultTableModel();
		this.model.addColumn("class name");
		this.model.addColumn("loaded by");
		this.model.addColumn("loaded from");
		this.table = new JTable(model);
		JScrollPane scrollPane = new JScrollPane(this.table);
		this.add(scrollPane, BorderLayout.CENTER);
		JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		JButton refreshButton = new JButton("refresh");
		refreshButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.getDataVector().removeAllElements();
				model.fireTableDataChanged();
				addRow();
			}
		});
		controlPanel.add(refreshButton);
		this.add(controlPanel, BorderLayout.NORTH);
		this.addRow();
		UIUtilities.fixColumnSize(table);
	}
	
	private void addRow() {
		final ClassLoader[] loaders = ClassScope.getCallerClassLoaderTree();
		final Class[] classes = ClassScope.getLoadedClasses(loaders);
		for (int c = 0; c < classes.length; ++c) {
			final Class cls = classes[c];
			this.model.addRow(new Object[] {cls.getName(), cls.getClassLoader().getClass().getName(), ClassScope.getClassLocation(cls)});
		}
	}
}
