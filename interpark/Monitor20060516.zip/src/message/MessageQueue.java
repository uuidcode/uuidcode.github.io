package message;
import java.util.Enumeration;
import java.util.Hashtable;

public class MessageQueue {
	private Hashtable listeners = new Hashtable();
	private static MessageQueue messageQueue = null;
	
	private MessageQueue() {		
	}
	
	public synchronized static MessageQueue getInstance() {
		if (messageQueue == null) {
			messageQueue = new MessageQueue();
		}		
		return messageQueue;		
	}
	
	public Object addListener(MessageListener object) {
		return this.listeners.put(object, object);
	}
	
	public Object removeListener(MessageListener object) {
		return this.listeners.remove(object);
	}
	
	public synchronized void sendMessage(Message message) {
		Enumeration enum = this.listeners.keys();
		while (enum.hasMoreElements()) {
			Object object = enum.nextElement();			
			if (object != null && object instanceof MessageListener) {
				MessageListener currentListener = (MessageListener) object;
				currentListener.listen(message);
			}
		}			
	}	
}