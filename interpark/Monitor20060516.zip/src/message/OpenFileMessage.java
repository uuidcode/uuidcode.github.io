package message;

import java.io.File;

public class OpenFileMessage implements Message {
	private File file;
	
	public OpenFileMessage(File file) {
		this.file = file;
	}

	public File getFile() {
		return file;
	}
}
