package message;

import java.io.File;

public class CurrentDirMessage {
	private File dir;
	
	public CurrentDirMessage(File dir) {
		this.dir = dir;
	}

	public File getDir() {
		return dir;
	}
}
