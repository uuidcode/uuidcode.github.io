package message;
public interface MessageListener {
	public void listen(Message message);	
}
