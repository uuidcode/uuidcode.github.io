package message;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ConsoleMessage implements Message {
	private Object message;
	private Date date;
	
	public ConsoleMessage(Object message) {
		this.date = new Date();
		this.message = message;
	}
	
	public String toString() {
		if (message instanceof String) {
			return new SimpleDateFormat("yyyy/MM/dd hh:mm:ss").format(this.date) + " " + message;
		} else if (message instanceof Exception) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			((Exception) message).printStackTrace(pw);
			String s = sw.toString();
			return new SimpleDateFormat("yyyy/MM/dd hh:mm:ss").format(this.date) + " " + s;
		}
		return null;
	}

	public Object getMessage() {
		return message;
	}
}
