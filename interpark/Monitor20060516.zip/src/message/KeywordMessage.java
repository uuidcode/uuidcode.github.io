package message;


public class KeywordMessage implements Message {
	private String keyword;
	private int refreshTime;
	
	public KeywordMessage(String keyword, int refreshTime) {
		this.keyword = keyword;
		this.refreshTime = refreshTime;
	}

	public String getKeyword() {
		return keyword;
	}

	public int getRefreshTime() {
		return refreshTime;
	}
}
