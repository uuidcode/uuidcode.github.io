package message;

public class HistoryFileMessage extends FileMessage {
	public HistoryFileMessage(String filename) {
		super(filename);
	}
}
