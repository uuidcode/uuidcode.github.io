package message;
import java.util.Vector;

public class HistoryMessage implements Message {
	private Vector queryVector;
	
	public HistoryMessage(Vector queryVector) {
		this.queryVector = queryVector;
	}

	public Vector getQueryVector() {
		return queryVector;
	}
}
