package message;

public class FileMessage implements Message {
	private String filename;
	
	public FileMessage(String filename) {
		this.filename = filename;
	}
	
	public String getFilename() {
		return filename;
	}
}
