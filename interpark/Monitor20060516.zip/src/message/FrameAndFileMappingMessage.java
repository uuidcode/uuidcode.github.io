package message;

import javax.swing.JInternalFrame;

public class FrameAndFileMappingMessage implements Message {
	private JInternalFrame frame;
	private String filename;
	
	public FrameAndFileMappingMessage(JInternalFrame frame, String filename) {
		this.frame = frame;
		this.filename = filename;
	}
	/**
	 * @return
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * @return
	 */
	public JInternalFrame getFrame() {
		return frame;
	}

	/**
	 * @param string
	 */
	public void setFilename(String string) {
		filename = string;
	}

	/**
	 * @param frame
	 */
	public void setFrame(JInternalFrame frame) {
		this.frame = frame;
	}

}
