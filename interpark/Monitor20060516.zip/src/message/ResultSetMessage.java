package message;

import query.CResultSet;

public class ResultSetMessage implements Message {
	private CResultSet[] rs;
	
	public ResultSetMessage(CResultSet[] rs) {
		this.rs = rs;
	}
	
	public CResultSet[] getRs() {
		return rs;
	}

}
