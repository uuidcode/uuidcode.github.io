
package action;

import javax.swing.ImageIcon;

public class CloseFileAction extends CommonAction {
	private static CloseFileAction action;
	
	private CloseFileAction() {
		super("Close All", new ImageIcon("resource/image/close.gif"));
		this.putValue(SHORT_DESCRIPTION, "Close file");
	}

	public static CloseFileAction getInstance() {
		if (action == null) {
			action = new CloseFileAction();
		}
		return action;
	}
}