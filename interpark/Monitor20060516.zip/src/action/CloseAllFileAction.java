package action;

import javax.swing.ImageIcon;

public class CloseAllFileAction extends CommonAction {
	private static CloseAllFileAction action;
	
	private CloseAllFileAction() {
		super("Close All", new ImageIcon("resource/image/closeAll.gif"));
		this.putValue(SHORT_DESCRIPTION, "Close all files");
	}

	public static CloseAllFileAction getInstance() {
		if (action == null) {
			action = new CloseAllFileAction();
		}
		return action;
	}
}