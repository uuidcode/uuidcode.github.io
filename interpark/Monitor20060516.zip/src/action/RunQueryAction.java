package action;

import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

public class RunQueryAction extends CommonAction {
	private static RunQueryAction action;
	private int sourceHashCode;

	private RunQueryAction() {
		super("Run Query", new ImageIcon("resource/image/runFromQuery.gif"));
		KeyStroke keyStroke =
			KeyStroke.getKeyStroke('Q', KeyEvent.CTRL_MASK, false);
		this.putValue(ACCELERATOR_KEY, keyStroke);
		this.putValue(SHORT_DESCRIPTION, "Run query");
	}

	public static RunQueryAction getInstance() {
		if (action == null) {
			action = new RunQueryAction();
		}
		return action;
	}
}