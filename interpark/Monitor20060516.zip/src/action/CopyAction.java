package action;

import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

public class CopyAction extends CommonAction {
	private static CopyAction action;

	private CopyAction() {
		super("Copy", new ImageIcon("resource/image/copy.gif"));
		KeyStroke keyStroke =
			KeyStroke.getKeyStroke('C', KeyEvent.CTRL_MASK, false);
		this.putValue(ACCELERATOR_KEY, keyStroke);
		this.putValue(SHORT_DESCRIPTION, "Copy");
	}

	public static CopyAction getInstance() {
		if (action == null) {
			action = new CopyAction();
		}
		return action;
	}
}