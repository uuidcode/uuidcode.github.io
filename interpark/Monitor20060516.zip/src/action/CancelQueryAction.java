package action;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

import query.QueryExecutor;

import message.Message;

public class CancelQueryAction extends AbstractAction implements Message {
	private static CancelQueryAction action;
	
	private CancelQueryAction() {
		super("Cancel", new ImageIcon("resource/image/cancel.gif"));
		KeyStroke keyStroke =
			KeyStroke.getKeyStroke(KeyEvent.VK_F11, KeyEvent.CTRL_MASK, false);
		this.putValue(ACCELERATOR_KEY, keyStroke);
		this.putValue(SHORT_DESCRIPTION, "Cancel query");
	}

	public static CancelQueryAction getInstance() {
		if (action == null) {
			action = new CancelQueryAction();
		}
		return action;
	}

	public void actionPerformed(ActionEvent e) {
		QueryExecutor.cancel();
	}
}