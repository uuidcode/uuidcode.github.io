package action;

import IExplorerRunner;

import java.awt.event.ActionEvent;
import java.io.File;

import javax.swing.AbstractAction;

import query.CResultSet;
import query.Query;
import query.QueryExecutor;

public class RunETaxAdminAction extends AbstractAction {
	private static RunETaxAdminAction action;
	private String memNo;

	private RunETaxAdminAction() {
		super("Run ETax Admin");
	}

	public static RunETaxAdminAction getInstance() {
		if (action == null) {
			action = new RunETaxAdminAction();
		}
		return action;
	}

	public void actionPerformed(ActionEvent e) {
		File file = null;

		String value = null;
		file = new File("sql/milti/���ݰ�꼭/�����ھ��̵�ΰ˻�.sql");
		if (!file.exists()) {
			return;
		}
		Query[] query = Query.getQuery(file.getAbsolutePath());
		query[0].setParameter(new String[] { this.memNo });
		CResultSet rs = QueryExecutor.getData(query[0]);
		if (rs != null && rs.next()) {
			String url ="http://e-tax.interpark.com/interpark/tax/login/login.jsp?mode=1&";
			url	+= "userid=";
			url += rs.getString("adm_id");
			url += "&passwd=";
			url += rs.getString("adm_passwd");
			IExplorerRunner runner = new IExplorerRunner(url);
			runner.run();
		}
	}

	public void setMemNo(String memNo) {
		this.memNo = memNo;
	}
}