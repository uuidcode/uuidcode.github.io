package action;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

import message.Message;
import message.MessageQueue;

public class RedoAction extends AbstractAction implements Message {
	private static RedoAction action;

	private RedoAction() {
		super("Redo", new ImageIcon("resource/image/redo.gif"));
		KeyStroke keyStroke =
			KeyStroke.getKeyStroke('Y', KeyEvent.CTRL_MASK, false);
		this.putValue(ACCELERATOR_KEY, keyStroke);
		this.putValue(SHORT_DESCRIPTION, "Redo");
	}

	public static RedoAction getInstance() {
		if (action == null) {
			action = new RedoAction();
		}
		return action;
	}

	public void actionPerformed(ActionEvent e) {
		MessageQueue.getInstance().sendMessage(this);		
	}
}