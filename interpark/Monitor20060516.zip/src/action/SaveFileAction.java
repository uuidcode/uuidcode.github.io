package action;

import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.KeyStroke;


public class SaveFileAction extends CommonAction {
	private static SaveFileAction action;

	private SaveFileAction() {
		super("Save", new ImageIcon("resource/image/save.gif"));
		KeyStroke keyStroke =
			KeyStroke.getKeyStroke('S', KeyEvent.CTRL_MASK, false);
		this.putValue(ACCELERATOR_KEY, keyStroke);
		this.putValue(SHORT_DESCRIPTION, "Save file");
	}

	public static SaveFileAction getInstance() {
		if (action == null) {
			action = new SaveFileAction();
		}
		return action;
	}
}