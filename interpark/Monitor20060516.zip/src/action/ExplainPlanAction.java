package action;

import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

public class ExplainPlanAction extends CommonAction {
	private static ExplainPlanAction action;
	private int sourceHashCode;

	private ExplainPlanAction() {
		super("Explain", new ImageIcon("resource/image/explain.gif"));
		KeyStroke keyStroke =
			KeyStroke.getKeyStroke('E', KeyEvent.CTRL_MASK, false);
		this.putValue(ACCELERATOR_KEY, keyStroke);
		this.putValue(SHORT_DESCRIPTION, "Explain Plan");
	}

	public static ExplainPlanAction getInstance() {
		if (action == null) {
			action = new ExplainPlanAction();
		}
		return action;
	}
}