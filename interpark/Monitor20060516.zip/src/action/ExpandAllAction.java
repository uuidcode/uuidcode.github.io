package action;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

import message.Message;
import message.MessageQueue;

public class ExpandAllAction extends AbstractAction implements Message {
	private static ExpandAllAction action;

	private ExpandAllAction() {
		super("Expand All");
	}

	public static ExpandAllAction getInstance() {
		if (action == null) {
			action = new ExpandAllAction();
		}
		return action;
	}

	public void actionPerformed(ActionEvent e) {
		MessageQueue.getInstance().sendMessage(this);
	}
}