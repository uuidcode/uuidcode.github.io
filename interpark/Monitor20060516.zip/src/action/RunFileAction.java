package action;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

import message.Message;
import message.MessageQueue;

public class RunFileAction extends AbstractAction implements Message {
	private static RunFileAction action;

	private RunFileAction() {
		super("Run", new ImageIcon("resource/image/run.gif"));
		KeyStroke keyStroke =
			KeyStroke.getKeyStroke('R', KeyEvent.CTRL_MASK, false);
		this.putValue(ACCELERATOR_KEY, keyStroke);
		this.putValue(SHORT_DESCRIPTION, "Run file");
	}

	public static RunFileAction getInstance() {
		if (action == null) {
			action = new RunFileAction();
		}
		return action;
	}

	public void actionPerformed(ActionEvent e) {
		MessageQueue.getInstance().sendMessage(this);
	}
}