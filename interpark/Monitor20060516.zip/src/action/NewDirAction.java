
package action;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

import message.Message;
import message.MessageQueue;

public class NewDirAction extends AbstractAction implements Message {
	private static NewDirAction action;

	private NewDirAction() {
		super("New Dir", new ImageIcon("resource/image/newDir.gif"));
		KeyStroke keyStroke =
			KeyStroke.getKeyStroke('M', KeyEvent.CTRL_MASK, false);
		this.putValue(ACCELERATOR_KEY, keyStroke);
		this.putValue(SHORT_DESCRIPTION, "New directory");
	}

	public static NewDirAction getInstance() {
		if (action == null) {
			action = new NewDirAction();
		}
		return action;
	}

	public void actionPerformed(ActionEvent e) {
		MessageQueue.getInstance().sendMessage(this);
	}
}
