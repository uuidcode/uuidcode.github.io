package action;

public class ExitAction extends CommonAction {
	private static ExitAction action;

	private ExitAction() {
		super("Exit");
		this.putValue(SHORT_DESCRIPTION, "Exit");
	}

	public static ExitAction getInstance() {
		if (action == null) {
			action = new ExitAction();
		}
		return action;
	}
}