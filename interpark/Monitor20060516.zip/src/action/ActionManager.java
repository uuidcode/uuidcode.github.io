package action;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import javax.swing.Action;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JToolBar;

public class ActionManager {
	private static Hashtable menuInfo = new Hashtable();

	static {
		menuInfo.put("File", ActionManager.getFileActions());
		menuInfo.put("Edit", ActionManager.getEditAction());
		menuInfo.put("Query", ActionManager.getQueryAction());
		menuInfo.put("Etc", ActionManager.getEtcAction());
	}

	public static JMenuBar getMenuBar() {
		JMenuBar menuBar = new JMenuBar();
		Enumeration enum = menuInfo.keys();
		while (enum.hasMoreElements()) {
			Object key = enum.nextElement();
			if (key != null) {
				Action[] action = (Action[]) menuInfo.get(key);
				JMenu menu = new JMenu(key.toString());
				for (int i = 0; i < action.length; i++) {
					menu.add(action[i]);
				}
				menuBar.add(menu);
			}
		}
		return menuBar;
	}
	
	public static JToolBar getToolBar() {
		JToolBar toolbar = new JToolBar();
		Enumeration enum = menuInfo.keys();
		while (enum.hasMoreElements()) {
			Object key = enum.nextElement();
			if (key != null) {
				Action[] action = (Action[]) menuInfo.get(key);
				for (int i = 0; i < action.length; i++) {
					toolbar.add(action[i]);
				}
				toolbar.addSeparator();
			}
		}
		return toolbar;
	}	

	private static Action[] getFileActions() {
		Vector menu = new Vector();
		menu.add(NewFileAction.getInstance());
		menu.add(NewDirAction.getInstance());
		menu.add(SaveFileAction.getInstance());
		menu.add(SaveAsFileAction.getInstance());
		menu.add(CloseFileAction.getInstance());
		menu.add(CloseAllFileAction.getInstance());
		menu.add(ExitAction.getInstance());
		return (Action[]) menu.toArray(new Action[0]);
	}

	private static Action[] getQueryAction() {
		Vector menu = new Vector();
		menu.add(RunFileAction.getInstance());
		menu.add(RunQueryAction.getInstance());
		menu.add(ExplainPlanAction.getInstance());
		menu.add(CancelQueryAction.getInstance());
		return (Action[]) menu.toArray(new Action[0]);
	}

	private static Action[] getEditAction() {
		Vector menu = new Vector();
		menu.add(CutAction.getInstance());
		menu.add(CopyAction.getInstance());
		menu.add(PasteAction.getInstance());
		menu.add(UndoAction.getInstance());
		menu.add(RedoAction.getInstance());
		return (Action[]) menu.toArray(new Action[0]);
	}

	private static Action[] getEtcAction() {
		Vector menu = new Vector();
		menu.add(MonitorETaxAction.getInstance());
		menu.add(ReportAction.getInstance());
		menu.add(ArrangeFrameAction.getInstance());
		return (Action[]) menu.toArray(new Action[0]);
	}
}
