package action;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;

import message.Message;
import message.MessageQueue;

import query.JMenuItemEx;
import query.QueryStylePane;

public class CommonAction extends AbstractAction implements Message {
	private int sourceHashCode;

	public CommonAction(String name) {
		super(name);
	}

	public CommonAction(String name, ImageIcon icon) {
		super(name, icon);
	}

	public void actionPerformed(ActionEvent e) {
		Object object = e.getSource();
		if (object instanceof QueryStylePane) {
			this.sourceHashCode = ((QueryStylePane) object).hashCode();
		} else if (object instanceof JMenuItemEx) {
			object = ((JMenuItemEx) object).getInfo();
			if (object != null && object instanceof QueryStylePane) {
				this.sourceHashCode = ((QueryStylePane) object).hashCode();
			} else {
				this.sourceHashCode = -1;
			}
		}

		MessageQueue.getInstance().sendMessage(this);
	}

	public int getSourceHashCode() {
		return sourceHashCode;
	}
}
