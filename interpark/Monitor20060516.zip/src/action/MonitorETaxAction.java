package action;

import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.net.Socket;
import java.util.Vector;

import query.CResultSet;
import query.Query;

import message.ConsoleMessage;
import message.Message;
import message.MessageListener;
import message.MessageQueue;
import message.ResultSetMessage;

public class MonitorETaxAction extends CommonAction implements MessageListener {
	private static MonitorETaxAction action;
	private static final String SERVER_GET =
		"GET /interpark/tax/admin/TaxA_issueAuto.jsp HTTP/1.0\r\n";
	private static final String LOGIN_GET =
		"GET /interpark/tax/login/login.jsp?userid=Supervisor&passwd=!@qw HTTP/1.0\r\n\r\n";
	private static final String ETAX1 = "211.233.74.83";
	private static final String ETAX2 = "211.233.74.86";
	private static final String ID = "Supervisor";
	private static final String PASSWORD = "!@qw";
	private static final int TIME_OUT = 1000 * 10;

	private MonitorETaxAction() {
		super("Monitor ETax");
		MessageQueue.getInstance().addListener(this);
	}

	public static MonitorETaxAction getInstance() {
		if (action == null) {
			action = new MonitorETaxAction();
		}
		return action;
	}

	public void actionPerformed(ActionEvent e) {
		this.report();
	}

	private String login(String server) {
		String cookie = null;
		Socket socket = null;
		OutputStreamWriter writer = null;
		BufferedReader reader = null;
		StringWriter out = null;
		try {
			socket = new Socket(server, 80);
			socket.setSoTimeout(TIME_OUT);
			writer = new OutputStreamWriter(socket.getOutputStream());
			writer.write(LOGIN_GET);
			writer.flush();

			MessageQueue.getInstance().sendMessage(
				new ConsoleMessage("login " + server));
			MessageQueue.getInstance().sendMessage(
				new ConsoleMessage("GET " + server));

			reader =
				new BufferedReader(
					new InputStreamReader(socket.getInputStream()));
			String line = "";

			out = new StringWriter();
			while ((line = reader.readLine()) != null) {
				if (line.startsWith("Set-Cookie")) {
					cookie = line.substring(11);
				}
				out.write(line + "\r\n");

			}
			return cookie;
		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
		} finally {
			if (out != null) {
				try {
					out.flush();
					out.close();
				} catch (Exception e) {

				}
			}

			if (writer != null) {
				try {
					writer.close();
				} catch (Exception e) {

				}
			}

			if (reader != null) {
				try {
					reader.close();
				} catch (Exception e) {

				}
			}

			if (socket != null) {
				try {
					socket.close();
				} catch (Exception e) {

				}
			}
		}
		return null;
	}

	private String getData(String server, String cookie) {
		Socket socket = null;
		OutputStreamWriter writer = null;
		BufferedReader reader = null;
		StringWriter out = null;
		try {
			socket = new Socket(server, 80);
			socket.setSoTimeout(TIME_OUT);
			writer = new OutputStreamWriter(socket.getOutputStream());
			writer.write(SERVER_GET);
			writer.write("Cookie: " + cookie + "\r\n\r\n");
			writer.flush();

			MessageQueue.getInstance().sendMessage(
				new ConsoleMessage("get data " + server));
			MessageQueue.getInstance().sendMessage(
				new ConsoleMessage("GET " + SERVER_GET));

			reader =
				new BufferedReader(
					new InputStreamReader(socket.getInputStream()));
			String line = "";

			out = new StringWriter();
			while ((line = reader.readLine()) != null) {
				out.write(line + "\r\n");
			}
			return out.toString();
		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
		} finally {
			if (out != null) {
				try {
					out.flush();
					out.close();
				} catch (Exception e) {

				}
			}

			if (writer != null) {
				try {
					writer.close();
				} catch (Exception e) {

				}
			}

			if (reader != null) {
				try {
					reader.close();
				} catch (Exception e) {

				}
			}

			if (socket != null) {
				try {
					socket.close();
				} catch (Exception e) {

				}
			}
		}
		return null;
	}

	private boolean isAlive(String server) {
		try {
			String cookie = this.login(server);
			return this.getData(server, cookie).indexOf(
				"<font class=\"sf9\" color=\"#0066CC\">�۵���")
				> 0;
		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
		}
		return false;

	}

	public void report() {
		Vector rows = new Vector();
		Vector data = new Vector();
		String[] columnName = { "server", "stat" };
		data.add(ETAX1);
		data.add(new Boolean(this.isAlive(ETAX1)));
		rows.add(data);
		data = new Vector();
		data.add(ETAX2);
		data.add(new Boolean(this.isAlive(ETAX2)));
		rows.add(data);
		try {
			CResultSet rs = new CResultSet(columnName, rows);
			rs.setQuery(
				new Query(true, false, null, null, null, null, "eTax�ڵ��߱޼�������"));
			MessageQueue.getInstance().sendMessage(
				new ResultSetMessage(new CResultSet[] { rs }));
		} catch (Exception e) {
		}
	}

	public void listen(Message message) {
		if (message == null) {
			return;
		}
		
		if (message instanceof ReportAction) {
			new Thread() {
				public void run() {
					report();
				}			
			}.start();	
		}		
	}
}