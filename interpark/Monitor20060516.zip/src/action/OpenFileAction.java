package action;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

import message.Message;
import message.MessageQueue;

public class OpenFileAction extends AbstractAction implements Message {
	private static OpenFileAction action;
	
	private OpenFileAction() {
		super("Open", new ImageIcon("resource/image/open.gif"));
		KeyStroke keyStroke =
			KeyStroke.getKeyStroke('O', KeyEvent.CTRL_MASK, false);
		this.putValue(ACCELERATOR_KEY, keyStroke);
		this.putValue(SHORT_DESCRIPTION, "Open file");
	}
	
	public static OpenFileAction getInstance() {
		if (action == null) {
			action = new OpenFileAction();
		}
		return action;
	}
	
	public void actionPerformed(ActionEvent e) {
		MessageQueue.getInstance().sendMessage(this);
	}
}