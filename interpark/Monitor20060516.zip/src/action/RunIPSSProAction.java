package action;

import IExplorerRunner;

import java.awt.event.ActionEvent;
import java.io.File;

import javax.swing.AbstractAction;

import query.CResultSet;
import query.Query;
import query.QueryExecutor;

public class RunIPSSProAction extends AbstractAction {
	private static RunIPSSProAction action;
	private String memNo;
	
	private RunIPSSProAction() {
		super("Run IPSSPRO");
	}
	
	public static RunIPSSProAction getInstance() {
		if (action == null) {
			action = new RunIPSSProAction();
		}
		return action;
	}
	
	public void actionPerformed(ActionEvent e) {
		File file = null;
			
		String value = null;
		try {
			Long.parseLong(this.memNo);
			file = new File("sql/milti/ȸ��/ȸ����ȣ�ΰ˻�.sql");
		} catch (Exception ex){
			file = new File("sql/milti/ȸ��/ȸ�����̵�ΰ˻�.sql");
		}
	
		if (!file.exists()) {
			return;
		}
		Query[] query = Query.getQuery(file.getAbsolutePath());
		query[0].setParameter(new String[] {this.memNo});
		CResultSet rs = QueryExecutor.getData(query[0]);
		if (rs != null && rs.next()) {
			String url = "http://www.interpark.com/stdservice/ipssCheckLogin.do?";
			url	+= "_method=checkLogin&style=ipssPro&sc.useAppTp=02&sc.isIpss=Y&sc.memId=";
			url += rs.getString("���̵�");
			url += "&sc.pwd=";
			url += rs.getString("��й�ȣ");
			IExplorerRunner runner = new IExplorerRunner(url);
			runner.run();
		}
	}
	
	public void setMemNo(String memNo) {
		this.memNo = memNo;
	}
}