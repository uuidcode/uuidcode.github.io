package action;

import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

public class PasteAction extends CommonAction {
	private static PasteAction action;
	
	private PasteAction() {
		super("Paste", new ImageIcon("resource/image/paste.gif"));
		KeyStroke keyStroke =
			KeyStroke.getKeyStroke('P', KeyEvent.CTRL_MASK, false);
		this.putValue(ACCELERATOR_KEY, keyStroke);
		this.putValue(SHORT_DESCRIPTION, "Paste");
	}

	public static PasteAction getInstance() {
		if (action == null) {
			action = new PasteAction();
		}
		return action;
	}
}