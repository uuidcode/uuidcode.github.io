package action;

import IExplorerRunner;

import java.awt.event.ActionEvent;
import java.io.File;

import javax.swing.AbstractAction;

import query.CResultSet;
import query.Query;
import query.QueryExecutor;

public class RunETaxTestAction extends AbstractAction {
	private static RunETaxTestAction action;
	private String memNo;
	private String url ="http://e-tax.interpark.com/interpark/view/index.jsp?";
	
	private RunETaxTestAction() {
		super("Run �׽�Ʈ���� ETax ������ȸ����ȣ��");
	}

	public static RunETaxTestAction getInstance() {
		if (action == null) {
			action = new RunETaxTestAction();
		}
		return action;
	}

	public void actionPerformed(ActionEvent e) {
		File file = null;

		String value = null;
		file = new File("sql/milti/��ü/��ü������_ȸ����ȣ�ΰ˻�.sql");
		if (!file.exists()) {
			return;
		}
		Query[] query = Query.getQuery(file.getAbsolutePath());
		query[0].setParameter(new String[] { this.memNo });
		CResultSet rs = QueryExecutor.getData(query[0]);
		if (rs != null && rs.next()) {
			String url ="http://e-taxtest.interpark.com/interpark/view/index.jsp?";
			url	+= "regno=";
			url += rs.getString("����ڹ�ȣ");
			url += "&loginid=";
			url += rs.getString("ȸ����ȣ");
			url += "&conm=";
			url += rs.getString("��ü��");
			url += "&shop_no=";
			url += rs.getString("����ȣ");
			url += "&entr_no=";
			url += rs.getString("��ü��ȣ");
			IExplorerRunner runner = new IExplorerRunner(url);
			runner.run();
		}
	}

	public void setMemNo(String memNo) {
		this.memNo = memNo;
	}
}