package action;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

import message.Message;
import message.MessageQueue;

public class DeleteFileAction extends AbstractAction implements Message {
	private static DeleteFileAction action;

	private DeleteFileAction() {
		super("Delete", new ImageIcon("resource/image/delete.gif"));
		KeyStroke keyStroke =
			KeyStroke.getKeyStroke('D', KeyEvent.CTRL_MASK, false);
		this.putValue(ACCELERATOR_KEY, keyStroke);
		this.putValue(SHORT_DESCRIPTION, "Delete file");
	}

	public static DeleteFileAction getInstance() {
		if (action == null) {
			action = new DeleteFileAction();
		}
		return action;
	}

	public void actionPerformed(ActionEvent e) {
		MessageQueue.getInstance().sendMessage(this);
	}
}
