package action;

import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.KeyStroke;


public class CutAction extends CommonAction {
	private static CutAction action;
	
	private CutAction() {
		super("Cut", new ImageIcon("resource/image/cut.gif"));
		KeyStroke keyStroke =
			KeyStroke.getKeyStroke('X', KeyEvent.CTRL_MASK, false);
		this.putValue(ACCELERATOR_KEY, keyStroke);
		this.putValue(SHORT_DESCRIPTION, "Cut");
	}

	public static CutAction getInstance() {
		if (action == null) {
			action = new CutAction();
		}
		return action;
	}
}