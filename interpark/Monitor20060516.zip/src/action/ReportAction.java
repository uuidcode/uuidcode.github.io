package action;

import java.awt.event.ActionEvent;

import message.MessageQueue;

public class ReportAction extends CommonAction {
	private static ReportAction action;
	
	private ReportAction() {
		super("Report");
	}

	public static ReportAction getInstance() {
		if (action == null) {
			action = new ReportAction();
		}
		return action;
	}

	public void actionPerformed(ActionEvent e) {
		MessageQueue.getInstance().sendMessage(this);
	}

}