package action;

import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.KeyStroke;


public class SaveAsFileAction extends CommonAction {
	private static SaveAsFileAction action;
		
	private SaveAsFileAction() {
		super("Save As", new ImageIcon("resource/image/saveAs.gif"));
		KeyStroke keyStroke =
			KeyStroke.getKeyStroke(KeyEvent.VK_F12, KeyEvent.CTRL_MASK, false);
		this.putValue(ACCELERATOR_KEY, keyStroke);
		this.putValue(SHORT_DESCRIPTION, "Save as file");
	}

	public static SaveAsFileAction getInstance() {
		if (action == null) {
			action = new SaveAsFileAction();
		}
		return action;
	}
}