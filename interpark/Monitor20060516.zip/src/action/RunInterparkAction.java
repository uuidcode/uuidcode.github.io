package action;

import IExplorerRunner;

import java.awt.event.ActionEvent;
import java.io.File;

import javax.swing.AbstractAction;

import query.CResultSet;
import query.Query;
import query.QueryExecutor;

public class RunInterparkAction extends AbstractAction {
	private static RunInterparkAction action;
	private String memNo;

	private RunInterparkAction() {
		super("Run Interpark");
	}

	public static RunInterparkAction getInstance() {
		if (action == null) {
			action = new RunInterparkAction();
		}
		return action;
	}

	public void actionPerformed(ActionEvent e) {
		File file = null;

		String value = null;
		try {
			Long.parseLong(this.memNo);
			file = new File("sql/milti/ȸ��/ȸ����ȣ�ΰ˻�.sql");
		} catch (Exception ex) {
			file = new File("sql/milti/ȸ��/ȸ�����̵�ΰ˻�.sql");
		}

		if (!file.exists()) {
			return;
		}
		Query[] query = Query.getQuery(file.getAbsolutePath());
		query[0].setParameter(new String[] { this.memNo });
		CResultSet rs = QueryExecutor.getData(query[0]);
		if (rs != null && rs.next()) {
			String url ="https://www.interpark.com/member/login.do?_method=login&_style=imfs&paramMethod=GET&";
			url	+= "sc.memId=";
			url += rs.getString("���̵�");
			url += "&sc.pwd=";
			url += rs.getString("��й�ȣ");
			IExplorerRunner runner = new IExplorerRunner(url);
			runner.run();
		}
	}

	public void setMemNo(String memNo) {
		this.memNo = memNo;
	}
}