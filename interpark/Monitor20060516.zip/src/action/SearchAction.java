package action;

import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

public class SearchAction extends CommonAction {
	private static SearchAction action;

	private SearchAction() {
		super("Search", new ImageIcon("resource/image/cut.gif"));
		KeyStroke keyStroke =
			KeyStroke.getKeyStroke('X', KeyEvent.CTRL_MASK, false);
		this.putValue(ACCELERATOR_KEY, keyStroke);
		this.putValue(SHORT_DESCRIPTION, "Search");
	}

	public static SearchAction getInstance() {
		if (action == null) {
			action = new SearchAction();
		}
		return action;
	}
}