package action;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

import message.Message;
import message.MessageQueue;

public class CollapseAllAction extends AbstractAction implements Message {
	private static CollapseAllAction action;

	private CollapseAllAction() {
		super("Collaspe All");
	}

	public static CollapseAllAction getInstance() {
		if (action == null) {
			action = new CollapseAllAction();
		}
		return action;
	}

	public void actionPerformed(ActionEvent e) {
		MessageQueue.getInstance().sendMessage(this);
	}
}