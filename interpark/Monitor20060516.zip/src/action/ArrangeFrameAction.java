package action;

public class ArrangeFrameAction extends CommonAction {
	private static ArrangeFrameAction action;
	
	private ArrangeFrameAction() {
		super("Arrange");
	}

	public static ArrangeFrameAction getInstance() {
		if (action == null) {
			action = new ArrangeFrameAction();
		}
		return action;
	}
}