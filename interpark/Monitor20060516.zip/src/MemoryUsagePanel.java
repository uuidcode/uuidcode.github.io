import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.ui.RectangleInsets;

public class MemoryUsagePanel extends JPanel {
	private TimeSeries total;
	private TimeSeries current;

	public MemoryUsagePanel() {
		super(new BorderLayout());
		total =
			new TimeSeries("Total Memory", org.jfree.data.time.Second.class);
		current = new TimeSeries("Current Memory", org.jfree.data.time.Second.class);

		TimeSeriesCollection timeseriescollection = new TimeSeriesCollection();
		timeseriescollection.addSeries(total);
		timeseriescollection.addSeries(current);
		DateAxis dateaxis = new DateAxis("Time");
		NumberAxis numberaxis = new NumberAxis("Memory(MBytes)");
		XYLineAndShapeRenderer xylineandshaperenderer =
			new XYLineAndShapeRenderer(true, false);
		xylineandshaperenderer.setSeriesPaint(0, Color.red);
		xylineandshaperenderer.setSeriesPaint(1, Color.green);
		xylineandshaperenderer.setStroke(new BasicStroke(3F, 0, 2));
		XYPlot xyplot =
			new XYPlot(
				timeseriescollection,
				dateaxis,
				numberaxis,
				xylineandshaperenderer);
		xyplot.setBackgroundPaint(Color.lightGray);
		xyplot.setDomainGridlinePaint(Color.white);
		xyplot.setRangeGridlinePaint(Color.white);
		xyplot.setAxisOffset(new RectangleInsets(5D, 5D, 5D, 5D));
		dateaxis.setAutoRange(true);
		dateaxis.setLowerMargin(0.0D);
		dateaxis.setUpperMargin(0.0D);
		dateaxis.setTickLabelsVisible(true);
		numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
		JFreeChart jfreechart =
			new JFreeChart(
				"JVM Memory Usage",
				new Font("SansSerif", 1, 24),
				xyplot,
				true);
		jfreechart.setBackgroundPaint(Color.white);
		ChartPanel chartpanel = new ChartPanel(jfreechart);
		chartpanel.setBorder(
			BorderFactory.createCompoundBorder(
				BorderFactory.createEmptyBorder(4, 4, 4, 4),
				BorderFactory.createLineBorder(Color.black)));
		add(chartpanel);

		new Thread() {
			public void run() {
				while (true) {
					Runtime runtime = Runtime.getRuntime();
					total.add(
						new Second(),
						runtime.totalMemory() / 1024 / 1024);
					current.add(new Second(), (runtime.totalMemory() - runtime.freeMemory()) / 1024 / 1024);

					try {
						Thread.sleep(1000);
					} catch (Exception e) {
					}
				}
			}
		}
		.start();
	}
}