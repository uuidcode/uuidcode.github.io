import java.lang.reflect.InvocationTargetException;

import javax.swing.SwingUtilities;
import javax.swing.table.AbstractTableModel;

public class ThreadViewerTableModel extends AbstractTableModel {
	private Object dataLock;
	private int rowCount;
	private Object[][] cellData;
	private Object[][] pendingCellData;

	private final int columnCount;
	private final String[] columnName;
	private final Class[] columnClass;

	private Thread internalThread;
	private volatile boolean noStopRequest;

	public ThreadViewerTableModel() {
		rowCount = 0;
		cellData = new Object[0][0];

		String[] name =
			{
				"Thread Name",
				"Priority",
				"Alive",
				"Daemon",
				"Interrupted",
				"Thread Group"
				 };
		columnName = name;

		Class[] classes =
			{
				String.class,
				Integer.class,
				Boolean.class,
				Boolean.class,
				Boolean.class,
				String.class};
		columnClass = classes;

		columnCount = columnName.length;
		dataLock = new Object();

		noStopRequest = true;

		Runnable r = new Runnable() {
			public void run() {
				try {
					runWork();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		};

		internalThread = new Thread(r, "ThreadViewer");
		internalThread.setPriority(Thread.MAX_PRIORITY - 1);
		internalThread.setDaemon(true);
		internalThread.start();
	}

	private void runWork() {
		Runnable transferPending = new Runnable() {
			public void run() {
				transferPendingCellData();
				fireTableDataChanged();
			}
		};

		while (noStopRequest) {
			try {
				createPendingCellData();
				SwingUtilities.invokeAndWait(transferPending);
				Thread.sleep(5000);
			} catch (InvocationTargetException e) {
				e.printStackTrace();
				stopRequest();
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}
	}

	public void stopRequest() {
		noStopRequest = false;
		Thread.interrupted();
	}

	public boolean isAlive() {
		return internalThread.isAlive();
	}

	private void createPendingCellData() {
		Thread[] thread = findAllThreads();
		Object[][] cell = new Object[thread.length][columnCount];

		for (int i = 0; i < thread.length; i++) {
			Thread t = thread[i];
			Object[] rowCell = cell[i];

			rowCell[0] = t.getName();
			rowCell[1] = new Integer(t.getPriority());
			rowCell[2] = new Boolean(t.isAlive());
			rowCell[3] = new Boolean(t.isDaemon());
			rowCell[4] = new Boolean(t.isInterrupted());
			rowCell[5] = t.getThreadGroup().getName();
		}

		synchronized (dataLock) {
			pendingCellData = cell;
		}
	}

	private void transferPendingCellData() {
		synchronized (dataLock) {
			cellData = pendingCellData;
			rowCount = cellData.length;
		}
	}

	public int getRowCount() {
		return rowCount;
	}

	public Object getValueAt(int row, int col) {
		return cellData[row][col];
	}

	public int getColumnCount() {
		return columnCount;
	}

	public Class getClumnClass(int columnIdx) {
		return columnClass[columnIdx];
	}

	public String getColumnName(int columnIdx) {
		return columnName[columnIdx];
	}

	public static Thread[] findAllThreads() {
		ThreadGroup group = Thread.currentThread().getThreadGroup();
		ThreadGroup topGroup = group;

		while (group != null) {
			topGroup = group;
			group = group.getParent();
		}

		int estimatedSize = topGroup.activeCount() * 2;
		Thread[] slackList = new Thread[estimatedSize];

		int actualSize = topGroup.enumerate(slackList);
		Thread list[] = new Thread[actualSize];
		System.arraycopy(slackList, 0, list, 0, actualSize);
		return list;
	}
}
