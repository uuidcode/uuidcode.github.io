import java.awt.Container;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;

import javax.swing.JTable;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

public class UIUtilities {
	public static Frame getFrame(Container container) {
		while (true) {
			if (container instanceof Frame) {
				return (Frame) container;
			}
			container = container.getParent();
			if (container == null) {
				break;
			}
		}

		return null;
	}

	public static void fixColumnSize(final JTable table) {
		new Thread() {
			public void run() {
				TableColumnModel model = table.getColumnModel();
				TableModel tableModel = table.getModel();
				int rowCount = tableModel.getRowCount();
				int columnCount = tableModel.getColumnCount();

				Graphics g = table.getGraphics();
				while (g == null) {
					g = table.getGraphics();
					try {
						Thread.sleep(1000);
					} catch (Exception e) {
					}
				}

				for (int i = 0; i < columnCount; i++) {
					int maxWidth = 40;
					FontMetrics metrics = g.getFontMetrics();
					int width =
						metrics.stringWidth(
							table
								.getColumnModel()
								.getColumn(i)
								.getIdentifier()
								.toString());
					if (width > maxWidth) {
						maxWidth = width;
					}

					for (int j = 0; j < rowCount; j++) {
						Object valueObject = tableModel.getValueAt(j, i);
						if (valueObject != null) {
							String value = valueObject.toString();
							width = metrics.stringWidth(value);
							if (width > maxWidth) {
								maxWidth = width;
							}
						}
					}
					model.getColumn(i).setPreferredWidth(maxWidth + 10);
				}
			}
		}
		.start();
	}
}
