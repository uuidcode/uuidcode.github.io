import java.awt.BorderLayout;
import java.sql.Connection;
import java.sql.DatabaseMetaData;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import query.QueryExecutor;

public class DatabaseMetaDataPanel extends JPanel {
	private String databaseName;

	public DatabaseMetaDataPanel(String databaseName) {
		this.databaseName = databaseName;
		this.setupUI();
	}

	private void setupUI() {
		try {
			Connection con = QueryExecutor.getConnection(this.databaseName);
			DatabaseMetaData metaData = con.getMetaData();
			PropertyTableModel tableModel = new PropertyTableModel();
			JTable table = new JTable(tableModel);
			this.setLayout(new BorderLayout());
			this.add(new JScrollPane(table));
			
			try {
				tableModel.addRow(
					"allProceduresAreCallable",
					metaData.allProceduresAreCallable());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"allTablesAreSelectable",
					metaData.allTablesAreSelectable());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"dataDefinitionCausesTransactionCommit",
					metaData.dataDefinitionCausesTransactionCommit());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"dataDefinitionIgnoredInTransactions",
					metaData.dataDefinitionIgnoredInTransactions());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"doesMaxRowSizeIncludeBlobs",
					metaData.doesMaxRowSizeIncludeBlobs());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getCatalogSeparator",
					metaData.getCatalogSeparator());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow("getCatalogTerm", metaData.getCatalogTerm());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getDatabaseMajorVersion",
					metaData.getDatabaseMajorVersion());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getDatabaseMinorVersion",
					metaData.getDatabaseMinorVersion());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getDatabaseProductName",
					metaData.getDatabaseProductName());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getDatabaseProductVersion",
					metaData.getDatabaseProductVersion());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getDefaultTransactionIsolation",
					metaData.getDefaultTransactionIsolation());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getDriverMajorVersion",
					metaData.getDriverMajorVersion());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getDriverMinorVersion",
					metaData.getDriverMinorVersion());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow("getDriverName", metaData.getDriverName());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getDriverVersion",
					metaData.getDriverVersion());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getExtraNameCharacters",
					metaData.getExtraNameCharacters());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getIdentifierQuoteString",
					metaData.getIdentifierQuoteString());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getJDBCMajorVersion",
					metaData.getJDBCMajorVersion());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getJDBCMajorVersion",
					metaData.getJDBCMinorVersion());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxBinaryLiteralLength",
					metaData.getMaxBinaryLiteralLength());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxCatalogNameLength",
					metaData.getMaxCatalogNameLength());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxCharLiteralLength",
					metaData.getMaxCharLiteralLength());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxColumnNameLength",
					metaData.getMaxColumnNameLength());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxColumnsInGroupBy",
					metaData.getMaxColumnsInGroupBy());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxColumnsInIndex",
					metaData.getMaxColumnsInIndex());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxColumnsInOrderBy",
					metaData.getMaxColumnsInOrderBy());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxColumnsInSelect",
					metaData.getMaxColumnsInSelect());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxColumnsInTable",
					metaData.getMaxColumnsInTable());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxConnections",
					metaData.getMaxConnections());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxCursorNameLength",
					metaData.getMaxCursorNameLength());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxIndexLength",
					metaData.getMaxIndexLength());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxProcedureNameLength",
					metaData.getMaxProcedureNameLength());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow("getMaxRowSize", metaData.getMaxRowSize());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxSchemaNameLength",
					metaData.getMaxSchemaNameLength());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxStatementLength",
					metaData.getMaxStatementLength());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxStatements",
					metaData.getMaxStatements());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxTableNameLength",
					metaData.getMaxTableNameLength());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxTablesInSelect",
					metaData.getMaxTablesInSelect());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getMaxUserNameLength",
					metaData.getMaxUserNameLength());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getNumericFunctions",
					metaData.getNumericFunctions());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getProcedureTerm",
					metaData.getProcedureTerm());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getResultSetHoldability",
					metaData.getResultSetHoldability());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow("getSchemaTerm", metaData.getSchemaTerm());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getSearchStringEscape",
					metaData.getSearchStringEscape());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow("getSQLKeywords", metaData.getSQLKeywords());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getSQLStateType",
					metaData.getSQLStateType());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getStringFunctions",
					metaData.getStringFunctions());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getSystemFunctions",
					metaData.getSystemFunctions());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"getTimeDateFunctions",
					metaData.getTimeDateFunctions());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow("getURL", metaData.getURL());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow("getUserName", metaData.getUserName());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"isCatalogAtStart",
					metaData.isCatalogAtStart());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow("isReadOnly", metaData.isReadOnly());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"locatorsUpdateCopy",
					metaData.locatorsUpdateCopy());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"nullPlusNonNullIsNull",
					metaData.nullPlusNonNullIsNull());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"nullsAreSortedAtEnd",
					metaData.nullsAreSortedAtEnd());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"nullsAreSortedAtStart",
					metaData.nullsAreSortedAtStart());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"nullsAreSortedHigh",
					metaData.nullsAreSortedHigh());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"nullsAreSortedLow",
					metaData.nullsAreSortedLow());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"storesLowerCaseIdentifiers",
					metaData.storesLowerCaseIdentifiers());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"storesLowerCaseQuotedIdentifiers",
					metaData.storesLowerCaseQuotedIdentifiers());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"storesMixedCaseIdentifiers",
					metaData.storesMixedCaseIdentifiers());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsAlterTableWithAddColumn",
					metaData.supportsAlterTableWithAddColumn());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsAlterTableWithDropColumn",
					metaData.supportsAlterTableWithDropColumn());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsANSI92EntryLevelSQL",
					metaData.supportsANSI92EntryLevelSQL());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsANSI92FullSQL",
					metaData.supportsANSI92FullSQL());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsANSI92IntermediateSQL",
					metaData.supportsANSI92IntermediateSQL());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsBatchUpdates",
					metaData.supportsBatchUpdates());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsCatalogsInDataManipulation",
					metaData.supportsCatalogsInDataManipulation());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsCatalogsInIndexDefinitions",
					metaData.supportsCatalogsInIndexDefinitions());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsCatalogsInPrivilegeDefinitions",
					metaData.supportsCatalogsInPrivilegeDefinitions());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsCatalogsInProcedureCalls",
					metaData.supportsCatalogsInProcedureCalls());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsCatalogsInTableDefinitions",
					metaData.supportsCatalogsInTableDefinitions());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsColumnAliasing",
					metaData.supportsColumnAliasing());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsConvert",
					metaData.supportsConvert());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsCorrelatedSubqueries",
					metaData.supportsCoreSQLGrammar());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsDataDefinitionAndDataManipulationTransactions",
					metaData.supportsCorrelatedSubqueries());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsDataManipulationTransactionsOnly",
					metaData
						.supportsDataDefinitionAndDataManipulationTransactions());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsDifferentTableCorrelationNames",
					metaData.supportsDataManipulationTransactionsOnly());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsExpressionsInOrderBy",
					metaData.supportsDifferentTableCorrelationNames());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsExtendedSQLGrammar",
					metaData.supportsExpressionsInOrderBy());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsFullOuterJoins",
					metaData.supportsExtendedSQLGrammar());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsGetGeneratedKeys",
					metaData.supportsFullOuterJoins());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsGroupBy",
					metaData.supportsGetGeneratedKeys());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsGroupByBeyondSelect",
					metaData.supportsGroupBy());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsGroupByUnrelated",
					metaData.supportsGroupByBeyondSelect());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsIntegrityEnhancementFacility",
					metaData.supportsGroupByUnrelated());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsLikeEscapeClause",
					metaData.supportsIntegrityEnhancementFacility());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsLimitedOuterJoins",
					metaData.supportsLikeEscapeClause());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsMinimumSQLGrammar",
					metaData.supportsLimitedOuterJoins());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsMixedCaseIdentifiers",
					metaData.supportsMinimumSQLGrammar());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsMixedCaseQuotedIdentifiers",
					metaData.supportsMixedCaseIdentifiers());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsMultipleOpenResults",
					metaData.supportsMixedCaseQuotedIdentifiers());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsMultipleResultSets",
					metaData.supportsMultipleOpenResults());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsMultipleTransactions",
					metaData.supportsMultipleResultSets());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsNamedParameters",
					metaData.supportsMultipleTransactions());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsNonNullableColumns",
					metaData.supportsNamedParameters());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsOpenCursorsAcrossCommit",
					metaData.supportsNonNullableColumns());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsOpenCursorsAcrossRollback",
					metaData.supportsOpenCursorsAcrossCommit());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsOpenStatementsAcrossCommit",
					metaData.supportsOpenCursorsAcrossRollback());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsOpenStatementsAcrossRollback",
					metaData.supportsOpenStatementsAcrossCommit());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsOrderByUnrelated",
					metaData.supportsOpenStatementsAcrossRollback());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsOuterJoins",
					metaData.supportsOrderByUnrelated());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsPositionedDelete",
					metaData.supportsOuterJoins());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsPositionedUpdate",
					metaData.supportsPositionedDelete());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsSavepoints",
					metaData.supportsPositionedUpdate());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsSchemasInProcedureCalls",
					metaData.supportsSavepoints());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsSchemasInTableDefinitions",
					metaData.supportsSchemasInDataManipulation());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsSelectForUpdate",
					metaData.supportsSchemasInIndexDefinitions());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsStatementPooling",
					metaData.supportsSchemasInPrivilegeDefinitions());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsStoredProcedures",
					metaData.supportsSchemasInProcedureCalls());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsSubqueriesInComparisons",
					metaData.supportsSchemasInTableDefinitions());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsSubqueriesInExists",
					metaData.supportsSelectForUpdate());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsSubqueriesInIns",
					metaData.supportsStatementPooling());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsSubqueriesInQuantifieds",
					metaData.supportsStoredProcedures());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsTableCorrelationNames",
					metaData.supportsSubqueriesInComparisons());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsTransactions",
					metaData.supportsSubqueriesInExists());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsUnion",
					metaData.supportsSubqueriesInIns());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsUnionAll",
					metaData.supportsSubqueriesInQuantifieds());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"usesLocalFilePerTable",
					metaData.supportsTableCorrelationNames());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsTransactions",
					metaData.supportsTransactions());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow("supportsUnion", metaData.supportsUnion());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"supportsUnionAll",
					metaData.supportsUnionAll());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow(
					"usesLocalFilePerTable",
					metaData.usesLocalFilePerTable());
			} catch (Throwable t) {
			}
			try {
				tableModel.addRow("usesLocalFiles", metaData.usesLocalFiles());
			} catch (Throwable t) {
			}
		} catch (Exception e) {
		} finally {
		}
	}
}