import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class ThreadViewerPanel extends JPanel {
	private ThreadViewerTableModel tableModel;
	
	public ThreadViewerPanel() {
		setupUI();
	}

	protected void setupUI() {
		if(tableModel == null) {
			tableModel = new ThreadViewerTableModel();
			JTable table = new JTable(tableModel);
			table.getTableHeader().setReorderingAllowed(false);
			table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

			table.getColumnModel().getColumn(0).setPreferredWidth(300);
			TableColumnModel colModel = table.getColumnModel();
			int numColumns = colModel.getColumnCount();

			for (int i = 1; i < numColumns - 1; i++) {
				TableColumn col = colModel.getColumn(i);
				col.setPreferredWidth(60);
			}

			JScrollPane sp = new JScrollPane(table);
			this.setLayout(new BorderLayout());
			this.add(sp, BorderLayout.CENTER);
		}
	}
	
	public void dispose() {
		tableModel.stopRequest();
	}

	protected void finalize() throws Throwable {
		dispose();
	}
}