import java.io.File;
import java.io.FileWriter;
import java.util.List;

import message.ConsoleMessage;
import message.MessageQueue;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import query.CResultSet;
import query.Query;
import query.QueryExecutor;

public class Config {
	private static final String CODE_FILE = "sql/milti/��Ÿ/�ڵ�.sql";
	private final static String CONFIG = "config.xml";
	private static Document document;
	private static Database[] database;
	private static ServerStat[] serverStat;
	private static CResultSet codeRs;
	
	private Config() {
	}

	static {
		try {
			SAXReader reader = new SAXReader();
			Document document = reader.read(CONFIG);
			List list = document.selectNodes("/config/database");
			database = new Database[list.size()];
			for (int i = 0; i < list.size(); i++) {
				Element element = (Element) list.get(i);
				database[i] =
					new Database(
						element.valueOf("name"),
						element.valueOf("url"),
						element.valueOf("driver"),
						element.valueOf("user"),
						element.valueOf("password"));
			}

			list = document.selectNodes("/config/server/port");
			serverStat = new ServerStat[list.size()];
			for (int i = 0; i < list.size(); i++) {
				Element element = (Element) list.get(i);				
				serverStat[i] =
					new ServerStat(
						element.valueOf("../ip"),
						element.getText());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		new Thread() {
			public void run() {
				File f = new File(CODE_FILE);
				long lastModified = f.lastModified();
				codeRs = QueryExecutor.getData(Query.getQuery(CODE_FILE)[0]);
				
				while (true) {
					try {
						Thread.sleep(1000*60);
					} catch (Exception e) {
					}
										
					f = new File(CODE_FILE);
					if (lastModified != f.lastModified()) {
						lastModified = f.lastModified();
						codeRs = QueryExecutor.getData(Query.getQuery(CODE_FILE)[0]);
					}	
				}
			}
		}.start();
	}

	public static Database[] getDatabase() {
		return database;
	}

	public static ServerStat[] getServerStat() {
		return serverStat;
	}
	
	public static void save(String fileName) {
		Element rootElement = DocumentHelper.createElement("Config");
		Document document = DocumentHelper.createDocument(rootElement);

		Database[] database = Config.getDatabase();
		for (int i = 0; i < database.length; i++) {
			XMLObject objectToXML = new XMLObject(database[i]);
			Element element = objectToXML.convertObjectToElement();
			rootElement.add(element);
		}
	
		ServerStat[] serverStat = Config.getServerStat();
		for (int i = 0; i < serverStat.length; i++) {
			XMLObject objectToXML = new XMLObject(serverStat[i]);
			Element element = objectToXML.convertObjectToElement();
			rootElement.add(element);
		}

		OutputFormat format = OutputFormat.createPrettyPrint();
		format.setIndent("\t");
		format.setEncoding("euc-kr");
		format.setTrimText(true);
		try {
			XMLWriter writer = new XMLWriter(new FileWriter(fileName), format);
			writer.write(document);
			writer.flush();
			writer.close();
			MessageQueue.getInstance().sendMessage(new ConsoleMessage("save " + fileName));
		} catch (Exception e) {
			MessageQueue.getInstance().sendMessage(new ConsoleMessage(e));
		}
	}

	public static CResultSet getCodeRs() {
		return codeRs;
	}
		
	public static void main(String[] args) {
		Config.save("text.xml");
	}
}
