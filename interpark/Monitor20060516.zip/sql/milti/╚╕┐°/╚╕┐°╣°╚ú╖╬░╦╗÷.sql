<?xml version="1.0" encoding="euc-kr"?>
<query>	
<sql>
<database>milti</database>
<comment>ȸ����ȣ�ΰ˻�</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select b.mem_id ���̵�, FN_DECRYPTION(b.pwd) ��й�ȣ
from member b
where b.mem_no=?
</queryString>
</sql>
<parameter>mem_no</parameter>
</query>
