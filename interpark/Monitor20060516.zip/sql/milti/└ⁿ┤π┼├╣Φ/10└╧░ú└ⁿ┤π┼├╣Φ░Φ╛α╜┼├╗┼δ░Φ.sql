<?xml version="1.0" encoding="euc-kr"?>
<query>	
<sql>
<database>milti</database>
<comment>10�ϰ������ù����û���</comment>
<reportable>true</reportable>
<chartable>false</chartable>
<queryString>
select b.yyyymmdd ��¥, sum(nvl(cnt, 0)) ����
from (select to_char(reg_dts, 'YYYYMMDD') yyyymmdd, 1 cnt from rebty_hdelv_application 
where reg_dts &gt; (sysdate - 10)) a, 
(select to_char(sysdate - no + 1, 'YYYYMMDD') yyyymmdd 
from copy_t where no &lt;= '10'
) b
where b.yyyymmdd = a.yyyymmdd(+)			   
group by b.yyyymmdd 
order by b.yyyymmdd desc
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>10�ϰ������ù����û����</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from rebty_hdelv_application 
where reg_dts &gt; sysdate - 10
order by reg_dts desc
</queryString>
</sql>
</query>
