<?xml version="1.0" encoding="euc-kr"?>
<query>	
<sql>
<database>milti</database>
<comment>10�ϰ������ù��ֹ����</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select b.yyyymmdd ��¥, sum(nvl(cnt, 0)) ����
from (select substr(ordclm_no, 0, 8) yyyymmdd, 1 cnt from orderclmdtl 
where ordclm_no &gt; to_char(sysdate - 10, 'YYYYMMDD')
and current_ordclmprd_stat in ('60')) a, 
(select to_char(sysdate - no + 1, 'YYYYMMDD') yyyymmdd 
from copy_t where no &lt;= 10
) b
where b.yyyymmdd = a.yyyymmdd(+)		   
group by b.yyyymmdd 
order by b.yyyymmdd desc
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>10�ϰ������ù��ֹ�</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from orderclmdtl 
where ordclm_no &gt; to_char(sysdate-1, 'YYYYMMDD')
and current_ordclmprd_stat in ('60')
order by ordclm_no desc
</queryString>
</sql>
</query>
