<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>milti</database>
<comment>�����ù��ü</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select cd.cd_dtl_nm1 ��ü����, cd_dtl_no, count(*) 
from supply_contract  sc,
code_detail cd
where sc.rpbty_hdelv_yn='Y'
and sc.use_yn='Y'
and cd.cd_no='EN001'
and cd.cd_dtl_no = sc.entr_tp
group by cd.cd_dtl_nm1, cd.cd_dtl_no
order by cd.cd_dtl_no
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>�����ù��ü-OM����</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from supply_contract sc
where sc.entr_tp='01'
and sc.rpbty_hdelv_yn='Y'
and sc.use_yn='Y'
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>�����ù��ü-OM�����</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from supply_contract sc
where sc.entr_tp='02'
and sc.rpbty_hdelv_yn='Y'
and sc.use_yn='Y'
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>�����ù��ü-MD��ü</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from supply_contract sc
where sc.entr_tp='03'
and sc.rpbty_hdelv_yn='Y'
and sc.use_yn='Y'
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>�����ù��ü-�����Ծ�ü</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from supply_contract sc
where sc.entr_tp='04'
and sc.rpbty_hdelv_yn='Y'
and sc.use_yn='Y'
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>�����ù��ü-���ظ���ü</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from supply_contract sc
where sc.entr_tp='05'
and sc.rpbty_hdelv_yn='Y'
and sc.use_yn='Y'
</queryString>
</sql>
</query>
