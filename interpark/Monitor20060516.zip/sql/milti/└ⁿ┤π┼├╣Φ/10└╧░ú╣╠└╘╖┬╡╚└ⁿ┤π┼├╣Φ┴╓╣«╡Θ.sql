<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>milti</database>
<comment>10�ϰ����Էµ������ù��ֹ���</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select c2.ordclm_no, c2.ord_seq, b2.supply_entr_no, b2.supply_ctrt_seq 
from delvwh_order a1, product_standard_his b2, orderclmdtl c2 
where a1.delvwh_ord_no in (
select delvwh_ord_no from (
select b.delvwh_ord_no from orderclmdtl a, delvwh_order b 
where a.ordclm_no &gt;= to_char(sysdate - 10, 'YYYYMMDD')
and a.ordclm_no &lt;= to_char(sysdate - 1, 'YYYYMMDD')
and a.ordclm_tp='1'
and a.current_ordclmprd_stat='60'
and b.ordclm_no = a.ordclm_no
and b.ord_seq = a.ord_seq
minus
select b.delvwh_ord_no from orderclmdtl a, delvwh_order b, rpbty_hdelv_delvwh_ord c 
where a.ordclm_no &gt;= to_char(sysdate - 10, 'YYYYMMDD')
and a.ordclm_no &lt;= to_char(sysdate - 1, 'YYYYMMDD')
and a.ordclm_tp='1'
and a.current_ordclmprd_stat='60'
and b.ordclm_no = a.ordclm_no
and b.ord_seq = a.ord_seq
and c.delvwh_ord_no = b.delvwh_ord_no
)
)
and c2.ordclm_no = a1.ordclm_no
and c2.ord_seq = a1.ord_seq
and c2.parent_prd_no = b2.prd_no 
and c2.reg_dts between b2.apply_str_dts and b2.apply_end_dts
</queryString>
</sql>
</query>
