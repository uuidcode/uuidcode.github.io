<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>milti</database>
<comment>rpbty_hdelv_delvwh_ord</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from rpbty_hdelv_delvwh_ord where ordclm_no=?
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>v_dist_dlv_mst_intprk@cjdlv</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from v_dist_dlv_mst_intprk@cjdlv 
where receipt_no in (select delvwh_ord_no from rpbty_hdelv_delvwh_ord where ordclm_no=?)
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>v_dist_dlv_cpl_intprk2@cjdlv</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from v_dist_dlv_cpl_intprk2@cjdlv
where receipt_no in (select delvwh_ord_no from rpbty_hdelv_delvwh_ord where ordclm_no=?)
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>orderclm_delv</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from orderclm_delv
where ordclm_no=?
</queryString>
</sql>
<parameter>ordclm_no</parameter>
</query>
