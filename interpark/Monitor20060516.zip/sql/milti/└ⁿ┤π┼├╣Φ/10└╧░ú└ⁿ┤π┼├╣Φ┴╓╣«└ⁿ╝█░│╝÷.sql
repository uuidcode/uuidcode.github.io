<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>milti</database>
<comment>10�ϰ������ù��ֹ����۰���</comment>
<reportable>true</reportable>
<chartable>false</chartable>
<queryString>
select b.yyyymmdd ��¥, 
sum(nvl(cnt, 0)) "�� ����", 
sum(nvl(tran_y, 0)) "���۵� ����", 
sum(nvl(tran_n, 0)) "���۾ȵ� ����",
sum(nvl(stat_70, 0)) "����� ����",
sum(nvl(stat_60, 0)) "������� ����",
min(trans_dts) trans_dts,
max(trans_dts) trans_dts
from (select to_char(a.reg_dts, 'YYYYMMDD') yyyymmdd, 1 cnt, 
decode(tran_yn, 'Y', 1, 0) tran_y, 
decode(tran_yn, 'N', 1, 0) tran_n,
decode(b.current_ordclmprd_stat, '70', 1, 0) stat_70,
decode(b.current_ordclmprd_stat, '60', 1, 0) stat_60,
a.TRAN_DTS trans_dts
from rpbty_hdelv_delvwh_ord a, orderclmdtl b , 
orderclm_delv c, delvwh_order d
where a.reg_dts &gt;= to_date(to_char(sysdate - 10, 'YYYYMMDD'), 'YYYYMMDD')
and a.delvwh_ord_no = d.delvwh_ord_no
and b.ordclm_no = d.ordclm_no
and b.ord_seq = d.ord_seq
and b.delv_no = c.delv_no) a, 
(select to_char(sysdate - no + 1, 'YYYYMMDD') yyyymmdd 
from copy_t where no &lt;= 10
) b
where b.yyyymmdd = a.yyyymmdd(+)       
group by b.yyyymmdd 
order by b.yyyymmdd desc
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>10�ϰ������ù��ֹ����º�����</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select cd1.cd_dtl_nm1 ����, count(*) ����
from rpbty_hdelv_delvwh_ord a, orderclmdtl b , 
orderclm_delv c, delvwh_order d,
code_detail cd1  
where a.reg_dts >= to_date(to_char(sysdate - 10, 'YYYYMMDD'), 'YYYYMMDD')
and a.delvwh_ord_no = d.delvwh_ord_no
and b.ordclm_no = d.ordclm_no
and b.ord_seq = d.ord_seq
and b.delv_no = c.delv_no
and cd1.cd_no='OR027'
and b.current_ordclmprd_stat = cd1.cd_dtl_no
group by cd1.cd_dtl_no, cd1.cd_dtl_nm1 
</queryString>
</sql>
</query>
