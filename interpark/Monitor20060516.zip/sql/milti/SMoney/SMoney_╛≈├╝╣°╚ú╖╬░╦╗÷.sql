<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>milti</database>
<comment>sm_currmems</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from sm_currmem where mem_no=?
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>sm_currhis</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from sm_currhis where mem_no=?
 order by sm_acumoccur_no desc
</queryString>
</sql>
<parameter>entr_no</parameter>
</query>
