<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>milti</database>
<comment>comment</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from code_master


</queryString>
</sql>
<sql>
<database>ora8i</database>
<comment>comment</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>

select count(*) from buytaxbill@tax2mgdb

select * from t_docs

select
(


select bill_no from buytaxbill@tax2mgdb
where bill_rcpt_tp in ('01')
and bill_stat in ('1', '2', '3')
and bill_no is not null
and setl_entr_tp in ('04')
minus
select vat_bill_no from ac_vat
where vat_sys='ILS' 
and vat_slip_sacode is null

(select count(*) from buytaxbill@tax2mgdb
where bill_rcpt_tp in ('01')
and bill_stat in ('1', '2', '3')
and bill_no is not null
and setl_entr_tp in ('04')) ����,
(select count(*) from buytaxbill@tax2mgdb
where bill_rcpt_tp in ('01')
and bill_no is not null
and setl_entr_tp in ('04')) ����Total,
(select count(*) from ts_taxinvoice
where ti_docstate in ('ST01', 'ST03', 'ST05')
and nvl(ti_gubun, 'B') = 'D') eTax,
(select count(*) from tax.ts_taxinvoice
where ti_docstate in ('ST01')
and nvl(ti_gubun, 'B') = 'D') �̽���,
(select count(*) from ts_taxinvoice where nvl(ti_gubun, 'B') = 'D') eTaxTotal 
from dual

</queryString>
</sql>
</query>
