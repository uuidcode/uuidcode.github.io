<?xml version="1.0" encoding="euc-kr"?>
<query>	
	<sql>
		<database>ora8i</database>
		<comment>���⼼�ݰ�꼭 t_root</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
	select res_date, res_seq, doc_code, sflag, origin, snd_bill_no1 from t_root where snd_bill_no1=?
	</queryString>
	</sql>
	<sql>
		<database>ora8i</database>
		<comment>���⼼�ݰ�꼭 t_res</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
	select res_date, res_seq, doc_code, snd_bill_no1, issue_cnt, srflag, origin, dflag from t_res where snd_bill_no1=?
	</queryString>
	</sql>
		<parameter>snd_bill_no</parameter>
</query>