<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>milti</database>
<comment>��ü�������</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
--���ݰ�꼭
select '���ݲ��꼭' ����Ÿ��, orcldtl.ordclm_no �ֹ���ȣ, orcldtl.ord_seq �ֹ���ǰ��ȣ, prd.prd_no ��ǰ��ȣ,
	   prd.prd_nm ��ǰ��, pp.sale_unitcost �ǸŰ�, m.mem_nm �ֹ���, odis.dis_unitcost �������ξ�
	   from evidence_request_prd erp, orderclm orcl, orderclmdtl orcldtl,
	 product_standard_his   optprd, product_standard_his   prd , product_price pp,
	 member m, orderclmdtl_discount odis
	where erp.reg_dts &gt;= to_date(?, 'YYYYMMDDHH24MISS') 
	and erp.reg_dts &lt;= to_date(?, 'YYYYMMDDHH24MISS')
	and erp.ordclm_no = orcl.ordclm_no
	and orcl.ordclm_tp = '1' 
	and orcldtl.ordclm_tp = '1' 
	and orcldtl.ordclm_no = erp.ordclm_no
	and orcldtl.ord_seq = erp.ord_seq
	and orcldtl.prd_no = optprd.prd_no	 
	and orcldtl.parent_prd_no = prd.prd_no 
	and orcl.ordclm_dts between optprd.apply_str_dts and optprd.apply_end_dts  
	and orcl.ordclm_dts between prd.apply_str_dts and prd.apply_end_dts  
	and orcl.ordclm_dts between pp.apply_str_dts and pp.apply_end_dts
	and pp.prd_no = orcldtl.prd_no
	and prd.ici_delv_yn = 'N'
	and orcl.ordclm_stat in ('20', '30', '40') 
	and orcldtl.current_ordclmprd_stat in ('70', '80')
	and prd.supply_entr_no = ?
	and prd.supplY_ctrt_seq = ?
	and m.mem_no = orcl.mem_no
	and odis.ordclm_no(+) = orcldtl.ordclm_no
	and odis.ord_seq(+) = orcldtl.ord_seq
	and odis.dis_tp(+) = 1
	union all	
--���ݿ�����
	select '�Ա���' ����Ÿ��, orcldtl.ordclm_no �ֹ���ȣ, orcldtl.ord_seq �ֹ���ǰ��ȣ, prd.prd_no ��ǰ��ȣ,
	   prd.prd_nm ��ǰ��, pp.sale_unitcost �ǸŰ�, m.mem_nm �ֹ���, odis.dis_unitcost �������ξ�
	   from cashrcpt_request erp, orderclm orcl, orderclmdtl orcldtl,
	 product_standard_his   optprd, product_standard_his   prd , product_price pp,
	 member m, orderclmdtl_discount odis
	where erp.reg_dts &gt;= to_date(?, 'YYYYMMDDHH24MISS') 
	and erp.reg_dts &lt;= to_date(?, 'YYYYMMDDHH24MISS')
	and erp.ordclm_no = orcl.ordclm_no
	and orcl.ordclm_tp = '1' 
	and orcldtl.ordclm_tp = '1' 
	and orcldtl.ordclm_no = erp.ordclm_no
	and orcldtl.prd_no = optprd.prd_no	 
	and orcldtl.parent_prd_no = prd.prd_no 
	and orcl.ordclm_dts between optprd.apply_str_dts and optprd.apply_end_dts  
	and orcl.ordclm_dts between prd.apply_str_dts and prd.apply_end_dts  
	and orcl.ordclm_dts between pp.apply_str_dts and pp.apply_end_dts
	and pp.prd_no = orcldtl.prd_no
	and prd.ici_delv_yn = 'N'
	and orcl.ordclm_stat in ('20', '30', '40') 
	and orcldtl.current_ordclmprd_stat in ('70', '80')
	and prd.supply_entr_no = ?
	and prd.supplY_ctrt_seq = ?
	and m.mem_no = orcl.mem_no
	and odis.ordclm_no(+) = orcldtl.ordclm_no
	and odis.ord_seq(+) = orcldtl.ord_seq
	and odis.dis_tp(+) = 1
	group by orcldtl.ordclm_no, orcldtl.ord_seq, prd.prd_no, prd.prd_nm, pp.sale_unitcost, m.mem_nm, odis.dis_unitcost
</queryString>
</sql>
<parameter>str_dts</parameter>
<parameter>end_dts</parameter>
<parameter>supply_entr_no</parameter>
<parameter>supply_ctrt_seq</parameter>
<parameter>str_dts</parameter>
<parameter>end_dts</parameter>
<parameter>supply_entr_no</parameter>
<parameter>supply_ctrt_seq</parameter>
</query>
