<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>ora8i</database>
<comment>������</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from t_admin
</queryString>
</sql>
</query>
