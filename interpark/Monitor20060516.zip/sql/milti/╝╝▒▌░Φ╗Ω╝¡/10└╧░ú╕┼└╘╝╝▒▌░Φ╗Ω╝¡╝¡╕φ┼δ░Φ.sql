<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>milti</database>
<comment>10�ϰ����Լ��ݰ�꼭�������</comment>
<reportable>true</reportable>
<chartable>false</chartable>
<queryString>
select b.yyyymmdd ��¥, sum(nvl(cnt, 0)) ����
from (select to_char(bill_appr_dts, 'yyyymmdd') yyyymmdd, 1 cnt from buytaxbill a 
where bill_appr_dts &gt;= sysdate - 10
and bill_stat in ('3')
and bill_rcpt_tp in ('01')) a, 
(select to_char(sysdate - no + 1, 'YYYYMMDD') yyyymmdd 
from copy_t where no &lt;= 10
) b
where b.yyyymmdd = a.yyyymmdd(+)		   
group by b.yyyymmdd 
order by b.yyyymmdd desc
</queryString>
</sql>
</query>
