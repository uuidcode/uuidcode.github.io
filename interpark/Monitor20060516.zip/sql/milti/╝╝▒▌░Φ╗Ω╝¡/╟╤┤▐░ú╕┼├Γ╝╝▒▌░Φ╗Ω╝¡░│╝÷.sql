<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>ora8i</database>
<comment>���⼼�ݰ�꼭 - t_root</comment>
<reportable>true</reportable>
<chartable>false</chartable>
<queryString>
select b.k_name doc, b.doc_code, count(*) cnt from t_root a, t_docs b 
 where res_date &gt; to_char(sysdate, 'YYYYMM')
 and a.doc_code = b.doc_code 
 group by b.k_name, b.doc_code
</queryString>
</sql>
<sql>
<database>ora8i</database>
<comment>���⼼�ݰ�꼭 - t_res</comment>
<reportable>true</reportable>
<chartable>false</chartable>
<queryString>
select b.k_name doc,b.doc_code,  count(*) cnt from t_res a, t_docs b 
where res_date &gt; to_char(sysdate, 'YYYYMM')
and a.doc_code = b.doc_code 
group by b.k_name, b.doc_code
</queryString>
</sql>
<sql>
<database>ora8i</database>
<comment>���⼼�ݰ�꼭 - t_card</comment>
<reportable>true</reportable>
<chartable>false</chartable>
<queryString>
select b.k_name doc, b.doc_code, count(*) cnt from t_card a, t_docs b 
where res_date &gt; to_char(sysdate, 'YYYYMM')
and a.doc_code = b.doc_code 
group by b.k_name, b.doc_code
</queryString>
</sql>
</query>
