<?xml version="1.0" encoding="euc-kr"?>
<query>  
<sql>
<database>ora8i</database>
<comment>���ݰ�꼭 - SCM</comment>
<reportable>true</reportable>
<chartable>false</chartable>
<queryString>
select
(select count(*) from ac_vat                                        
where vat_sys='SCM') ȸ��,                                   
(select count(*) from buytaxbill@tax2mgdb
where bill_rcpt_tp in ('01')                                           
and bill_stat in ('1', '2', '3')                               
and bill_no is not null
and setl_entr_tp in ('03')) ����,                           
(select count(*) from ts_taxinvoice                                 
where ti_docstate in ('ST01', 'ST03', 'ST05')
and nvl(ti_gubun, 'B') = 'B') eTax,        
(select count(*) from tax.ts_taxinvoice                                 
where ti_docstate in ('ST01')
and nvl(ti_gubun, 'B') = 'B')  �̽���,  
(select count(*) from ts_taxinvoice where nvl(ti_gubun, 'B') = 'B') eTaxTotal                      
from dual
</queryString>
</sql>
<sql>
<database>ora8i</database>
<comment>���ݰ�꼭 - ILS</comment>
<reportable>true</reportable>
<chartable>false</chartable>
<queryString>
select
(select count(*) from ac_vat
where vat_sys='ILS' and vat_slip_sacode is null) ȸ��,
(select count(*) from buytaxbill@tax2mgdb
where bill_rcpt_tp in ('01')
and bill_stat in ('1', '2', '3')
and bill_no is not null
and setl_entr_tp in ('04')) ����,
(select count(*) from buytaxbill@tax2mgdb
where bill_rcpt_tp in ('01')
and bill_no is not null
and setl_entr_tp in ('04')) ����Total,
(select count(*) from ts_taxinvoice
where ti_docstate in ('ST01', 'ST03', 'ST05')
and nvl(ti_gubun, 'B') = 'D') eTax,
(select count(*) from tax.ts_taxinvoice
where ti_docstate in ('ST01')
and nvl(ti_gubun, 'B') = 'D') �̽���,
(select count(*) from ts_taxinvoice where nvl(ti_gubun, 'B') = 'D') eTaxTotal 
from dual
</queryString>
</sql>
<sql>
<database>ora8i</database>
<comment>�ʱ���¿� �ִ� ���ݰ�꼭 ����</comment>
<reportable>true</reportable>
<chartable>false</chartable>
<queryString>
select ntc_str_dt, ntc_end_dt, count(*) from buytaxbill@tax2mgdb
where bill_stat in ('1') 
and bill_rcpt_tp in ('01')
group by ntc_str_dt, ntc_end_dt
</queryString>
</sql>
<sql>
<database>ora8i</database>
<comment>ȸ�迡�� �����ϴ� ���ݰ�꼭 - SCM</comment>
<reportable>true</reportable>
<chartable>false</chartable>
<queryString>
select * from ac_vat
where vat_sys='SCM'
and vat_bill_no in (
select vat_bill_no from ac_vat                                        
where vat_sys='SCM'
minus
select bill_no from buytaxbill@tax2mgdb
where bill_rcpt_tp in ('01')                                           
and bill_stat in ('1', '2', '3')                               
and bill_no is not null
and setl_entr_tp in ('03'))
</queryString>
</sql>
<sql>
<database>ora8i</database>
<comment>buytaxbill</comment>
<reportable>true</reportable>
<chartable>false</chartable>
<queryString>
select * from buytaxbill@tax2mgdb
where bill_no in (
select vat_bill_no from ac_vat                                        
where vat_sys='SCM'
minus
select bill_no from buytaxbill@tax2mgdb
where bill_rcpt_tp in ('01')                                           
and bill_stat in ('1', '2', '3')                               
and bill_no is not null
and setl_entr_tp in ('03')
)
</queryString>
</sql>
<sql>
<database>ora8i</database>
<comment>ts_taxinvoice</comment>
<reportable>true</reportable>
<chartable>false</chartable>
<queryString>
select * from ts_taxinvoice
where ti_serialno in (
select vat_bill_no from ac_vat                                        
where vat_sys='SCM'
minus
select bill_no from buytaxbill@tax2mgdb
where bill_rcpt_tp in ('01')                                           
and bill_stat in ('1', '2', '3')                               
and bill_no is not null
and setl_entr_tp in ('03')
)
</queryString>
</sql>
<sql>
<database>ora8i</database>
<comment>ac_vat_hist</comment>
<reportable>true</reportable>
<chartable>false</chartable>
<queryString>
select * from ac_vat_hist
where vat_sys='SCM'
and vat_bill_no in (
select vat_bill_no from ac_vat                                        
where vat_sys='SCM'
minus
select bill_no from buytaxbill@tax2mgdb
where bill_rcpt_tp in ('01')                                           
and bill_stat in ('1', '2', '3')                               
and bill_no is not null
and setl_entr_tp in ('03')
)
</queryString>
</sql>
<sql>
<database>ora8i</database>
<comment>3������ �����Ϻ� ���ݰ�꼭��</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select ntc_str_dt, ntc_end_dt, count(*) from buytaxbill@tax2mgdb 
where bill_stat in ('3') 
and bill_rcpt_tp in ('01')
and ntc_str_dt &gt;= to_char(add_months(sysdate, -3), 'YYYYMM') || '01'
group by ntc_str_dt, ntc_end_dt
</queryString>
</sql>
</query>
