<?xml version="1.0" encoding="euc-kr"?>
<query>  
<sql>
<database>milti</database>
<comment>columns</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select a.column_id,                                                              
(select /*+rule*/ c.position from all_cons_columns c, all_constraints d  
where c.table_name= a.table_name                                         
and c.column_name = a.column_name                                        
and c.owner = a.owner                                                    
and d.owner = c.owner                                                    
and d.table_name = c.table_name                                          
and d.constraint_name = c.constraint_name                                
and d.constraint_type = 'P'                                              
) pk,                                                                     
a.column_name, a.data_type, a.data_length,                                
a.nullable, a.data_default, b.comments                                    
from all_tab_columns a, all_col_comments b                                
where a.table_name like upper(?)
and b.table_name = a.table_name                                           
and b.column_name = a.column_name                                         
and b.owner = a.owner  
order by a.column_id
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>indexes</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select a.index_name, a.uniqueness, b.column_name, 
descend, b.column_position  from all_indexes a, ALL_IND_COLUMNS   b
where a.table_name = upper(?)
and b.table_name = a.table_name
and b.index_name = a.index_name
and b.index_owner = a.owner
order by a.index_name, b.column_position
</queryString>
</sql>
<parameter>tablename</parameter>
</query>
