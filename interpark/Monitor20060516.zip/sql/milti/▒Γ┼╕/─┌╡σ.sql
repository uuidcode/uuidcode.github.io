<?xml version="1.0" encoding="euc-kr"?>
<query>  
<sql>
<database>milti</database>
<comment>�ڵ�</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from (
select 'product.sail_stat_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='PD001' 
and b.cd_no=a.cd_no 
union all
select 'product_detail.prd_attbt' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='PD004' 
and b.cd_no=a.cd_no 
union all
select 'product_price.tax_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='PD006' 
and b.cd_no=a.cd_no 
union all
select 'product.delv_amt_payt_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='PD024' 
and b.cd_no=a.cd_no 
union all
select 'tmp_ord.ord_occur_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR002' 
and b.cd_no=a.cd_no 
union all
select 'orderclm.ordclm_crt_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR002' 
and b.cd_no=a.cd_no 
union all
select 'tmp_payment.pay_ref_mthd_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR009' 
and b.cd_no=a.cd_no 
union all
select 'orderclmdtl.current_ordclmprd_stat' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR027' 
and b.cd_no=a.cd_no 
union all
select 'orderclm.ordclm_stat' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR004'
and b.cd_no=a.cd_no 
union all
select 'orderclm.ordclm_stat' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR005'
and b.cd_no=a.cd_no 
union all
select 'orderclm.ordclm_crt_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR003'
and b.cd_no=a.cd_no 
union all
select 'supply_contract.entr_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='EN001'
and b.cd_no=a.cd_no 
union all
select 'orderclm.ordclm_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR001'
and b.cd_no=a.cd_no 
union all
select 'clm_request.clmreq_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR020'
and b.cd_no=a.cd_no 
union all
select 'orderclmdtl.return_resp_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR031'
and b.cd_no=a.cd_no 
union all
select 'orderclmdtl.cost_resp_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR008'
and b.cd_no=a.cd_no 
union all
select 'clm_requestdtl.clmreq_stat' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR019'
and b.cd_no=a.cd_no 
union all
select 'orderclmdtl.current_ordclmprd_stat' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR028'
and b.cd_no=a.cd_no 
union all 
select 'orderclmdtl_status_his.ordclm_prd_stat' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR027'
and b.cd_no=a.cd_no 
union all
select 'orderclmdtl_status_his.ordclm_prd_stat' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR028'
and b.cd_no=a.cd_no 
union all
select 'orderclmdtl.clm_rsn_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR029'
and b.cd_no=a.cd_no 
union all
select 'delvwh_order.nodelvwh_stat' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR063'
and b.cd_no=a.cd_no 
union all
select 'orderclmdtl.current_cncl_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR026'
and b.cd_no=a.cd_no 
union all
select 'orderclmdtl.hdelv_prepay_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR065'
and b.cd_no=a.cd_no 
union all
select 'orderclmdtl.inwh_conf_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR032'
and b.cd_no=a.cd_no 
union all
select 'returnprd_object.obj_rsn_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='OR036'
and b.cd_no=a.cd_no 
union all
select 'sos_request.prcs_stat' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='SOS03'
and b.cd_no=a.cd_no 
union all
select 'mail_send_history.mail_tp_cd' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='SY004'
and b.cd_no=a.cd_no 
union all
select 'supply_contract.use_app_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='EN050'
and b.cd_no=a.cd_no 
union all
select 'supply_contract.entr_stat' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='EN003'
and b.cd_no=a.cd_no 
union all
select 'supply_contract.buy_entr_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='EN002'
and b.cd_no=a.cd_no 
union all
select 'rpbty_hdelv_delvwh_ord.cur_hdelv_ord_stat' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='EN070'
and b.cd_no=a.cd_no 
union all
select 'hdelv_mafc_entr.hdelv_mafc_entr_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm1
from code_master a, code_detail b where a.cd_no='EN030'
and b.cd_no=a.cd_no 
) order by column_name, cd_no, cd_nm, cd_dtl_no
</queryString>
</sql>
</query>
