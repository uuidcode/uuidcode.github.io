<?xml version="1.0" encoding="euc-kr"?>
<query>	
<sql>
<database>milti</database>
<comment>tablelist</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from all_tables where table_name like '%' || upper(?) || '%'
</queryString>
</sql>
<parameter>tablename</parameter>
</query>
