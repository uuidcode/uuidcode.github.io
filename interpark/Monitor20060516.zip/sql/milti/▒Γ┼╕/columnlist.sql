<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>milti</database>
<comment>columnlist</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from all_col_comments where comments like '%' || ? || '%'
</queryString>
</sql>
<parameter>column_name</parameter>
</query>
