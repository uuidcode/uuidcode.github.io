<?xml version="1.0" encoding="euc-kr"?>
<query>	
<sql>
<database>milti</database>
<comment>��ü����</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
		select s.entr_no, s.supply_ctrt_seq, e.entr_nm, e.biz_reg_no, s.supply_ctrt_nm, 
			cd1.cd_dtl_nm1 || '(' || s.entr_tp || ')' ��ü����, 
			cd2.cd_dtl_nm1 || '(' || s.entr_buy_tp || ')' ��������,
			cd3.cd_dtl_nm1 || '('	|| s.entr_stat || ')' ��ü����,
			s.rpbty_hdelv_yn �����ù��뿩��
			from enterprise e, supply_contract s, code_detail cd1,
			code_detail cd2, code_detail cd3
			where e.entr_no = ?
			and e.entr_no= s.entr_no
			and cd1.cd_no='EN001'
			and cd1.cd_dtl_no = s.entr_tp
			and cd2.cd_no='EN002'
			and cd2.cd_dtl_no = s.entr_buy_tp
			and cd3.cd_no='EN003'
			and cd3.cd_dtl_no = s.entr_stat
			</queryString>
		</sql>
		<sql>
				<database>milti</database>
				<comment>��ü������</comment>
				<reportable>false</reportable>
				<chartable>false</chartable>
				<queryString>
				select d.entr_no, d.supply_ctrt_seq, b.mem_no ȸ����ȣ, b.mem_nm ȸ���̸�,
				b.mem_id ȸ�����̵�, FN_DECRYPTION(b.pwd) ��й�ȣ
				from entr_mgt_auth a, member b, enterprise c, supply_contract d
				where a.mem_no=?
				and c.entr_no = a.mem_no
				and a.entr_mgr_no = b.mem_no 
				and c.entr_no = d.entr_no
				and a.supply_ctrt_seq = d.supply_ctrt_seq
			</queryString>
		</sql>
		<parameter>entr_no</parameter>
</query>
