<?xml version="1.0" encoding="euc-kr"?>
<query>	
		<sql>
				<database>milti</database>
				<comment>��ü������</comment>
				<reportable>false</reportable>
				<chartable>false</chartable>
				<queryString>
				select h.ordclm_no, 
				h.ord_seq, 
				cd1.cd_dtl_nm1 || '(' || g.ordclm_stat || ')' �ֹ�����,
				cd2.cd_dtl_nm1 || '(' || h.current_ordclmprd_stat || ')' �ֹ���ǰ����,
				c.entr_nm ��ü��, 
				c.biz_reg_no ����ڹ�ȣ, 
				e.cd_dtl_nm1 || '(' || d.entr_tp || ')' ��ü����,
				c.entr_no ��ü��ȣ, 
				a.supply_ctrt_seq ����ȣ,
				b.mem_no ȸ����ȣ,
				b.mem_nm ȸ���̸�,
				b.mem_id ȸ�����̵�,
				FN_DECRYPTION(b.pwd) ��й�ȣ
				from entr_mgt_auth a, member b, enterprise c, 
				supply_contract d, code_detail e, product f,
				orderclm g,	orderclmdtl h, product_detail i,
				code_detail cd1, code_detail cd2
				where g.ordclm_no=?
				and g.ordclm_no = h.ordclm_no
				and h.parent_prd_no = f.prd_no
				and i.prd_no = f.prd_no
				and i.supply_entr_no = c.entr_no
				and i.supply_ctrt_seq = d.supply_ctrt_seq
				and a.mem_no = c.entr_no
				and a.entr_mgr_no = b.mem_no 
				and a.supply_ctrt_seq = d.supply_ctrt_seq
				and c.entr_no = d.entr_no
				and e.cd_no = 'EN001'
			  and d.entr_tp = e.cd_dtl_no
			  and cd1.cd_no='OR004'
			  and cd1.cd_dtl_no=g.ordclm_stat
			  and cd2.cd_no='OR027'
			  and cd2.cd_dtl_no=h.current_ordclmprd_stat
			</queryString>
		</sql>
		<parameter>ordclm_no</parameter>
</query>
