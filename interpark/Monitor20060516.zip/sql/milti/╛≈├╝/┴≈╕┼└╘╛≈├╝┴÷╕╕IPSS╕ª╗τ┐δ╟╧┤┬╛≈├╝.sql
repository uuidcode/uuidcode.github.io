<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>milti</database>
<comment>WSCM��ü����IPSS������ϴ¾�ü</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select a.entr_no, a.supply_ctrt_seq, a.entr_tp, a.entr_buy_tp, a.supply_ctrt_nm
from supply_contract a where (a.entr_no, a.supply_ctrt_seq) in
(
select new_entr_no, supply_ctrt_seq from enterprise_map where entr_no in ('175383', '85335', '36145', '149018', '92439', '199995', '200616')
and po_type=1
)
</queryString>
</sql>
</query>
