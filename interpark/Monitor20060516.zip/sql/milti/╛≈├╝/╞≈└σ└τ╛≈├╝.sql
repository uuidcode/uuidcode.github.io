<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>milti</database>
<comment>�������ü</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from supply_contract where entr_no='3000008365'
</queryString>
</sql>
</query>
