<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>milti</database>
<comment>�ǸŻ��º���ü��</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select cd_dtl_nm1 �ǸŻ��º�,
(select count(*) from supply_contract sc where use_yn='Y' and entr_tp='01' and entr_stat=cd.cd_dtl_no) OM����, 
(select count(*) from supply_contract sc where use_yn='Y' and entr_tp='02' and entr_stat=cd.cd_dtl_no) OM�����,
(select count(*) from supply_contract sc where use_yn='Y' and entr_tp='03' and entr_stat=cd.cd_dtl_no) MD,
(select count(*) from supply_contract sc where use_yn='Y' and entr_tp='04' and entr_stat=cd.cd_dtl_no) ������,
(select count(*) from supply_contract sc where use_yn='Y' and entr_tp='05' and entr_stat=cd.cd_dtl_no) ���ظ�,
(select count(*) from supply_contract sc where use_yn='Y' and entr_stat=cd.cd_dtl_no) �հ� 
from code_detail cd
where cd.cd_no='EN003'
union all
select '�հ�', sum(OM����), sum(OM�����), sum(MD), sum(������), sum(���ظ�), sum(�հ�) 
from (
select cd_dtl_nm1 �ǸŻ��º�,
(select count(*) from supply_contract sc where use_yn='Y' and entr_tp='01' and entr_stat=cd.cd_dtl_no) OM����, 
(select count(*) from supply_contract sc where use_yn='Y' and entr_tp='02' and entr_stat=cd.cd_dtl_no) OM�����,
(select count(*) from supply_contract sc where use_yn='Y' and entr_tp='03' and entr_stat=cd.cd_dtl_no) MD,
(select count(*) from supply_contract sc where use_yn='Y' and entr_tp='04' and entr_stat=cd.cd_dtl_no) ������,
(select count(*) from supply_contract sc where use_yn='Y' and entr_tp='05' and entr_stat=cd.cd_dtl_no) ���ظ�,
(select count(*) from supply_contract sc where use_yn='Y' and entr_stat=cd.cd_dtl_no) �հ� 
from code_detail cd
where cd.cd_no='EN003'
)
</queryString>
</sql>
</query>
