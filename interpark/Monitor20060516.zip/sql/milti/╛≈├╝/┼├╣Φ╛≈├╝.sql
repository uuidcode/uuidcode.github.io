<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>milti</database>
<comment>�ù��ü</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from HDELV_MAFC_ENTR 
where hdelv_mafc_entr_tp='01' 
and use_yn='Y'
</queryString>
</sql>
</query>
