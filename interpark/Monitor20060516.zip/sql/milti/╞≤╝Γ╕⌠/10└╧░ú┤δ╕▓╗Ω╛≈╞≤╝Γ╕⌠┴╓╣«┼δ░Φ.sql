<?xml version="1.0" encoding="euc-kr"?>
<query>	
<sql>
<database>milti</database>
<comment>10�ϰ��븲��������ֹ����</comment>
<reportable>true</reportable>
<chartable>false</chartable>
<type>day</type>
<date>��¥</date>
<count>����</count>
<queryString>
select b.yyyymmdd ��¥, sum(nvl(cnt, 0)) ����
from (select to_char(ordclm_dts, 'YYYYMMDD') yyyymmdd, 1 cnt from orderclm 
where ordclm_dts &gt; (sysdate - 10)
and PARTNER_MEM_CD in (2104209126, 2104176772, 2104176792, 2104176807, 2104176818, 2104176825, 2104176846, 2104176850)) a, 
(select to_char(sysdate - no + 1, 'YYYYMMDD') yyyymmdd 
from copy_t where no &lt;= 10
) b
where b.yyyymmdd = a.yyyymmdd(+)			   
group by b.yyyymmdd 
order by b.yyyymmdd desc
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>10�ϰ��븲����迭�纰�ֹ�����</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select partner_mem_cd, count(*) ���� from orderclm 
where ordclm_dts &gt; (sysdate - 10)
and PARTNER_MEM_CD in (2104209126, 2104176772, 2104176792, 2104176807, 2104176818, 2104176825, 2104176846, 2104176850)
group by partner_mem_cd
order by partner_mem_cd
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>10�ϰ��븲��������ֹ�</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from orderclm 
where ordclm_dts &gt; (sysdate - 10)
and PARTNER_MEM_CD in (2104209126, 2104176772, 2104176792, 2104176807, 2104176818, 2104176825, 2104176846, 2104176850)
order by ordclm_no desc
</queryString>
</sql>
</query>
