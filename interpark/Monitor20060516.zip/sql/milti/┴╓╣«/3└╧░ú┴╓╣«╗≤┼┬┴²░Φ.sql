<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>milti</database>
<comment>�����Ϸ��ֹ����� D</comment>
<reportable>true</reportable>
<chartable>false</chartable>
<queryString>
select * from (				
select cd.cd_dtl_nm1 ��ۻ���, cd.cd_dtl_no, count(*) ���� 
from orderclmdtl ord, orderclm o, code_detail cd 
where ord.ordclm_no like to_char(sysdate, 'YYYYMMDD') || '%'
and cd.cd_no = 'OR027'
and o.ordclm_no = ord.ordclm_no
and o.ordclm_stat in ('20', '30')
and o.ordclm_tp = '1'
and ord.current_ordclmprd_stat = cd.cd_dtl_no
group by cd.cd_dtl_nm1, cd_dtl_no			
) order by cd_dtl_no
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>�����Ϸ��ֹ����� D-1</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from (				
select cd.cd_dtl_nm1 ��ۻ���, cd.cd_dtl_no, count(*) ���� 
from orderclmdtl ord, orderclm o, code_detail cd 
where ord.ordclm_no like to_char(sysdate - 1, 'YYYYMMDD') || '%'
and cd.cd_no = 'OR027'
and o.ordclm_no = ord.ordclm_no
and o.ordclm_stat in ('20', '30')
and o.ordclm_tp = '1'
and ord.current_ordclmprd_stat = cd.cd_dtl_no
group by cd.cd_dtl_nm1, cd_dtl_no			
) order by cd_dtl_no
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>�����Ϸ��ֹ����� D-2</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from (				
select cd.cd_dtl_nm1 ��ۻ���, cd.cd_dtl_no, count(*) ���� 
from orderclmdtl ord, orderclm o, code_detail cd 
where ord.ordclm_no like to_char(sysdate - 2, 'YYYYMMDD') || '%'
and cd.cd_no = 'OR027'
and o.ordclm_no = ord.ordclm_no
and o.ordclm_stat in ('20', '30')
and o.ordclm_tp = '1'
and ord.current_ordclmprd_stat = cd.cd_dtl_no
group by cd.cd_dtl_nm1, cd_dtl_no			
) order by cd_dtl_no
</queryString>
</sql>
</query>
