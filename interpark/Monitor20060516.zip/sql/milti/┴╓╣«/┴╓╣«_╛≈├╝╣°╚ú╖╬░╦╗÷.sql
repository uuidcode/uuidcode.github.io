<?xml version="1.0" encoding="euc-kr"?>
<query>	
	<sql>
		<database>milti</database>
		<comment>�ֹ�����Ʈ_��ü��ȣ�ΰ˻�</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
			select /*+index (od idx_orderclmdtl_08) */ 
  		 	od.ordclm_no, od.ord_seq, 
  		 	cd4.cd_dtl_nm1 || '(' || o.ordclm_stat || ')' �ֹ�����,
				cd5.cd_dtl_nm1 || '(' || od.current_ordclmprd_stat || ')' �ֹ���ǰ����,
  		 	pd.prd_no, pd.supply_entr_no, pd.supply_ctrt_seq,
			  cd1.cd_dtl_nm1 || '(' || s.entr_tp || ')' ��ü����, 
			  cd2.cd_dtl_nm1 || '(' || s.entr_buy_tp || ')' ��������,
			  cd3.cd_dtl_nm1 || '('	|| s.entr_stat || ')' ��ü����
			  from orderclmdtl od, product p, product_detail pd, supply_contract s,
			  code_detail cd1, code_detail cd2, code_detail cd3, entr_mgt_auth ema,
			  orderclm o, code_detail cd4, code_detail cd5
			  where od.ordclm_no &gt; ?
			  and o.ordclm_no = od.ordclm_no
			  and o.ordclm_tp = 1
			  and p.prd_no = od.prd_no
			  and pd.prd_no = p.parent_prd_no
			  and s.entr_no = pd.supply_entr_no
			  and s.supply_ctrt_seq = s.supply_ctrt_seq
			  and cd1.cd_no='EN001'
			  and cd1.cd_dtl_no = s.entr_tp
			  and cd2.cd_no='EN002'
			  and cd2.cd_dtl_no = s.entr_buy_tp
			  and cd3.cd_no='EN003'
			  and cd3.cd_dtl_no = s.entr_stat
			  and cd4.cd_no='OR004'
			  and cd4.cd_dtl_no=o.ordclm_stat
			  and cd5.cd_no='OR027'
			  and cd5.cd_dtl_no=od.current_ordclmprd_stat
			  and ema.mem_no = s.entr_no
			  and ema.entr_mgr_no = ?
		</queryString>
	</sql>
	<parameter>ordclm_no</parameter>
	<parameter>entr_no</parameter>
</query>