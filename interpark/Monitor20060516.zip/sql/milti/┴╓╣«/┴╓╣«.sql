<?xml version="1.0" encoding="euc-kr"?>
<query>	
<sql>
<database>milti</database>
<comment>�ֹ�����</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
SELECT O.ORDCLM_NO, a.cd_dtl_nm1 || '(' || O.ORDCLM_STAT || ')' AS �ֹ����� 
	   , E.ENTR_NM, M.MEM_NO, M.MEM_ID, FN_DECRYPTION(M.PWD)
	   , D.ORD_SEQ, D.ORDCLM_CNT, D.ACC_CNCL_CNT, D.CURRENT_ORDCLMPRD_STAT AS ��ǰ����, D.REAL_SALE_UNITCOST AS �ǸŰ� 
	   , D.PARTDELVWH_ALLOW_YN, D.DELVWH_PRE_DT, D.PRD_NO, P1.PRD_NM
	   , PD.PRD_NO, PD.SUPPLY_ENTR_NO, SC.ENTR_NO, SC.SUPPLY_CTRT_SEQ, SC.ENTR_TP , SC.ADM_NO
FROM ORDERCLM O, ORDERCLMDTL D, PRODUCT P, product p1, PRODUCT_DETAIL PD, SUPPLY_CONTRACT SC, 
	 ENTERPRISE E, ENTR_MGT_AUTH EM, MEMBER M, code_detail a
WHERE O.ORDCLM_NO like ? || '%'
AND D.ORDCLM_NO = O.ORDCLM_NO 
AND P.PRD_NO = D.PRD_NO 
and p1.prd_no = p.parent_prd_no
AND PD.PRD_NO = P1.PRD_NO
AND SC.ENTR_NO = PD.SUPPLY_ENTR_NO
AND SC.SUPPLY_CTRT_SEQ = PD.SUPPLY_CTRT_SEQ 
AND E.ENTR_NO = SC.ENTR_NO
AND EM.MEM_NO = E.ENTR_NO
AND EM.SUPPLY_CTRT_SEQ = SC.SUPPLY_CTRT_SEQ
AND M.MEM_NO = EM.ENTR_MGR_NO 
and a.cd_no='OR004'
and o.ordclm_stat = a.cd_dtl_no
ORDER BY ORDCLM_DTS DESC
</queryString>
</sql>
<parameter>ordclm_no</parameter>
</query>
