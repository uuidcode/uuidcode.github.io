<?xml version="1.0" encoding="euc-kr"?>
<query>  
<sql>
<database>milti</database>
<comment>delvwh_order</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from delvwh_order where ordclm_no=?
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>delvwh_status_history</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from delvwh_status_history
 where delvwh_ord_no in (select delvwh_ord_no from delvwh_order where delvwh_ord_no=?)
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>orderclm</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from orderclm where ordclm_no=?
</queryString>
 </sql>
 <sql>
<database>milti</database>
<comment>orderclm</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from orderclm where ori_ordclm_no=?
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>orderclm_status_his</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from orderclm_status_his where ordclm_no=?
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>orderclmdtl</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from orderclmdtl where ordclm_no=? order by ordclm_no, ord_seq
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>orderclmdtl_status_his</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from orderclmdtl_status_his where ordclm_no=?
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>clm_request</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from clm_request where ordclm_no=?
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>clm_requestdtl</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from clm_requestdtl where ordclm_no=?
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>orderclm_delv</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from orderclm_delv where ordclm_no=?
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>orderclm_delv_place</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from orderclm_delv_place where ordclm_no=?
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>returnprd_object</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from returnprd_object where ordclm_no=?
</queryString>
</sql>
<parameter>ordclm_no</parameter>
</query>
