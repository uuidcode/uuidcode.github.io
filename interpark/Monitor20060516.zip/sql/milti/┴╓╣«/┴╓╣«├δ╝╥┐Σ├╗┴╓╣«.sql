<?xml version="1.0" encoding="euc-kr"?>
<query>	
<sql>
<database>milti</database>
<comment>�ֹ���ҿ�û�ֹ�</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select crd.ordclm_no, crd.ord_seq, crd.clmreq_seq, clmreq_cnt 
	   from clm_request cr, clm_requestdtl crd
	   where cr.ordclm_no &gt;= ?
	   and cr.clmreq_tp ='1'
	   and crd.ordclm_no = cr.ordclm_no
	   and crd.clmreq_seq = cr.clmreq_seq
	   and crd.clmreq_stat = '1'
</queryString>
</sql>
<parameter>ordclm_no</parameter>
</query>
