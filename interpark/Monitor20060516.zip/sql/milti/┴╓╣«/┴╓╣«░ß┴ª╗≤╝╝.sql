<?xml version="1.0" encoding="euc-kr"?>
<query>	
<sql>
<database>milti</database>
<comment>orderclm</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from orderclm where ordclm_no=?
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>orderclmdtl</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from orderclmdtl where ordclm_no=?
</queryString>
 </sql>
 <sql>
<database>milti</database>
<comment>orderclmdtl_discount</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from orderclmdtl_discount where ordclm_no=?
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>ordpayment_refund</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from ordpayment_refund where ordclm_no=?
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>credit_acct_payment</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from credit_acct_payment where ordclm_no=?
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>card_payment</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from card_payment where ordclm_no=?
</queryString>
</sql>
<sql>
<database>milti</database>
<comment>bank_payment</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from bank_payment where ordclm_no=?
</queryString>
</sql>
<parameter>ordclm_no</parameter>
</query>
