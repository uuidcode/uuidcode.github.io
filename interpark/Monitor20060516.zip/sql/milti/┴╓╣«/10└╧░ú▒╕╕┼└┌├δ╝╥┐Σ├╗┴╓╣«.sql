<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>milti</database>
<comment>10�ϰ���������ҿ�û�ֹ�</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select  cd_dtl_nm1, count(*)
	   from clm_request cr, clm_requestdtl crd, code_detail cd
	   where cr.ordclm_no &gt;= to_char(sysdate - 10, 'YYYYMMDD')
	   and cr.clmreq_tp ='1'
	   and crd.ordclm_no = cr.ordclm_no
	   and crd.clmreq_seq = cr.clmreq_seq
	   and cd.cd_no='OR019'
	   and cd.cd_dtl_no = crd.clmreq_stat
	   group by cd.cd_dtl_no, cd_dtl_nm1
</queryString>
</sql>
</query>
