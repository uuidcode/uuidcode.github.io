<?xml version="1.0" encoding="euc-kr"?>
<query>	
<sql>
<database>milti</database>
<comment>��������ֹ�</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select /*+ ordered use_nl(o od p pd s) index (o idx_orderclm_08) */ 
od.ordclm_no, od.ord_seq, pd.prd_no, pd.supply_entr_no, pd.supply_ctrt_seq,
cd1.cd_dtl_nm1 || '(' || s.entr_tp || ')' ��ü����, 
cd2.cd_dtl_nm1 || '(' || s.entr_buy_tp || ')' ��������,
cd3.cd_dtl_nm1 || '('	|| s.entr_stat || ')' ��ü����
from orderclm o, orderclmdtl od, product_standard_his p, product_detail pd, supply_contract s,
code_detail cd1, code_detail cd2, code_detail cd3
where o.ordclm_dts &gt;= to_date(?, 'YYYYMMDD')
and o.ordclm_dts &lt;= to_date(?, 'YYYYMMDD')
and o.ordclm_tp = '1'
and o.ordclm_stat in ('20', '30')
and od.ordclm_no = o.ordclm_no
and od.ordclm_tp = '1'
and od.current_ordclmprd_stat in ('40')
and od.ordclm_no = o.ordclm_no
and p.prd_no = od.parent_prd_no
and p.ici_delv_yn = 'N'
and o.ordclm_dts between p.apply_str_dts and p.apply_end_dts
and pd.prd_no = p.prd_no
and s.entr_no = pd.supply_entr_no
and s.supply_ctrt_seq = pd.supply_ctrt_seq
and cd1.cd_no='EN001'
and cd1.cd_dtl_no = s.entr_tp
and cd2.cd_no='EN002'
and cd2.cd_dtl_no = s.entr_buy_tp
and cd3.cd_no='EN003'
and cd3.cd_dtl_no = s.entr_stat
</queryString>
</sql>
<parameter>ordclm_dts</parameter>
<parameter>ordclm_dts</parameter>
</query>
