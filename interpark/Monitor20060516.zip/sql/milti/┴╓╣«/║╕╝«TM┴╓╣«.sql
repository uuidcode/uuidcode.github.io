<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>milti</database>
<comment>�Ѵް� ����ȵ� ����TM�ֹ� ����</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select count(*) from orderclm 
where ordclm_crt_tp in ('05')
and ordclm_no &gt;= to_char(add_months(sysdate, -2), 'YYYYMM')
and ordclm_stat not in ('40', '50')
and ordclm_tp = 1
</queryString>
</sql>
</query>
