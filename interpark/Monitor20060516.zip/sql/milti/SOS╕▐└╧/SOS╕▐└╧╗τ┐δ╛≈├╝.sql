<?xml version="1.0" encoding="euc-kr"?>
<query>
<sql>
<database>milti</database>
<comment>SOS���ϻ���ü</comment>
<reportable>false</reportable>
<chartable>false</chartable>
<queryString>
select * from supply_contract 
where sos_mail_use_yn='Y'
and entr_tp='03'
and use_yn = 'Y'
and rownum &lt;= 10
</queryString>
</sql>
</query>
