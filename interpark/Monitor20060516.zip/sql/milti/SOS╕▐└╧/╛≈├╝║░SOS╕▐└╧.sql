<?xml version="1.0" encoding="euc-kr"?>
<query>	
		<sql>
				<database>milti</database>
				<comment>��ü��SOS����</comment>
				<reportable>false</reportable>
				<chartable>false</chartable>
				<queryString>
select /*+ use_nl(s pd p a) */ 
a.sos_no, a.sos_title, pd.supply_entr_no, pd.supply_ctrt_seq, 
s.sos_mail_use_yn, 
(select count(*) from sos_ans where sos_no=a.sos_no) answer, a.reg_dts 
from SOS_quest a, product p, product_detail pd, supply_contract s
where a.prd_no is not null
and a.prcs_stat = '01'
and a.major_tp in ( 'CST0101' ,'CST0111')
and a.use_yn='Y'
and p.prd_no = a.prd_no 
and pd.prd_no = p.parent_prd_no
and s.entr_no = pd.supply_entr_no
and s.supply_ctrt_seq = pd.supply_ctrt_seq
and s.entr_tp in ('03')
and s.entr_no=?
</queryString>
		</sql>
		<parameter>entr_no</parameter>
</query>