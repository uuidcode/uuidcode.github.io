<?xml version="1.0" encoding="euc-kr"?>
<query>  
      <sql>
            <database>milti</database>
            <comment>product</comment>
            <reportable>false</reportable>
            <chartable>false</chartable>
            <queryString>
             select * from product where prd_no=?
            </queryString>
      </sql>
      <sql>
            <database>milti</database>
            <comment>product_detail</comment>
            <reportable>false</reportable>
            <chartable>false</chartable>
            <queryString>
             select * from product_detail where prd_no=?
            </queryString>
      </sql>
    <sql>
            <database>milti</database>
            <comment>product_standard_his</comment>
            <reportable>false</reportable>
            <chartable>false</chartable>
            <queryString>
             select * from product_standard_his where prd_no=?
            </queryString>
      </sql>
     <sql>
            <database>milti</database>
            <comment>product_price</comment>
            <reportable>false</reportable>
            <chartable>false</chartable>
            <queryString>
             select * from product_price where prd_no=?
            </queryString>
      </sql>
      <parameter>prd_no</parameter>
</query>

