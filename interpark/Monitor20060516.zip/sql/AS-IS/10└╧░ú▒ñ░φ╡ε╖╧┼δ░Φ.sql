<?xml version="1.0" encoding="euc-kr"?>
<query>	
		<sql>
				<database>comdb</database>
				<comment>10�ϰ� ���� ���</comment>
				<reportable>false</reportable>
				<chartable>true</chartable>
				<type>day</type>
				<date>��¥</date>
				<count>����</count>
				<queryString>
       select substr(reg_dm, 0, 8) ��¥, count(*) ���� from tadvres 
	   where reg_dm &gt;= to_char(sysdate - 10, 'YYYYMMDD') || '000000'
	   and adv_disp_stat='00'
	   group by substr(reg_dm, 0, 8)
	   </queryString>
   	</sql>
</query>