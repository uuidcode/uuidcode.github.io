<?xml version="1.0" encoding="euc-kr"?>
<query>	
		<sql>
				<database>comdb</database>
				<comment>�ڵ�</comment>
				<reportable>false</reportable>
				<chartable>false</chartable>
				<queryString>
select 'torderclm.cost_sale' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm, b.use_yn, b.reg_dm, b.user_id, b.upd_dm 
from tcode a, tcodedtl b where a.cd_no='CR06'
and b.cd_no=a.cd_no
union all
select 'torderclm.duty_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm, b.use_yn, b.reg_dm, b.user_id, b.upd_dm 
from tcode a, tcodedtl b where a.cd_no='CR08'
and b.cd_no=a.cd_no
union all
select 'tgoodsdepl.sale_stat_cl' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm, b.use_yn, b.reg_dm, b.user_id, b.upd_dm 
from tcode a, tcodedtl b where a.cd_no='27'
and b.cd_no=a.cd_no
union all
select 'torderdtl.po_status' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm, b.use_yn, b.reg_dm, b.user_id, b.upd_dm 
from tcode a, tcodedtl b where a.cd_no='DL04'
and b.cd_no=a.cd_no
union all
select 'torderdtl.ord_job_stat' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm, b.use_yn, b.reg_dm, b.user_id, b.upd_dm 
from tcode a, tcodedtl b where a.cd_no='42'
and b.cd_no=a.cd_no
union all
select 'torderclm.clm_stat_cl' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm, b.use_yn, b.reg_dm, b.user_id, b.upd_dm 
from tcode a, tcodedtl b where a.cd_no='43'
and b.cd_no=a.cd_no
union all
select 'torderclm.clm_req_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm, b.use_yn, b.reg_dm, b.user_id, b.upd_dm 
from tcode a, tcodedtl b where a.cd_no='44'
and b.cd_no=a.cd_no
union all
select 'torderdtl.ord_job_stat' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm, b.use_yn, b.reg_dm, b.user_id, b.upd_dm 
from tcode a, tcodedtl b where a.cd_no='204'
and b.cd_no=a.cd_no
union all
select 'tsm_use.use_tp' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm, b.use_yn, b.reg_dm, b.user_id, b.upd_dm 
from tcode a, tcodedtl b where a.cd_no='OM07'
and b.cd_no=a.cd_no
union all
select 'torderclm.post_cfm_cl' column_name, a.cd_no, a.cd_nm, b.cd_dtl_no, b.cd_dtl_nm, b.use_yn, b.reg_dm, b.user_id, b.upd_dm 
from tcode a, tcodedtl b where a.cd_no='CR22'
and b.cd_no=a.cd_no
</queryString>
	</sql>
</query>