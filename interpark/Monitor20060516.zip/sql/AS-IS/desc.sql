<?xml version="1.0" encoding="euc-kr"?>
<query>	
	<sql>
		<database>comdb</database>
		<comment>desc</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
 
select a.column_id,                                                              
 		(select /*+rule*/ c.position from all_cons_columns c, all_constraints d  
	    where c.table_name= a.table_name                                         
        and c.column_name = a.column_name                                        
		and c.owner = a.owner                                                    
		and d.owner = c.owner                                                    
		and d.table_name = c.table_name                                          
	    and d.constraint_name = c.constraint_name                                
	    and d.constraint_type = 'P'                                              
	   ) pk,                                                                     
	   a.column_name, a.data_type, a.data_length,                                
	   a.nullable, a.data_default, b.comments                                    
 	   from all_tab_columns a, all_col_comments b                                
	   where a.table_name=?                                                      
	   and b.table_name = a.table_name                                           
	   and b.column_name = a.column_name                                         
	   and b.owner = a.owner  
   </queryString>
   </sql>
   		<parameter>tablename</parameter>
</query>


         