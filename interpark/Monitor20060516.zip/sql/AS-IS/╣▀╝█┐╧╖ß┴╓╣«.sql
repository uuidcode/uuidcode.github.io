<?xml version="1.0" encoding="euc-kr"?>
<query>	
	<sql>
		<database>comdb</database>
		<comment>�߼ۿϷ��ֹ�</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
 SELECT 
 a.ord_no ord_no, 
 scm_timebyordno(a.pay_dm) ordr_pay_dm, 
 substr(g.delv_cfm_dt,0,4)||'-'||substr(g.delv_cfm_dt,5,2)||'-'||substr(g.delv_cfm_dt,7,2) delv_cfm_dt, 
 decode(b.BUY_CFM_DM,null,'N','Y') BUY_CFM_YN, 
 scm_timebyString(b.BUY_CFM_DM) BUY_CFM_DM, 
 a.ordr_nm_fst ordr_nm_fst,  
 f.RCVR_NM_FST, 
 b.goods_no, 
 scm_planeText(b.goods_nm) goods_nm, 
 (b.delv_accm_cnt) ord_cnt, 
 (b.delv_accm_cnt)*(b.sale_pr + nvl(b.goods_add_amt, 0)/b.goods_cnt) sale_amt,
 (b.delv_accm_cnt)*(b.goods_add_amt/b.goods_cnt) goods_add_amt,
 (                                                           
select                                                       
case when (select nvl(sum(case when clm_stat_cl='05' then    
	   nvl(rtn_end_cnt, 0)                                   
	   else                                                  
	   -nvl(rtn_end_cnt, 0)                                  
	   end), 0) from torderclm                               
	   where ord_no = b.ord_no                               
	   and ord_seq = b.ord_seq                               
	   and clm_req_tp='01'                                   
	   and clm_stat_cl in ('05', '10')) &gt; 0 then             
	   'Y'                                                   
	   else                                                  
	   'N'                                                   
	   end from dual                                         
 ) return_yn,                                                
 (                                                           
select nvl(sum(case when clm_stat_cl='05' then               
	   nvl(rtn_end_cnt, 0)                                   
	   else                                                  
	   -nvl(rtn_end_cnt, 0)                                  
	   end), 0)  from torderclm                              
	   where ord_no = b.ord_no                               
	   and ord_seq = b.ord_seq                               
	   and clm_req_tp='01'                                   
	   and clm_stat_cl in ('05', '10')                       
 ) return_goods_cnt,                                         
 (                                                           
select nvl(sum(case when clm_stat_cl='05' then               
	   nvl(rtn_end_cnt, 0)                                   
	   else                                                  
	   -nvl(rtn_end_cnt, 0)                                  
	   end), 0)  from torderclm                              
	   where ord_no = b.ord_no                               
	   and ord_seq = b.ord_seq                               
	   and clm_req_tp='01'                                   
	   and clm_stat_cl in ('05', '10')                       
 )*(b.sale_pr + nvl(b.goods_add_amt, 0)/b.goods_cnt) return_goods_amt, 
 (b.goods_cnt - b.ord_cncl_cnt) fin_ord_cnt, 
 (b.goods_cnt - b.ord_cncl_cnt)*(b.sale_pr + nvl(b.goods_add_amt, 0)/b.goods_cnt) fin_ord_amt, 
 b.ord_add_amt, 
 round((delv_accm_cnt - (                                     
select nvl(sum(case when clm_stat_cl='05' then               
	   nvl(rtn_end_cnt, 0)                                   
	   else                                                  
	   -nvl(rtn_end_cnt, 0)                                  
	   end), 0)  from torderclm                              
	   where ord_no = b.ord_no                               
	   and ord_seq = b.ord_seq                               
	   and clm_req_tp='01'                                   
	   and clm_stat_cl in ('05', '10')                       
 )                                                            
 )* (b.sale_pr + nvl(b.goods_add_amt, 0)/b.goods_cnt) * b.com_rt/100) com_amt,
 to_char(b.com_rt,'999,999.99')||'%' com_rt, 
 scm_finalOrdCnt(b.ord_no,b.ord_seq)*b.base_point point_amt, 
 scm_finalOrdCnt(b.ord_no,b.ord_seq)*b.base_point point_fee, 
 backend.F_GET_FreeFee(b.ord_no, b.ord_seq) installment_fee,
 (select nvl(allt_mon_cnt,null) from tpgpaydtl where comp_code in('7530','7900','8100') and ord_no = a.ord_no and pg_inv_tp = '1' and pay_cncl_cl = '1' and (pay_job_stat = '01' or pay_job_stat = '04') ) allt_mon_cnt 
 FROM                                                                                                           
 	( SELECT ROWID rid , ord_no, delv_no                                                                        
    FROM   torderdtl                                                                                            
 		   WHERE  man_entr_no = ?                                                                   
 		   AND    shop_no = ?
 		   AND    ship_yn = 'N'                                                                                 
 		   and    ord_no &gt;= ?
 		   and    ord_no &lt;= ?
 		  ) b1 ,                                                                                                
  torder a, torderdtl  b, tshopentr d,                                                                          
  torderdelv f, torderdelvdtl g, ec.ttaxbillreqom h                                          
 WHERE  a.ord_dm &gt;= ?
 AND a.ord_dm &lt;= ?
 and b1.ord_no = a.ord_no                                                                                       
 AND b1.rid = b.rowid                                                                                           
 AND b.man_entr_no = d.entr_no                                                                                  
 AND b.shop_no     = d.shop_no                                                                                  
 AND b.delv_no     = f.delv_no                                                                                  
 AND b.ord_no      = g.ord_no                                                                                   
 AND b.ord_seq      = g.ord_seq                                                                                 
 AND b.ship_yn     = 'N'                                                                                        
 AND b.ord_job_stat = '04'                                                                                     
 AND b.shop_no = h.shop_no (+)                                                                                 
 AND b.ord_no  = h.ord_no (+)                                                                                  
 AND b.man_entr_no = h.entr_no (+) 
 </queryString>
   </sql>
   		<parameter>entr_no</parameter>
   		<parameter>shop_no</parameter>
   		<parameter>start_ord_dm</parameter>
   		<parameter>end_ord_dm</parameter>
   		<parameter>start_ord_dm</parameter>
   		<parameter>end_ord_dm</parameter>
</query>