<?xml version="1.0" encoding="euc-kr"?>
<query>	
	<sql>
		<database>comdb</database>
		<comment>���ֻ���</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
	select /*+ index(a torderdtl_idx13, a torderdtl_idx17) */ 
	b.cd_dtl_nm "���ֻ���", a.po_status, c.cd_dtl_nm, a.ord_job_stat "�ֹ�����", a.* 
	from torderdtl a, tcodedtl b, tcodedtl c, tshopentr d
	where a.ord_no >= to_char(sysdate - ?, 'YYYYMMDD')
	and a.ord_job_stat in ('10', '11')
	and b.cd_no='DL04'
	and b.cd_dtl_no = a.po_status
	and c.cd_no='204'
	and c.cd_dtl_no = a.ord_job_stat
	and d.shop_no = a.shop_no
	and d.entr_no = a.man_entr_no
	and d.reg_entr_tp=?
 	</queryString>
 	</sql>
	<parameter>shop_no</parameter>
	<parameter>entr_no</parameter>
</query>