<?xml version="1.0" encoding="euc-kr"?>
<query>	
<sql>
<database>ora8i</database>
<comment>���ݰ�꼭 - SCM</comment>
<reportable>false</reportable>
	<chartable>false</chartable>
						<queryString>
	select																
	(select count(*) from ac_vat                                        
			where vat_sys='SCM') ȸ��,                                   
	(select count(*) from tb_po075@comdb                                
			where bill_tp='1'                                           
		   	and bill_stat in ('01', '02')                               
			and vat_bill_no is not null
			and gubun='B') ����,                           
	(select count(*) from ts_taxinvoice                                 
			where ti_docstate in ('ST01', 'ST03', 'ST05')
			and nvl(ti_gubun, 'B') = 'B') eTax,        
    (select count(*) from tax.ts_taxinvoice                                 
			where ti_docstate in ('ST01')
			and nvl(ti_gubun, 'B') = 'B')  �̽���,  
	(select count(*) from ts_taxinvoice where nvl(ti_gubun, 'B') = 'B') eTaxTotal                      
	from dual
	</queryString>
			</sql>
			<sql>
						<database>ora8i</database>
						<comment>���ݰ�꼭 - ILS</comment>
						<reportable>false</reportable>
						<chartable>false</chartable>
						<queryString>
	select																
	(select count(*) from ac_vat                                        
			where vat_sys='ILS' and vat_slip_sacode is null) ȸ��,                                   
	(select count(*) from tb_po075@comdb                                
			where bill_tp in ('1')                                           
		   	and bill_stat in ('01', '02')                               
			and vat_bill_no is not null
			and gubun='D') ����,
	(select count(*) from tb_po075@comdb                                
			where bill_tp='1'
			and vat_bill_no is not null
			and gubun='D') ����Total,
	(select count(*) from ts_taxinvoice                                 
			where ti_docstate in ('ST01', 'ST03', 'ST05')
			and nvl(ti_gubun, 'B') = 'D') eTax,        
    (select count(*) from tax.ts_taxinvoice                                 
			where ti_docstate in ('ST01')
			and nvl(ti_gubun, 'B') = 'D') �̽���,  
	(select count(*) from ts_taxinvoice where nvl(ti_gubun, 'B') = 'D') eTaxTotal                      
	from dual
	</queryString>
		</sql>
		<sql>
						<database>ora8i</database>
						<comment>���⼼�ݰ�꼭 - t_res</comment>
						<reportable>true</reportable>
						<chartable>false</chartable>
<queryString>
select b.k_name doc, count(*) cnt from t_res a, t_docs b 
where res_date &gt; to_char(sysdate, 'YYYYMM')
and a.doc_code = b.doc_code 
group by b.k_name
</queryString>
</sql>
<sql>
<database>ora8i</database>
<comment>���⼼�ݰ�꼭 - t_roor</comment>
<reportable>true</reportable>
<chartable>false</chartable>
<queryString>
select b.k_name doc, count(*) cnt from t_root a, t_docs b 
 where res_date &gt; to_char(sysdate, 'YYYYMM')
 and a.doc_code = b.doc_code 
 group by b.k_name
</queryString>
</sql>
</query>
