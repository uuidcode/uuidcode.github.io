<?xml version="1.0" encoding="euc-kr"?>
<query>	
		<sql>
				<database>comdb</database>
				<comment>��ǰ</comment>
				<reportable>false</reportable>
				<chartable>false</chartable>
				<queryString>
	select 
c.goods_no,
c.goods_nm,
e.cd_dtl_nm || '(' || c.sale_stat_cl || ')' sale_stat_cl,
c.com_rt,
c.reg_dm,
c.upd_dm,
c.sale_str_dm,
c.sale_end_dm,
c.user_id,
f.cd_dtl_nm || '(' || c.spe_sale_tp || ')' spe_sale_tp,
c.spe_str_dm,
c.spe_end_dm,
c.spe_sale_amt,
c.spe_sale_cost,
c.spe_lmt_cnt,
c.*
 from tgoodsdepl c, tcodedtl e,  tcodedtl f
 where c.goods_no=?
  and e.cd_no='27'
  and e.cd_dtl_no = c.sale_stat_cl
  and f.cd_no='26'
  and f.cd_dtl_no = c.spe_sale_tp
  </queryString>
   		</sql>
   		<sql>
   			<database>comdb</database>
				<comment>����</comment>
				<reportable>false</reportable>
				<chartable>false</chartable>
				<queryString>
   	select a.disp_no,  
  case 
	 when length(a.disp_no) = 18 then
		   (select disp_nm from tshopdispdepl where shop_no='0000100000'
		    and disp_no=substr(a.disp_no, 0, 6)) || '_' ||
		   (select disp_nm from tshopdispdepl where shop_no='0000100000'
		   and disp_no=substr(a.disp_no, 0, 9))  || '_' ||
		   (select disp_nm from tshopdispdepl where shop_no='0000100000'
		   and disp_no=substr(a.disp_no, 0, 12)) || '_' ||
		   (select disp_nm from tshopdispdepl where shop_no='0000100000'
		   and disp_no=substr(a.disp_no, 0, 15)) || '_' ||
		   (select disp_nm from tshopdispdepl where shop_no='0000100000'
		   and disp_no=a.disp_no) 
	  when length(a.disp_no) = 15 then
		   (select disp_nm from tshopdispdepl where shop_no='0000100000'
		    and disp_no=substr(a.disp_no, 0, 6)) || '_' ||
		   (select disp_nm from tshopdispdepl where shop_no='0000100000'
		   and disp_no=substr(a.disp_no, 0, 9))  || '_' ||
		   (select disp_nm from tshopdispdepl where shop_no='0000100000'
		   and disp_no=substr(a.disp_no, 0, 12)) || '_' ||
		   (select disp_nm from tshopdispdepl where shop_no='0000100000'
		   and disp_no=a.disp_no) 
	   when length(a.disp_no) = 12 then
		   (select disp_nm from tshopdispdepl where shop_no='0000100000'
		    and disp_no=substr(a.disp_no, 0, 6)) || '_' ||
		   (select disp_nm from tshopdispdepl where shop_no='0000100000'
		   and disp_no=substr(a.disp_no, 0, 9))  || '_' ||
		   (select disp_nm from tshopdispdepl where shop_no='0000100000'
     	    and disp_no=a.disp_no)
	 when length(a.disp_no) = 9 then
		   (select disp_nm from tshopdispdepl where shop_no='0000100000'
		    and disp_no=substr(a.disp_no, 0, 6)) || '_' ||
		   (select disp_nm from tshopdispdepl where shop_no='0000100000'
     	    and disp_no=a.disp_no)
	   end disp_nm 
	   from tomgoodsclass_disp a, tgoodsdepl c, tshopdispgoodsdepl d
       where c.goods_no=?
		  and d.goods_no = c.goods_no
		  and d.shop_no = '0000100000'
		  and a.shop_no='0000100000'
		  and a.disp_no = d.disp_no
	</queryString>
		</sql>
		<sql>
			<database>comdb</database>
				<comment>�ɼ�</comment>
				<reportable>false</reportable>
				<chartable>false</chartable>
			<queryString>
	select * from tgoodsoptdepl where goods_no=?
	</queryString>
		</sql>
		<sql>
			<database>comdb</database>
				<comment>�ɼ����</comment>
				<reportable>false</reportable>
				<chartable>false</chartable>
			<queryString>
		  select * from tb_cm051 where goods_no=?
	</queryString>
		</sql>
	<sql>
			<database>comdb</database>
				<comment>history</comment>
				<reportable>false</reportable>
				<chartable>false</chartable>
			<queryString>
		  select * from tgoodsdeplhis where goods_no=? order by bind_dm
	</queryString>
		</sql>
   	<parameter>goods_no</parameter>
</query>