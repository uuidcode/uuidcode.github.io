<?xml version="1.0" encoding="euc-kr"?>
<query>	
	<sql>
		<database>comdb</database>
		<comment>��ǰ������</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
	select /*+ index(a tgoodsdepl_idx12) */
	'OpenMarket_' || substr(a.reg_dm, 0, 8) || '_�ɼ�' || decode(goods_opt_yn, '1', '����', '����') || 
	'_�ɼ����' || decode(optstk_yn, 'Y', '����', '����') state, 
	count(*) cnt  from tgoodsdepl a
	  where reg_dm between ? || '000000' and  ? || '235959'
	  and reg_entr_tp='O'
	  group by substr(a.reg_dm, 0, 8), goods_opt_yn, optstk_yn
   </queryString>
   </sql>
	 <parameter>start_dm</parameter>
	 <parameter>end_dm</parameter>
</query>