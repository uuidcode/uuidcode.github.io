<?xml version="1.0" encoding="euc-kr"?>
<query>	
		<sql>
				<database>comdb</database>
				<comment>10�ϰ���ǰ�Ǹ����</comment>
				<reportable>false</reportable>
				<chartable>true</chartable>
				<type>day</type>
				<date>��¥</date>
				<count>����</count>
				<queryString>
  select yyyymmdd ��¥, count(*) ����  from TENTRGOODSCNT 
  where yyyymmdd&gt;=to_char(sysdate - 10, 'YYYYMMDD') group by yyyymmdd
  order by yyyymmdd desc
  		 </queryString>
   	</sql>
</query>