<?xml version="1.0" encoding="euc-kr"?>
<query>	
	<sql>
		<database>comdb</database>
		<comment>SMoney</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
	select
	(select count(*) from tsm_ordd_sm where sm_amt &lt; (tot_use_amt + tot_repay_amt + repay_cfm_amt)) "���ݾ׻���",
	(select count(*) from tsm_ordd_sm where sm_amt = (tot_use_amt + tot_repay_amt + repay_cfm_amt) and sm_stat &lt;&gt; '9') "������ó��"
	from dual
   </queryString>
   </sql>
</query>