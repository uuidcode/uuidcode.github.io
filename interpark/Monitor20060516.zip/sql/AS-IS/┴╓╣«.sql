<?xml version="1.0" encoding="euc-kr"?>
<query>	
	<sql>
		<database>comdb</database>
		<comment>torder</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
		select * from torder where ord_no=?
		</queryString>
	</sql>
	<sql>
		<database>comdb</database>
		<comment>torderdtl</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
		select * from torderdtl where ord_no=?
		</queryString>
	</sql>
	<sql>
		<database>comdb</database>
		<comment>torderdelv</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
		select /*+ index(a torderdtl_idx0) index(b torderdelv_idx0)*/ b.* 
		from  torderdtl a, torderdelv b where a.ord_no=?
	    and b.delv_no = a.delv_no
	</queryString>
	</sql>
	<sql>
		<database>comdb</database>
		<comment>torderdelvdtl</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
		select * from torderdelvdtl where ord_no=?
	</queryString>
	</sql>
	<sql>
		<database>comdb</database>
		<comment>tb_dl040</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
		select * from tb_dl040 where ord_no=?
	</queryString>
	</sql>
	<sql>
		<database>comdb</database>
		<comment>torderclm</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
		select * from torderclm where ord_no=?
	    </queryString>
	</sql>
   	<parameter>ord_no</parameter>
</query>