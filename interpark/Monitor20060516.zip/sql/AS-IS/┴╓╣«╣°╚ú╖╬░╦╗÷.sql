<?xml version="1.0" encoding="euc-kr"?>
<query>	
	<sql>
		<database>comdb</database>
		<comment>�ֹ���ȣ�� �˻�</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
select c.bus_no, c.entr_tp, d.scm_entr_tp, e.mem_no, e.mem_id, e.mem_pwd, c.reg_entr_tp, c.omshop_no,
	   c.entr_no, d.entr_stat_cl, c.shop_no, c.entr_nm, c.user_id, 
	   entr_dm_yn, penalty_yn, d.whole_delv_yn, d.sos_mail_yn, statistics_yn, d.ship_yn, d.bill_tp
	    from torder a, torderdtl b, tshopentr c, tshopentrmall d, tmember e 
	    where a.ord_no=?	   
	   and a.ord_no = b.ord_no
	   and b.man_entr_no = c.entr_no
	   and b.shop_no = c.shop_no
	   and b.man_entr_no = d.entr_no
	   and b.shop_no = d.shop_no 
	   and c.mem_no = e.mem_no
	 </queryString>
</sql>
	 <parameter>ord_no</parameter>	
</query>


