<?xml version="1.0" encoding="euc-kr"?>
<query>	
	<sql>
		<database>comdb</database>
		<comment>�κй�ǰ</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
 select a.ord_no, a.ord_seq, a.man_entr_no, 
 a.goods_cnt, a.ord_cncl_cnt, 
 b.clm_stat_cl, a.reted_qty from torderdtl a, torderclm b 
 where a.ord_no &gt; ?
 and a.reg_entr_tp='O'
 and a.po_status = '02'
 and a.ord_job_stat='04'
 and a.goods_cnt - a.ord_cncl_cnt &gt; 0
 and b.ord_no = a.ord_no
 and b.ord_seq = a.ord_seq
 and b.clm_req_tp='01'
 and b.clm_stat_cl not in ('05', '10', '00')
 and rownum &lt; ?
   </queryString>
   </sql>
   		<parameter>from</parameter>
   		<parameter>row</parameter>
</query>

