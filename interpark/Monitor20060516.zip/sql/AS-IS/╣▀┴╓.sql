<?xml version="1.0" encoding="euc-kr"?>
<query>	
	<sql>
		<database>comdb</database>
		<comment>����</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
select /*+ index(a torderdtl_idx13, a torderdtl_idx19, d tshopentr_idx4) use_nl(a b c d e) */ 
	b.cd_dtl_nm "���ֻ���", a.po_status, c.cd_dtl_nm, a.ord_job_stat "�ֹ�����", a.* 
	from torderdtl a, tcodedtl b, tcodedtl c, tshopentr d, torderdelv e
	where a.ord_no &gt;= to_char(sysdate, 'YYYYMMDD')
	and a.ord_job_stat in ('10', '11')
	and a.ship_yn='N'
	and b.cd_no='DL04'
	and b.cd_dtl_no = a.po_status
	and c.cd_no='204'
	and c.cd_dtl_no = a.ord_job_stat
	and d.shop_no = a.shop_no
	and d.entr_no = a.man_entr_no
	and d.mem_no &gt; '0'
	and d.reg_entr_tp=?
	and d.use_yn='1'
	and e.delv_no = a.delv_no
 	</queryString>
 	</sql>
   		<parameter>regEntrTp</parameter>
</query>