<?xml version="1.0" encoding="euc-kr"?>
<query>	
		<sql>
				<database>comdb</database>
				<comment>OM �ð��뺰 ��ǰ ������</comment>
				<reportable>false</reportable>
				<chartable>true</chartable>
				<type>hour</type>
				<date>��¥</date>
				<count>����</count>
				<queryString>
	select /*+ index(a tgoodsdepl_idx12) */
	substr(a.reg_dm, 0, 10) ��¥, count(*) ����  from tgoodsdepl a
	  where reg_dm &gt;= to_char(sysdate, 'YYYYMMDD')
	  and reg_entr_tp='O'
	  group by substr(a.reg_dm, 0, 10)
	</queryString>
		</sql>
		<sql>
			<database>comdb</database>
				<comment>SCM �ð��뺰 ��ǰ ������</comment>
				<reportable>false</reportable>
				<chartable>true</chartable>
				<type>hour</type>
				<date>��¥</date>
				<count>����</count>
			<queryString>
	  select /*+ index(a tgoodsdepl_idx12) */
	substr(a.reg_dm, 0, 10) ��¥, count(*) ����  from tgoodsdepl a
	  where reg_dm &gt;= to_char(sysdate, 'YYYYMMDD')
	  and reg_entr_tp='M'
	  group by substr(a.reg_dm, 0, 10)
   </queryString>
   	</sql>
</query>