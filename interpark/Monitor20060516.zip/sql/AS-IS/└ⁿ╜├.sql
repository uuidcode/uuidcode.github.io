<?xml version="1.0" encoding="euc-kr"?>
<query>	
	<sql>
		<database>comdb</database>
		<comment>����</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
SELECT /* + ordered use_nl(b a) index(a TSHOPDISPDEPL_IDX0) */
	   a.disp_no dno, 
	   a.disp_nm dnm, 
	   a.disp_no dispno
 FROM   tshopdispdepl a  
 WHERE  LENGTH( a.disp_no ) > 3
 START WITH (a.shop_no, a.disp_no) = 
         (select '0000100000',  (select disp_no from tshopdispgoodsdepl where goods_no=?) from dual)
 CONNECT BY PRIOR a.high_disp_no = a.disp_no
 AND        PRIOR a.shop_no = a.shop_no
 ORDER  BY a.disp_no ASC
 </queryString>
 </sql>
	 <parameter>goods_no</parameter>	
</query>