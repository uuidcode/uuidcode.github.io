<?xml version="1.0" encoding="euc-kr"?>
<query>	
	<sql>
		<database>comdb</database>
		<comment>��ǰ����Ʈ</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
	 SELECT * 
	 FROM ( 
	 SELECT /*+ index(c torderclm_idx6) use_nl(c a b) */  
	 a.ord_no ord_no, 
	 a.ordr_nm_fst ordr_nm_fst, 
	 scm_planeText(b.goods_nm) goods_nm, 
	 b.goods_cnt sale_qty, 
	 a.pay_dm pay_dm, 
	 b.ord_confirm_dm  ord_confirm_dm, 
	 c.clm_crt_dm clm_crt_dm, 
	 d.zip_cd ||'-'|| d.zip_addr1 || d.zip_addr2 || d.dtl_addr recall_dist , 
	 c.post_dm post_dm, 
	 c.rsn_cd rsn_cd, 
	 f.real_cost_share real_cost_share, 
	 c.cost_share  cost_share, 
	 func.GetCodeName('CR08',f.cost_share) cost_share_nm, 
	 c.invoice_no invoice_no, 
	 DECODE(c.clm_stat_cl,'02',e.delv_entr_no,c.delv_entr_no) delv_entr_no, 
	 b.ord_seq ord_seq, 
	 c.clm_seq clm_seq, 
	 b.goods_no goods_no, 
	 c.clm_cnt clm_cnt, 
	 c.duty_tp duty_tp, 
	 f.ship_amt ship_amt, 
	 DECODE(c.clm_stat_cl ,'02','����','Ȯ��') clm_type_nm, 
	 c.clm_stat_cl clm_stat_cl 
	 FROM      torder a, torderdtl b, torderclm c, torderdelv d, tshopentr e, tb_cr070 f 
	 WHERE     c.entr_no = ?   
	 AND       b.shop_no     = ?  
	 AND       c.clm_crt_dm between ? and ?
	 AND       c.clm_req_tp  = '01' 
	 AND	   c.clm_stat_cl IN ('02' ,'04','05') 
	 AND       c.ord_no      = b.ord_no  
	 AND       c.ord_seq     = b.ord_seq 
	 AND       b.ord_no      = a.ord_no  
	 AND       b.delv_no     = d.delv_no 
	 AND       b.shop_no     = e.shop_no 
	 AND       b.man_entr_no = e.entr_no 
	 AND       c.ord_no      = f.ord_no  (+) 
	 AND       c.ord_seq     = f.ord_seq (+) 
	 AND       c.clm_seq     = f.clm_seq (+) 
	 AND	    b.ship_yn     = 'N'           
	 ) 
	 ORDER BY ordr_nm_fst asc, ord_no asc 
 </queryString>
 </sql>
  <parameter>entr_no</parameter>	
  <parameter>shop_no</parameter>
  <parameter>clm_crt_dm from</parameter>
  <parameter>clm_crt_dm to</parameter>
</query>