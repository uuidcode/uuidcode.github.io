<?xml version="1.0" encoding="euc-kr"?>
<query>	
			<sql>
						<database>comdb</database>
						<comment>10�ϰ� �����ù� ��û ��</comment>
						<reportable>false</reportable>
						<chartable>true</chartable>
						<type>day</type>
						<date>��¥</date>
						<count>����</count>
						<groupBy>Ÿ��</groupBy>
						<queryString>
			select  substr(a.ord_no, 0, 8) ��¥, nvl(b.reg_entr_tp, 'M') Ÿ��, count(*) ���� from torderdtl a, torderdtl b 
	   where a.ord_no > to_char(sysdate - 10, 'YYYYMMDD') 
	   and a.ord_no = b.ord_no
	   and a.ord_seq = b.ord_seq 
	   and b.po_status='15'
	   group by substr(a.ord_no, 0, 8), nvl(b.reg_entr_tp, 'M')
		</queryString>
			</sql>
</query>