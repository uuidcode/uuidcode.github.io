<?xml version="1.0" encoding="euc-kr"?>
<query>	
	<sql>
		<database>comdb</database>
		<comment>��ȯ</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
select 
	   /*+ ordered(a b c d)*/
	   a.ord_no, a.ord_seq, a.clm_seq, 
                        d.cd_dtl_nm || '(' || a.clm_stat_cl || ')' clm_stat_cl, 
                        a.goods_no, b.goods_nm, c.entr_no, c.shop_no 
	   from torderclm a, torderdtl b, tshopentr c, tcodedtl d 
	   where a.clm_req_tp  in ('03', '04') 
       AND a.clm_stat_cl IN ('02', '04', '05')
       and a.ord_no &gt;= to_char(sysdate - ?, 'YYYYMMDD')
	   and b.ord_no = a.ord_no
	   and b.ord_seq = a.ord_seq
	   and b.ship_yn = 'N'
	   and c.shop_no = b.shop_no
	   and c.entr_no = b.man_entr_no
	   and c.reg_entr_tp=?
	   and d.cd_no='43'
	   and d.cd_dtl_no=a.clm_stat_cl
   </queryString>
   </sql>
   		<parameter>howLongDays</parameter>
   		<parameter>regEntrTp</parameter>
</query>