<?xml version="1.0" encoding="euc-kr"?>
<query>	
	<sql>
		<database>ora8i</database>
		<comment>���ڰ�༭</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
select
(select count(*) from TBPK0030A) ���ڰ�༭��,
(select count(*) from TBCD1310M) ��ü�� from dual
	</queryString>
	</sql>
</query>