<?xml version="1.0" encoding="euc-kr"?>
<query>	
	<sql>
		<database>comdb</database>
		<comment>��ü��ȣ�� �˻�</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
 select  goods_ord_tp, b.bus_no, b.entr_tp, c.scm_entr_tp, 
 		a.mem_no, a.mem_id, mem_pwd, b.reg_entr_tp, omshop_no,
		  b.entr_no, c.entr_stat_cl, b.shop_no, entr_nm, b.user_id, 
	   entr_dm_yn, penalty_yn, c.whole_delv_yn, c.sos_mail_yn,
	   statistics_yn, c.ship_yn, c.bill_tp
	   from tmember a, tshopentr b, tshopentrmall c
	   where a.mem_no = b.mem_no
	   and b.entr_no = c.entr_no
	   and b.shop_no = c.shop_no
	   and b.entr_no in (?)
	 </queryString>
	 </sql>
	 <parameter>entr_no</parameter>	
</query>
