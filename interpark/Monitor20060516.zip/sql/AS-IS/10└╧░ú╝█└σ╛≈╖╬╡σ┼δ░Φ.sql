<?xml version="1.0" encoding="euc-kr"?>
<query>	
		<sql>
				<database>comdb</database>
				<comment>10�ϰ� ������ε� ���</comment>
				<reportable>false</reportable>
				<chartable>true</chartable>
				<type>day</type>
				<date>��¥</date>
				<count>����</count>
				<groupBy>Ÿ��</groupBy>
				<queryString>
       select substr(a.upload_dtseq, 0, 8) ��¥, b.reg_entr_tp Ÿ��, count(*) ���� from tdelvfile_d a, tshopentr b 
		where a.upload_dtseq &gt;= to_char(sysdate - 10, 'YYYYMMDD') 
		and a.entr_no = b.entr_no
		group by substr(a.upload_dtseq, 0, 8), b.reg_entr_tp
	   </queryString>
   	</sql>
</query>