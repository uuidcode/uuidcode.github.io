<?xml version="1.0" encoding="euc-kr"?>
<query>	
		<sql>
<database>comdb</database>
<comment>10�ϰ� �Ǹ��� Ż�� ��û</comment>
<reportable>false</reportable>
				<chartable>true</chartable>
				<date>��¥</date>
				<count>����</count>
				<type>day</type>
				<queryString> select  /*+ ordered(a, b) use_nl(a, b)*/
		substr(a.entr_stat_dm, 0, 8) ��¥, a.shop_no, a.entr_no,  
		(select count(*) from tsm_ordd_sm where shop_no = a.shop_no and entr_no = a.entr_no and sm_tp='01') cash,
		(select count(*) from tsm_ordd_sm 
				where shop_no = a.shop_no
				 and entr_no = a.entr_no 
				 and sm_tp='01' 
				 and sm_amt = (tot_use_amt + tot_repay_amt + repay_cfm_amt) 
				 and sm_stat='9') repaidcash,
		1 ����
		from tshopentrmall a, tshopentr b
		where a.entr_stat_dm &gt;= to_char(sysdate - 10, 'YYYYMMDD') || '000000'
		and a.entr_stat_cl='004'
		and b.entr_no = a.entr_no
		and b.shop_no = a.shop_no
		and b.entr_tp in ('6', '7')
		group by a.shop_no, a.entr_no, a.entr_stat_dm
		order by a.entr_stat_dm
		</queryString>
		</sql>
</query>
