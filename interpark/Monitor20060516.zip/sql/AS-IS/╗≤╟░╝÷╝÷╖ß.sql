<?xml version="1.0" encoding="euc-kr"?>
<query>	
	<sql>
		<database>comdb</database>
		<comment>��ǰ������</comment>
		<reportable>false</reportable>
		<chartable>false</chartable>
		<queryString>
select a.com_rt, b.omsale_fee from tgoodsdepl a, tb_cm030 b
	   where a.goods_no = ?
	   and a.class1 = b.class1
	   and a.class2 = b.class2
	   and a.class3 = b.class3
	   and a.class4 = b.class4
	 </queryString>
	 </sql>
	 <parameter>goods_no</parameter>	
</query>


