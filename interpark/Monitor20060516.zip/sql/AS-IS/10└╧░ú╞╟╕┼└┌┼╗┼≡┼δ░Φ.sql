<?xml version="1.0" encoding="euc-kr"?>
<query>	
		<sql>
				<database>comdb</database>
				<comment>10�ϰ� �Ǹ��� Ż��</comment>
				<reportable>false</reportable>
				<chartable>true</chartable>
				<type>day</type>
				<date>��¥</date>
				<count>����</count>
	  		<queryString>
select substr(entr_stat_dm, 0, 8) ��¥, count(*) ���� from tshopentrmall 
   	   where entr_stat_cl = '003'
   	   and entr_stat_dm &gt;= to_char(sysdate - 10, 'YYYYMMDD') || '000000'
	  group by substr(entr_stat_dm, 0, 8)
	</queryString>
		</sql>
</query>