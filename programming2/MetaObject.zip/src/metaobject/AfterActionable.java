package metaobject;

public interface AfterActionable {
	public void afterAdd();
	public void afterEdit();
	public void afterRemove();
}
