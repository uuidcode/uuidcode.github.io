package metaobject;

public interface Validatable {
	public boolean isAddable();
	public boolean isEditalbe();
	public boolean isRemovable();
}
