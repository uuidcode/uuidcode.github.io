package metaobject;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MetaObjectFormDialog extends JDialog {
	public final static int OK = 1;
	private int stat = 0;
	
	public MetaObjectFormDialog(
		Container owner,
		final MetaObject object,
		String title,
		boolean editing) {
		super(UIUtilities.getFrame(owner), title, true);

		String keyValue = object.getKeyField().getValue();
		if (keyValue == null || keyValue.trim().length() == 0) {
			keyValue = String.valueOf(System.currentTimeMillis());
			object.getKeyField().setValue(keyValue);
		}
		
		try {
			MetaField[] fields = XMLObject.getField(object);
			int rowCount = 0;
			for (int i = 0; i < fields.length; i++) {
				if (fields[i].visibleInForm) {
					rowCount++;
				}
			}

			JPanel panel = new JPanel(new GridLayout2(rowCount, 2));

			for (int i = 0; i < fields.length; i++) {
				if (fields[i].visibleInForm) {
					panel.add(new JLabel(fields[i].displayName));
					JPanel fieldPanel =
						new JPanel(new FlowLayout(FlowLayout.LEFT));
					
					if (fields[i].type == MetaField.IMAGE) {
						File imageFile = new File(fields[i].getValue());
						if (imageFile.exists()) {
							fieldPanel.add(new ImageLabel(imageFile.getName()));	 
						}						
					}
					fieldPanel.add(fields[i].textField);
					panel.add(fieldPanel);
				}
			}

			panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

			JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
			JButton okButton = new JButton("OK");
			okButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					stat = OK;
					XMLObject.save(object);
					dispose();
				}
			});
			bottomPanel.add(okButton);

			JButton cancelButton = new JButton("Cancel");
			cancelButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			bottomPanel.add(cancelButton);

			JPanel mainPanel = new JPanel();
			BoxLayout boxLayout = new BoxLayout(mainPanel, BoxLayout.Y_AXIS);
			mainPanel.setLayout(boxLayout);
			mainPanel.add(panel);
			//mainPanel.add(new JSeparator(SwingConstants.HORIZONTAL));
			mainPanel.add(bottomPanel);

			this.setContentPane(mainPanel);
			this.pack();
			Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
			int x = (screen.width - this.getWidth()) / 2;
			int y = (screen.height - this.getHeight()) / 2;
			this.setLocation(x, y);
			this.setResizable(false);
			this.setVisible(true);
		} catch (Exception e) {
		}
	}
	
	public int getStat() {
		return stat;
	}

}