package metaobject;

import javax.swing.BorderFactory;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.text.JTextComponent;

public class MetaField {
	public final static int TEXT = 1;
	public final static int PASSWORD = 2;
	public final static int TEXTAREA = 3;
	public final static int IMAGE = 4;
	
	public boolean visibleInForm;
	public boolean visibleInList;
	public String name;
	public String displayName;
	private String value;
	public int size;
	public JTextComponent textField;
	public int type;

	private MetaField(
		String name,
		String displayName,
		String value,
		int size,
		boolean visibleInForm,
		boolean visibleInList) {
		this.name = name;
		this.displayName = displayName;
		this.value = value;
		this.size = size;
		this.visibleInForm = visibleInForm;
		this.visibleInList = visibleInList;
	}

	public MetaField(
		String name,
		String displayName,
		String value,
		int size,
		boolean visibleInForm,
		boolean visibleInList,
		int type) {
		this(name, displayName, value, size, visibleInForm, visibleInList);
		this.type = type;
		if (type == TEXT || type == IMAGE) {
			JTextField field = new JTextField();
			field.setColumns(size);
			field.setText(this.value);
			this.textField = field;
		} else if (type == PASSWORD) {
			JPasswordField field = new JPasswordField();
			field.setColumns(size);
			field.setText(this.value);
			this.textField = field;
		} else if (type == TEXTAREA) {
			JTextArea field = new JTextArea(5, size);
			field.setBorder(BorderFactory.createEtchedBorder());
			field.setText(this.value);
			this.textField = field;
		}
	}

	public void save() {
		this.value = this.textField.getText();
	}

	public static void save(MetaField[] fields) {
		for (int i = 0; i < fields.length; i++) {
			fields[i].save();
		}
	}

	public String toString() {
		try {
			return Inspector.toString(this);
		} catch (Exception e) {
		}
		return null;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String string) {
		this.textField.setText(string);
		value = string;
	}

	public boolean equals(Object object) {
		if (object != null && object instanceof MetaField) {
			MetaField metaField = (MetaField) object;
			return this.name.equals(metaField.name);
		}
		return false;
	}
}