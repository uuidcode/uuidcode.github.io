package metaobject;

public interface MetaObject {
	public MetaField getKeyField();
	public MetaField getDisplayImageField();
}
