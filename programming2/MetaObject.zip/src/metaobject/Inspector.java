package metaobject;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;

public class Inspector {
	private Inspector() {
	}

	public static String toString(MetaObject[] objects) throws Exception {
		StringBuffer buffer = new StringBuffer();
		for (int i = 0; i < objects.length; i++) {
			buffer.append(Inspector.toString(objects[i]));
			buffer.append("\n");
		}
		return buffer.toString();
	}
	
	public static String toString(Object object) throws Exception {
		StringBuffer buffer = new StringBuffer();
		if (object instanceof MetaObject) {
			MetaObject metaObject = (MetaObject) object;
			MetaField[] metaFields = XMLObject.getField(metaObject);
			for (int i = 0; i < metaFields.length; i++) {
				buffer.append(
					"["
						+ metaFields[i].name
						+ "="
						+ metaFields[i].getValue()
						+ "]");
			}
		} else {
			Field[] fields = object.getClass().getDeclaredFields();
			AccessibleObject.setAccessible(fields, true);
			for (int i = 0; i < fields.length; i++) {
				buffer.append(
					"["
						+ fields[i].getName()
						+ "="
						+ fields[i].get(object)
						+ "]");
			}
		}
		return buffer.toString();
	}
}