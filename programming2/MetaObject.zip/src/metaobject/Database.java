package metaobject;


public class Database implements MetaObject {
	public MetaField id = new MetaField("id", "Database Name", "", 0, false, false, MetaField.TEXT);
	public MetaField name = new MetaField("name", "Database Name", "", 10, true, true, MetaField.TEXT);
	public MetaField displayImage = new MetaField("displayImage", "Display Image", "", 20, true, false, MetaField.IMAGE);
	public MetaField url = new MetaField("url", "URL", "", 30, true, true, MetaField.TEXT);
	public MetaField driver = new MetaField("driver", "JDBC Driver", "", 20, true, true, MetaField.TEXT);
	public MetaField user = new MetaField("user", "User", "", 10, true, true, MetaField.TEXT);
	public MetaField password = new MetaField("password", "Password", "", 10, true, false, MetaField.PASSWORD);
	public MetaField description = new MetaField("description", "Description", "", 30, true, false, MetaField.TEXTAREA);
	
	public MetaField getKeyField() {
		return id;
	}
	
	public MetaField getDisplayImageField() {
		return displayImage;
	}
		
	public static void main(String[] args) throws Exception {
		MetaObject[] objects = XMLObject.read(Database.class);
		System.out.println(Inspector.toString(objects));
	}
}