package metaobject;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MetaObjectManagerDialog extends JDialog implements WindowListener {
	private static MetaObjectManagerDialog serviceManager;
	public MetaObjectManagerPanel metaObjectManagerPanel;
	
	public static MetaObjectManagerDialog showDailog(
		Container owner,
		String title,
		Class c,
		int type) {
		if (serviceManager == null) {
			serviceManager = new MetaObjectManagerDialog(owner, title, c, type);
		}
		return serviceManager;
	}

	private MetaObjectManagerDialog(
		final Container owner,
		String title,
		final Class c,
		int type) {
		
		super(UIUtilities.getFrame(owner), title, false);
		this.addWindowListener(this);

		JPanel panel = new JPanel(new BorderLayout());
		panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

		this.metaObjectManagerPanel =
			new MetaObjectManagerPanel(title, c, type);
		panel.add(metaObjectManagerPanel, BorderLayout.CENTER);

		JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JButton close = new JButton("close");
		close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MetaObjectManagerDialog.this.setVisible(false);
			}
		});
		bottomPanel.add(close);
		//panel.add(bottomPanel, BorderLayout.SOUTH);
		
		JPanel contentPanel = new JPanel();
		BoxLayout boxLayout = new BoxLayout(contentPanel, BoxLayout.Y_AXIS);
		contentPanel.setLayout(boxLayout);

		contentPanel.add(panel);
//		contentPanel.add(Box.createVerticalStrut(5));
//		contentPanel.add(new JSeparator(SwingConstants.HORIZONTAL));
//		contentPanel.add(Box.createVerticalStrut(5));
		contentPanel.add(bottomPanel);
		
		//this.setContentPane(panel);
		this.setContentPane(contentPanel);
		this.pack();
		this.setResizable(true);

		int width = 800;
		int height = 400;

		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (screen.width - width) / 2;
		int y = (screen.height - height) / 2;
		setBounds(x, y, width, height);
	}

	public void windowActivated(WindowEvent e) {
	}

	public void windowClosed(WindowEvent e) {
		MetaObjectManagerDialog.this.setVisible(false);		
	}

	public void windowClosing(WindowEvent e) {
		MetaObjectManagerDialog.this.setVisible(false);		
	}

	public void windowDeactivated(WindowEvent e) {
	}

	public void windowDeiconified(WindowEvent e) {
	}

	public void windowIconified(WindowEvent e) {
	}

	public void windowOpened(WindowEvent e) {
	}
	
	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		MetaObjectManagerDialog dialog = MetaObjectManagerDialog.showDailog(f, "Test", Database.class, MetaObjectManagerPanel.LIST);
		dialog.setVisible(true);
	}
}