package metaobject;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class MetaObjectManagerPanel extends JPanel {
	public final static int TABLE = 0;
	public final static int LIST = 1;
	
	private static final String SUCCESS_MESSAGE = "Success to ";
	
	private int type;
	private JTable table;
	private JList list;
	private MetaObject[] metaObjects;
	private Class metaObjectClass;
	private Runnable dataBinding = null;
	private Runnable refreshing = null;
	private JPanel topPanel;
	private Validatable validatable;
	private AfterActionable afterActionable;
	private String title;
	private boolean isReloading;

	public MetaObjectManagerPanel(String title, Class metaObjectClass, int type) {
		super();
		this.setLayout(new BorderLayout());
		this.title = title;
		this.metaObjectClass = metaObjectClass;
		this.type = type;
		
		try {
			if (this.type == TABLE) {
				MetaObjectTableModel model = new MetaObjectTableModel(newInstance());
				this.table = new JTable(model);
				this.table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
				this.table.getTableHeader().setReorderingAllowed(false);
				this.add(new JScrollPane(this.table), BorderLayout.CENTER);
			} else if (this.type == LIST) {
				this.list = new JList();
				this.list.setCellRenderer(new MetaObjectCellRender(metaObjectClass));
				this.add(new JScrollPane(list), BorderLayout.CENTER);
			}

			this.reload();

			this.topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
			this.makeButton();
			this.add(topPanel, BorderLayout.NORTH);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void makeButton() {
		makeAddButton();
		makeEditButton();
		makeRemoveButton();
	}
	
	public MetaObject getSelectedMetaObject() {
		if (this.type == TABLE) {
			return this.metaObjects[this.table.getSelectedRow()];
		} else if (this.type == LIST) {
			return this.metaObjects[this.list.getSelectedIndex()];
		}
		return null;
	}
	
	private void makeRemoveButton() {
		final JButton removeButton = new JButton("remove");
		removeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MetaObject metaObject = getSelectedMetaObject();
				if (metaObject != null) {
					waitReloding();
					if (validatable == null || validatable.isRemovable()) {
						XMLObject.remove(metaObject);
						successAction(
							null,
							SUCCESS_MESSAGE + removeButton.getText());
						if (afterActionable != null) {
							afterActionable.afterRemove();
						}
					}
				}
			}
		});
		topPanel.add(removeButton);
	}

	private void makeEditButton() {
		final JButton editButton = new JButton("edit");
		editButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MetaObject metaObject = getSelectedMetaObject();
				if (metaObject != null) {
					waitReloding();
					if (validatable == null || validatable.isEditalbe()) {
						MetaObjectFormDialog metaObjectFormDailog =
							new MetaObjectFormDialog(
								MetaObjectManagerPanel.this,
								metaObject,
								MetaObjectManagerPanel.this.title,
								false);
						successAction(
							metaObjectFormDailog,
							SUCCESS_MESSAGE + editButton.getText());
						if (afterActionable != null) {
							afterActionable.afterEdit();
						}
					}
				}
			}
		});
		topPanel.add(editButton);
	}

	private void makeAddButton() {
		final JButton addButton = new JButton("add");
		addButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if (validatable == null || validatable.isAddable()) {
						MetaObject metaObject = newInstance();
						MetaObjectFormDialog metaObjectFormDailog =
							new MetaObjectFormDialog(
								MetaObjectManagerPanel.this,
								metaObject,
								MetaObjectManagerPanel.this.title,
								false);

						successAction(
							metaObjectFormDailog,
							SUCCESS_MESSAGE + addButton.getText());
						
						if (afterActionable != null) {
							afterActionable.afterAdd();
						}
					}
				} catch (Exception ex) {
				}
			}
		});
		topPanel.add(addButton);
	}

	private MetaObject newInstance() throws Exception {
		return (MetaObject) Class
			.forName(this.metaObjectClass.getName())
			.newInstance();
	}

	private void waitReloding() {
		while (isReloading) {
			try {
				Thread.sleep(500);
			} catch (Exception e) {
			}
		}
	}

	public void successAction(MetaObjectFormDialog dialog, String message) {
		boolean isOK = false;
		if (dialog != null) {
			if (dialog.getStat() == MetaObjectFormDialog.OK) {
				isOK = true;
			}
		} else {
			isOK = true;
		}

		if (isOK) {
			reload();
			JOptionPane.showMessageDialog(
				UIUtilities.getFrame(this),
				message,
				title,
				JOptionPane.INFORMATION_MESSAGE);
		}
	}

	public void failAction(String message) {
		JOptionPane.showMessageDialog(
			UIUtilities.getFrame(this),
			message,
			title,
			JOptionPane.ERROR_MESSAGE);
	}

	public void reload() {
		new Thread() {
			public void run() {
				isReloading = true;
				try {
					metaObjects = XMLObject.read(metaObjectClass);
					if (dataBinding != null) {
						dataBinding.run();
					}
					
					if (type == TABLE) {
						((MetaObjectTableModel) table.getModel()).setDataVector(metaObjects);
						UIUtilities.fixColumnSize(table);
					} else if (type == LIST) {
						list.setListData(metaObjects);
					}
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				isReloading = false;
			}
		}
		.start();
	}

	public Runnable getDataBinding() {
		return dataBinding;
	}

	public void setDataBinding(Runnable binding) {
		dataBinding = binding;
	}
	public Class getMetaObjectClass() {
		return metaObjectClass;
	}

	public MetaObject[] getMetaObjects() {
		return metaObjects;
	}

	public void setMetaObjects(MetaObject[] objects) {
		metaObjects = objects;
	}

	public void setSubComponent(JComponent[] components) {
		for (int i = 0; components != null && i < components.length; i++) {
			topPanel.add(components[i]);
		}
		topPanel.revalidate();
		topPanel.repaint();
	}

	public Runnable getRefreshing() {
		return refreshing;
	}

	public void setRefreshing(Runnable runnable) {
		if (runnable != null) {
			refreshing = runnable;
			if (refreshing != null) {
				new Thread(refreshing).start();
			}
		}
	}

	public void setValidatable(Validatable validatable) {
		this.validatable = validatable;
	}

	public boolean isReloading() {
		return isReloading;
	}
	
	public void setAfterActionable(AfterActionable actionable) {
		afterActionable = actionable;
	}
	
	public JComponent getViewComponent() {
		if (this.type == TABLE) {
			return this.table;
		} else if (this.type == LIST) {
			return this.list;
		}
		return null;
	}
}
