package metaobject;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.List;
import java.util.Vector;

import org.dom4j.CDATA;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

public class XMLObject {
	public static MetaField[] getField(MetaObject object) throws Exception {
		Field[] fields = object.getClass().getDeclaredFields();
		Vector validField = new Vector();
		AccessibleObject.setAccessible(fields, true);
		for (int i = 0; i < fields.length; i++) {
			int modifiers = fields[i].getModifiers();
			if (Modifier.isPublic(modifiers)
				&& !Modifier.isStatic(modifiers)
				&& fields[i].getType().equals(MetaField.class)) {
				validField.add(fields[i].get(object));
			}
		}
		return (MetaField[]) validField.toArray(new MetaField[0]);
	}

	private static String getClassName(Element element) {
		String className = element.getName();
		while ((element = element.getParent()) != null) {
			className = element.getName() + "." + className;
		}
		return className;
	}

	private static MetaObject element2Object(Element element)
		throws Exception {
		MetaObject object =
			(MetaObject) Class.forName(getClassName(element)).newInstance();
		MetaField[] fields = getField(object);
		for (int i = 0; i < fields.length; i++) {
			String value = element.valueOf(fields[i].name);
			if (value != null && value.trim().length() != 0) {
				fields[i].setValue(element.valueOf(fields[i].name));
			}
		}
		return object;
	}

	private static Element elementReplacedByObject(
		Element element,
		MetaObject object)
		throws Exception {
		MetaField[] fields = getField(object);
		for (int i = 0; i < fields.length; i++) {
			Node node = element.selectSingleNode(fields[i].name);
			Element currentElement = null;
			if (node != null) {
				currentElement = (Element) node;
				currentElement.clearContent();
			} else {
				currentElement = DocumentHelper.createElement(fields[i].name);
				element.add(currentElement);
			}
			currentElement.add(DocumentHelper.createCDATA(fields[i].getValue()));			
		}
		return element;
	}

	public static Element createElement(MetaObject object, boolean tree) {
		String[] name = object.getClass().getName().split("\\.");

		Element rootElement = null;
		Element element = null;
		if (tree) {
			for (int i = 0; i < name.length; i++) {
				if (element == null) {
					element = DocumentHelper.createElement(name[i]);
					rootElement = element;
				} else {
					Element newElement = DocumentHelper.createElement(name[i]);
					element.add(newElement);
					element = newElement;
				}
			}
		} else {
			element = DocumentHelper.createElement(name[name.length - 1]);
			rootElement = element;
		}

		try {
			MetaField[] fields = getField(object);
			for (int i = 0; i < fields.length; i++) {
				Element newElement =
					DocumentHelper.createElement(fields[i].name);
				CDATA cdata = DocumentHelper.createCDATA(fields[i].getValue());
				newElement.add(cdata);
				element.add(newElement);
			}
		} catch (Exception e) {
		}
		return rootElement;
	}

	private static Element getKeyElement(
		Document document,
		MetaObject object) {
		try {
			MetaObject[] objects = read(object.getClass());
			MetaField[] field = getField(object);
			MetaField uiField = object.getKeyField();
			if (uiField != null) {
				StringBuffer xPath = new StringBuffer();
				xPath.append(getXPath(object.getClass()));
				xPath.append(
					"[" + uiField.name + "='" + uiField.getValue() + "']");
				Node node = document.selectSingleNode(xPath.toString());
				if (node != null && node instanceof Element) {
					return (Element) node;
				}
			}
		} catch (Exception e) {
		}

		return null;
	}

	public static void remove(MetaObject object) {
		Document document = null;
		try {
			SAXReader reader = new SAXReader();
			document = reader.read(getFile(object.getClass()));
		} catch (Exception e) {
		}

		if (document == null) {
			return;
		} else {
			Element keyElement = getKeyElement(document, object);
			if (keyElement != null) {
				document.getRootElement().remove(keyElement);
				writeXML(document, object.getClass());
			}
		}
	}

	public static File getFile(Class c) {
		return new File(c.getName() + ".xml");
	}

	public static String getXPath(Class c) {
		return "/" + c.getName().replaceAll("\\.", "/");
	}

	public static MetaObject[] read(Class c) throws Exception {
		File f = getFile(c);
		if (!f.exists()) {
			return new MetaObject[0];
		}

		SAXReader reader = new SAXReader();
		Document document = reader.read(f);
		List list = document.selectNodes(getXPath(c));
		MetaObject[] objects = new MetaObject[list.size()];
		for (int i = 0; i < list.size(); i++) {
			objects[i] = XMLObject.element2Object((Element) list.get(i));
		}
		return objects;
	}

	public static void save(MetaObject object) {
		if (object == null) {
			return;
		}

		try {
			MetaField.save(XMLObject.getField(object));
		} catch (Exception e) {
		}

		File f = getFile(object.getClass());
		Document document = null;
		if (f.exists()) {
			SAXReader reader = new SAXReader();
			try {
				document = reader.read(f);
			} catch (Exception e) {
			}
		}

		boolean exist = false;
		if (document == null) {
			newWriteXML(object);
		} else {
			Element keyElement = getKeyElement(document, object);
			if (keyElement != null) {
				exist = true;
				try {
					elementReplacedByObject(keyElement, object);
					writeXML(document, object.getClass());
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			if (!exist) {
				String xPath = getXPath(object.getClass());
				Element element = (Element) document.selectSingleNode(xPath);
				if (element != null) {
					element = element.getParent();
					element.add(XMLObject.createElement(object, false));
					writeXML(document, object.getClass());
				} else {
					newWriteXML(object);
				}
			}
		}
	}

	private static void newWriteXML(MetaObject object) {
		Document document = DocumentHelper.createDocument();
		Element rootElement = createElement(object, true);
		document.add(rootElement);
		writeXML(document, object.getClass());
	}

	private static void writeXML(Document document, Class c) {
		OutputFormat format = new OutputFormat("    ", true);
		format.setEncoding("EUC-KR");
		format.setTrimText(true);
		format.setLineSeparator(System.getProperty("line.separator"));
		XMLWriter writer = null;
		try {
			writer = new XMLWriter(new FileOutputStream(getFile(c)), format);
			writer.write(document);
		} catch (Exception e) {
			if (writer != null) {
				try {
					writer.close();
				} catch (Exception ex) {
				}
			}
		}
	}
}
