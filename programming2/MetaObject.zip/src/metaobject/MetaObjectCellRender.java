package metaobject;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.io.File;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListCellRenderer;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

public class MetaObjectCellRender extends JPanel implements ListCellRenderer {
	protected static Border noFocusBorder = new EmptyBorder(1, 1, 1, 1);
	protected JPanel panel;
	
	public MetaObjectCellRender(Class metaObjectClass) {
		this.setLayout(new BorderLayout());	
		this.setBackground(Color.WHITE);
		this.setOpaque(true);
	}

	private void setupUI(MetaObject metaObject) {
		this.removeAll();
		try {
			MetaField[] metaFields = XMLObject.getField(metaObject);

			this.panel = new JPanel();
			panel.setBackground(Color.WHITE);
			panel.setOpaque(true);
			int rowCount = 0;
			for (int i = 0; i < metaFields.length; i++) {
				if (metaFields[i].visibleInList) {
					rowCount++;
				}
			}

			panel.setLayout(new GridLayout2(rowCount, 1));
			for (int i = 0; i < metaFields.length; i++) {
				if (metaFields[i].visibleInList) {
					JLabel nameLabel = new JLabel(metaFields[i].displayName + " : " + metaFields[i].getValue());
					nameLabel.setOpaque(false);
					panel.add(nameLabel);
				}
			}
			this.add(panel, BorderLayout.CENTER);
			
			File imageIconFile = new File(metaObject.getDisplayImageField().getValue());
			if (imageIconFile.exists()) {
				this.add(new ImageLabel(imageIconFile.getName()), BorderLayout.WEST);			
			}
			this.revalidate();
			this.repaint();
		} catch (Exception e) {
		}
	}

	public Component getListCellRendererComponent(
		JList list,
		Object value,
		int index,
		boolean isSelected,
		boolean cellHasFocus) {
		if (value != null && value instanceof MetaObject) {
			setupUI((MetaObject) value);
			
			if (isSelected) {
				this.panel.setForeground(list.getSelectionForeground());
				this.panel.setBackground(list.getSelectionBackground());
			} else {
				this.panel.setForeground(list.getForeground());
				this.panel.setBackground(list.getBackground());
			}

			if (cellHasFocus) {
				this.setBorder(
					UIManager.getBorder("List.focusCellHighlightBorder"));
			} else {
				this.setBorder(noFocusBorder);
			}

			return this;
		}
		return this;
	}

	public static void main(String[] args) throws Exception {
		JFrame f = new JFrame();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel p = new JPanel(new BorderLayout());
		JList list = new JList();
		list.setCellRenderer(new MetaObjectCellRender(Database.class));
		list.setListData(XMLObject.read(Database.class));
		p.add(list, BorderLayout.CENTER);
		f.setContentPane(p);
		f.setSize(new Dimension(400, 400));
		f.setVisible(true);
	}
}
