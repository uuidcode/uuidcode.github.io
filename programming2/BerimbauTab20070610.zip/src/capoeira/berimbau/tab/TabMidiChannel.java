package capoeira.berimbau.tab;

import javax.sound.midi.Instrument;
import javax.sound.midi.MidiChannel;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.Soundbank;
import javax.sound.midi.Synthesizer;

public class TabMidiChannel {
	private static MidiChannel channel;
	static {
		Synthesizer synthesizer = null;
		Instrument[] instruments = null;
		try {
			synthesizer = MidiSystem.getSynthesizer();
			synthesizer.open();
		} catch (Exception e) {
		}

		Soundbank sb = synthesizer.getDefaultSoundbank();
		if (sb != null) {
			instruments = synthesizer.getDefaultSoundbank().getInstruments();
			synthesizer.loadInstrument(instruments[0]);
			MidiChannel[] midiChannels = synthesizer.getChannels();
			
//			for (int i = 0; i < instruments.length; i++) {
//				synthesizer.loadInstrument(instruments[i]);
//				Debugger.log(new Exception(), instruments[i].getName());
//				MidiChannel[] midiChannels = synthesizer.getChannels();
//				for (int j = 0; j < midiChannels.length; j++) {
//					Debugger.log(new Exception(), midiChannels[j].toString());
//					midiChannels[j].noteOn(64, 64);
//					try {
//						Thread.sleep(1000);
//					} catch (Exception e) {
//					}					
//				}
//			}
			
			channel = midiChannels[0];
		}
		
		
	}
	
	public static void play(int noteNumber) {
		//channel.noteOn(noteNumber, 64);
	}
	
	public static void main(String[] args) {
		new TabMidiChannel();
	}

}
