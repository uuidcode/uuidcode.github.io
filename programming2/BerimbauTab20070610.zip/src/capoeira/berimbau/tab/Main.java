package capoeira.berimbau.tab;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.util.Enumeration;
import java.util.Vector;

import javax.swing.Action;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JToolBar;
import javax.swing.UIDefaults;
import javax.swing.UIManager;

import capoeira.berimbau.tab.action.CopyAction;
import capoeira.berimbau.tab.action.DeleteAction;
import capoeira.berimbau.tab.action.ExitAction;
import capoeira.berimbau.tab.action.NewAction;
import capoeira.berimbau.tab.action.OpenAction;
import capoeira.berimbau.tab.action.PasteAction;
import capoeira.berimbau.tab.action.SaveAction;
import capoeira.berimbau.tab.action.SaveAsAction;

import capoeira.berimbau.tab.action.SaveAsImageAction;
import capoeira.berimbau.tab.debugger.DebuggerPanel;
import capoeira.berimbau.tab.note.BuzzNote;
import capoeira.berimbau.tab.note.CloseNote;
import capoeira.berimbau.tab.note.Note;

import capoeira.berimbau.tab.note.NoteFactory;
import capoeira.berimbau.tab.note.OpenAndCloseNote;
import capoeira.berimbau.tab.note.OpenNote;

public class Main extends JFrame {
	private NoteSheet sheet = null;
	public final static boolean DEBUGGING = false;
	private Vector actions = new Vector();
	public final static String RESOURCE_DIR = "resource/";
	public final static String IMAGE_DIR = RESOURCE_DIR + "image/";
	public final static String MP3_DIR = RESOURCE_DIR + "mp3/";
	public final static String IMAGE_EXT = ".gif";

	public Main() {
		super("Capoeira Berimbau Tab");

		this.setIconImage(
			Toolkit.getDefaultToolkit().getImage(SplashPanel.getMainImage()));

		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		panel.setBackground(Color.white);

		JPanel notePanel = new JPanel(new BorderLayout());
		notePanel.setBackground(Color.white);

		NoteListPanel noteListPanel = new NoteListPanel();
		this.sheet = new NoteSheet();
		sheet.setBackground(Color.white);

		noteListPanel.setBackground(Color.white);
		noteListPanel.setLayout(null);
		noteListPanel.setSheet(sheet);

		Vector notes = new Vector();
		notes.add(new BuzzNote(BuzzNote.TWO_QUARTER));
		notes.add(new BuzzNote(BuzzNote.HALF));
		notes.add(new BuzzNote(BuzzNote.FOUR_OCTET));

		notes.add(new OpenNote(OpenNote.TWO));
		notes.add(new OpenNote(OpenNote.ONE_AND_HALF));
		notes.add(new OpenNote(OpenNote.ONE));
		notes.add(new OpenNote(OpenNote.HALF_AND_HALF));
		notes.add(new OpenNote(OpenNote.QUARTER_AND_HALF_QAUARTER));
		notes.add(new OpenNote(OpenNote.HALF));
		notes.add(new OpenNote(OpenNote.TWO_QUARTER));
		notes.add(new OpenNote(OpenNote.FOUR_OCTET));

		notes.add(new CloseNote(CloseNote.TWO));
		notes.add(new CloseNote(CloseNote.ONE_AND_HALF));
		notes.add(new CloseNote(CloseNote.ONE));
		notes.add(new CloseNote(CloseNote.HALF));
		notes.add(new CloseNote(CloseNote.TWO_QUARTER));
		notes.add(new CloseNote(CloseNote.FOUR_OCTET));

		notes.add(new OpenAndCloseNote(OpenAndCloseNote.OPEN_HALF_CLOSE_HALF));
		notes.add(new OpenAndCloseNote(OpenAndCloseNote.OPEN_QUARTER_CLOSE_QUARTER));
		notes.add(new OpenAndCloseNote(OpenAndCloseNote.CLOSE_HALF_OPEN_HALF));
		notes.add(new OpenAndCloseNote(OpenAndCloseNote.CLOSE_QUARTER_OPEN_QUARTER));
		notes.add(new OpenAndCloseNote(OpenAndCloseNote.CLOSE_HALF_OPEN_QUARTER));
		notes.add(new OpenAndCloseNote(OpenAndCloseNote.CLOSE_HALF_OPEN_ONE));		

		int offset = 10;
		for (int i = 0; i < notes.size(); i++) {
			Note note = (Note) notes.get(i);
			noteListPanel.add(note);
			Dimension d = note.getPreferredSize();
			note.setBounds(
				offset,
				offset + i * (offset + d.height),
				d.width,
				d.height);
		}

		JSplitPane mainSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		mainSplitPane.setLeftComponent(new JScrollPane(noteListPanel));
		mainSplitPane.setRightComponent(new JScrollPane(sheet));
		noteListPanel.setPreferredSize(
			new Dimension(
				(NoteFactory.WIDTH * 2) + 2 * offset,
				(NoteFactory.HEIGHT + offset) * notes.size()));
		sheet.setPreferredSize(
			new Dimension(
				NoteSheet.WIDTH,
				NoteSheet.HEIGHT * NoteSheet.ROW_COUNT
					+ NoteSheet.TITLE_HEIGHT
					+ NoteSheet.OFFSET));

		JSplitPane debuggerSplitPane = null;
		if (DEBUGGING) {
			debuggerSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
			debuggerSplitPane.setLeftComponent(mainSplitPane);
			DebuggerPanel debuggerPanel = new DebuggerPanel(sheet);
			debuggerSplitPane.setRightComponent(debuggerPanel);

			sheet.setDebuggerPanel(debuggerPanel);

			panel.add(debuggerSplitPane, BorderLayout.CENTER);
		} else {
			panel.add(mainSplitPane, BorderLayout.CENTER);
		}

		this.setupActionAndMenu();
		JToolBar toolbar = this.getToolBar();
		panel.add(toolbar, BorderLayout.NORTH);

		this.setContentPane(panel);
		//this.setSize(1000, 600);
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);

		mainSplitPane.setDividerSize(5);
		mainSplitPane.setDividerLocation(240);

		if (DEBUGGING) {
			debuggerSplitPane.setDividerSize(5);
			debuggerSplitPane.setDividerLocation(400);
		}
	}

	public void init() {
		this.sheet.initTitle();
	}

	private void addAction(JMenu menu, Action action) {
		this.actions.add(action);
		menu.add(new JMenuItem(action));
	}

	private void addSeperator() {
		this.actions.add(null);
	}

	private void setupActionAndMenu() {
		JMenuBar menuBar = new JMenuBar();
		JMenu menu = new JMenu("File");

		this.addAction(menu, new NewAction(this.sheet));
		this.addAction(menu, new OpenAction(this.sheet));
		this.addAction(menu, new SaveAction(this.sheet));
		this.addAction(menu, new SaveAsAction(this.sheet));
		this.addAction(menu, new SaveAsImageAction(this.sheet));
		this.addAction(menu, new ExitAction(this.sheet));
		menuBar.add(menu);

		this.addSeperator();

		menu = new JMenu("Edit");
		this.addAction(menu, new CopyAction(this.sheet));
		this.addAction(menu, new PasteAction(this.sheet));
		this.addAction(menu, new DeleteAction(this.sheet));
		menuBar.add(menu);
		this.setJMenuBar(menuBar);
	}

	public JToolBar getToolBar() {
		JToolBar toolbar = new JToolBar();
		toolbar.setRollover(true);
		toolbar.setFloatable(false);
		for (int i = 0; i < this.actions.size(); i++) {
			Object object = this.actions.get(i);
			if (object == null) {
				toolbar.addSeparator();
			} else {
				toolbar.add((Action) object);
			}

		}
		return toolbar;
	}

	public static void main(String[] args) {
		SplashPanel splashPanel = new SplashPanel();
		splashPanel.showSplash();

		UIDefaults uiDefaults = UIManager.getDefaults();
		Color defaultColor = new Color(236, 233, 216);
		Font font = new Font("Gulim", Font.PLAIN, 12);
		Enumeration enum = uiDefaults.keys();
		while (enum.hasMoreElements()) {
			Object obj = enum.nextElement();

			String key = obj.toString();
			if (key.toLowerCase().indexOf("font") != -1) {
				UIManager.put(key, font);
			}

			Object value = UIManager.get(key);
			if (value != null
				&& value.toString().toLowerCase().indexOf("[r=204,g=204,b=204]")
					!= -1) {
				UIManager.put(key, defaultColor);
			}
		}

		Main main = new Main();
		main.init();
		splashPanel.setVisible(false);
	}
}
