package capoeira.berimbau.tab.debugger;
import java.awt.BorderLayout;
import java.awt.Rectangle;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PrintWriter;

import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class ConsolePanel extends JPanel implements Runnable {
	private JTextArea console = new JTextArea();
	private JScrollPane scrollPaen = new JScrollPane(this.console);
	public static PipedOutputStream out = new PipedOutputStream();
	private PipedInputStream in = null;

	public ConsolePanel() {
		try {
			this.in = new PipedInputStream(out);
		} catch (Exception e) {
		}

		this.setLayout(new BorderLayout());
		this.add(this.scrollPaen);
	}

	public void run() {
		if (this.in != null) {
			BufferedReader reader =
				new BufferedReader(new InputStreamReader(this.in));

			try {
				String line = null;
				while ((line = reader.readLine()) != null) {
					this.console.append(line + "\r\n");
					console.setCaretPosition(
						console.getDocument().getLength() - 1);

					scrollPaen.getVerticalScrollBar().setValue(
						scrollPaen.getVerticalScrollBar().getMaximum());

					scrollToEnd();
				}

			} catch (Exception e) {
			}
		}
	}

	private void scrollToEnd() {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				if (isAdjusting()) {
					return;
				}

				int height = console.getHeight();
				scrollPaen.scrollRectToVisible(
					new Rectangle(0, height - 1, 1, height));
			}
		});
	}

	private boolean isAdjusting() {
		JScrollBar scrollBar = scrollPaen.getVerticalScrollBar();

		if (scrollBar != null && scrollBar.getValueIsAdjusting()) {
			return true;
		}

		return false;
	}

}
