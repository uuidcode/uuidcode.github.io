package capoeira.berimbau.tab.debugger;

import capoeira.berimbau.tab.Main;

public class Debugger {
	public synchronized static void log(Exception e, Object log) {
		try {
			String meesage = e.getStackTrace()[0] + ":" + log + "\r\n";
			if (Main.DEBUGGING) {
				ConsolePanel.out.write(meesage.getBytes());
			} else {
				System.out.print(meesage);
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();	
		}
	}
}
