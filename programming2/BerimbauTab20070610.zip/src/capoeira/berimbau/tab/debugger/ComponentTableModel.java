package capoeira.berimbau.tab.debugger;

import java.awt.Container;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;

import javax.swing.table.DefaultTableModel;

public class ComponentTableModel extends DefaultTableModel {
	public Container container;
	
	public ComponentTableModel(Container container) {
		this.container = container;
		this.addColumn("Name");
		this.addColumn("Value");
	}
	
	public void init() {
		Field[] fields = this.container.getClass().getDeclaredFields();
		AccessibleObject.setAccessible(fields, true);

		try {
			for (int i = 0; i < fields.length; i++) {
				this.addRow(new Object[] {fields[i].getName(), fields[i].get(this.container)});
			}
		} catch (Exception e) {
		}
	}
	
	public void refresh() {
		this.dataVector.removeAllElements();
		this.init();
		this.fireTableDataChanged();
	}

	public boolean isCellEditable(int row, int column) {
		return false;
	}
}
