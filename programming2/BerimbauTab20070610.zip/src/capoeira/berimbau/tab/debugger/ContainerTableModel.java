package capoeira.berimbau.tab.debugger;

import java.awt.Component;
import java.awt.Container;

import javax.swing.table.DefaultTableModel;

public class ContainerTableModel extends DefaultTableModel {
	private Container container;
	
	public ContainerTableModel(Container container) {
		this.container = container;
		this.columnIdentifiers.add("Compoenent");
	}
	
	public void refresh() {
		this.dataVector.removeAllElements();
		Component[] com = this.container.getComponents();
		for (int i = 0; i < com.length; i++) {
			this.addRow(new Object[] {com[i]});
		}
		this.fireTableDataChanged();
	}
	
	public boolean isCellEditable(int row, int column) {
		return false;
	}
}
