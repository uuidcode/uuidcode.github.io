package capoeira.berimbau.tab.debugger;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.util.Vector;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class DebuggerPanel extends JPanel {
	private ContainerTableModel containerModel = null;
	private ComponentTableModel componentTableModel = null;
	
	public DebuggerPanel(Container container) {
		this.setLayout(new BorderLayout());
		this.containerModel = new ContainerTableModel(container);
		this.componentTableModel = new ComponentTableModel(container);
		JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		
		JTable componentTable = new JTable(this.componentTableModel);
		componentTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		componentTable.getColumnModel().getColumn(0).setPreferredWidth(100);
		componentTable.getColumnModel().getColumn(1).setPreferredWidth(500);
		splitPane.setLeftComponent(new JScrollPane(componentTable));
		
		JTable containerTable = new JTable(this.containerModel);
		containerTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		containerTable.getColumnModel().getColumn(0).setPreferredWidth(800);
		splitPane.setRightComponent(new JScrollPane(containerTable));
		
		JSplitPane mainSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		mainSplitPane.setLeftComponent(splitPane);
		ConsolePanel console = new ConsolePanel();
		mainSplitPane.setRightComponent(console);
				
		this.add(mainSplitPane, BorderLayout.CENTER);
		splitPane.setDividerSize(5);
		splitPane.setDividerLocation(400);
		
		mainSplitPane.setDividerSize(5);
		mainSplitPane.setDividerLocation(400);
		
		Thread consoleThread = new Thread(console);
		consoleThread.start();
	}	

	public void refresh() {
		this.componentTableModel.refresh();
		this.containerModel.refresh();
	}

}
