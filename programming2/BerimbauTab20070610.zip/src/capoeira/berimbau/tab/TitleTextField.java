package capoeira.berimbau.tab;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class TitleTextField extends JTextField implements KeyListener {
	private final static int OFFSET = 30;
	public TitleTextField() {
//		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
//		String[] fontFamilies = ge.getAvailableFontFamilyNames();
//
//		for (int i = 0; i < fontFamilies.length; i++) {
//			System.out.println(fontFamilies[i]);
//		}
		this.setFont(new Font("BookMan Old Style", Font.ITALIC | Font.BOLD, 20));
		this.setBorder(new LineBorder(Color.WHITE, 1));
		this.addKeyListener(this);
	}
	
	public void paint(Graphics g) {
		if (g != null) {
			super.paint(g);
			Color currentColor = g.getColor();
			g.setColor(Color.BLACK);
			g.fillRect(0, this.getHeight() - 2, this.getWidth(), 2);
			g.setColor(currentColor);	
		}
	}

	/* (non-Javadoc)
	 * @see java.awt.event.KeyListener#keyPressed(java.awt.event.KeyEvent)
	 */
	public void keyPressed(KeyEvent e) {
		
		
	}

	public void resize() {
		Graphics g = this.getGraphics();
		if (g != null) {
			FontMetrics fontMetrics = g.getFontMetrics();
			int stringWidth = fontMetrics.stringWidth(this.getText());
			Rectangle rect = this.getBounds();
			int x = rect.x + rect.width/2;
			rect.x = x - (stringWidth + OFFSET)/2;
			rect.width = stringWidth + OFFSET;
			this.setBounds(rect);	
		}
		
	}
	
	public void keyReleased(KeyEvent e) {
		resize();
	}

	public void keyTyped(KeyEvent e) {
		
	}

}
