package capoeira.berimbau.tab.action;

import capoeira.berimbau.tab.NoteSheet;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class OpenAction extends CommonAction {
	public OpenAction(NoteSheet sheet) {
		super(sheet, "Open", KeyEvent.VK_O, KeyEvent.CTRL_MASK);
	}
	
	public void actionPerformed(ActionEvent e) {	
		this.sheet.open();
	}
}