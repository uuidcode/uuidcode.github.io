package capoeira.berimbau.tab.action;

import capoeira.berimbau.tab.NoteSheet;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class SaveAsAction extends CommonAction {
	public SaveAsAction(NoteSheet sheet) {
		super(sheet, "Save As", KeyEvent.VK_F12, 0);
	}
	
	public void actionPerformed(ActionEvent e) {
		this.sheet.saveAs();	
	}
}
