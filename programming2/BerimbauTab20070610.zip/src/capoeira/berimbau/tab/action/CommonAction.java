package capoeira.berimbau.tab.action;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

import capoeira.berimbau.tab.Main;
import capoeira.berimbau.tab.NoteSheet;

public abstract class CommonAction extends AbstractAction {
	protected NoteSheet sheet;
	protected String name;
	
	public CommonAction(NoteSheet sheet, String name, int keyCode, int keyModifier) {
		super(name, new ImageIcon(Main.IMAGE_DIR + name + Main.IMAGE_EXT));
		this.sheet = sheet;
		this.name = name;
		KeyStroke keyStroke =
			KeyStroke.getKeyStroke(keyCode, keyModifier, true);
		this.putValue(ACCELERATOR_KEY, keyStroke);
		this.putValue(SHORT_DESCRIPTION, this.name);
	}

	public NoteSheet getSheet() {
		return sheet;
	}
}