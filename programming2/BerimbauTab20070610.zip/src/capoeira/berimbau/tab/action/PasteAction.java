package capoeira.berimbau.tab.action;

import capoeira.berimbau.tab.NoteSheet;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class PasteAction extends CommonAction {
	public PasteAction(NoteSheet sheet) {
		super(sheet, "Paste", KeyEvent.VK_V, KeyEvent.CTRL_MASK);
	}
	
	public void actionPerformed(ActionEvent e) {
		this.sheet.paste();
	}
}
