package capoeira.berimbau.tab.action;

import capoeira.berimbau.tab.NoteSheet;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class SaveAsImageAction extends CommonAction {
	public SaveAsImageAction(NoteSheet sheet) {
		super(sheet, "Save As Image", KeyEvent.VK_I, KeyEvent.CTRL_MASK);
	}
	
	public void actionPerformed(ActionEvent e) {
		this.sheet.saveAsImage();
	}
}
