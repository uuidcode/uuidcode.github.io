package capoeira.berimbau.tab.action;

import capoeira.berimbau.tab.NoteSheet;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class DeleteAction extends CommonAction {
	public DeleteAction(NoteSheet sheet) {
		super(sheet, "Delete", KeyEvent.VK_DELETE, 0);
	}
	
	public void actionPerformed(ActionEvent e) {
		this.sheet.delete();
	}
}
