package capoeira.berimbau.tab.action;

import capoeira.berimbau.tab.NoteSheet;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class CopyAction extends CommonAction {
	public CopyAction(NoteSheet sheet) {
		super(sheet, "Copy", KeyEvent.VK_C, KeyEvent.CTRL_MASK);
	}
	
	public void actionPerformed(ActionEvent e) {
		this.sheet.copy();
	}
}
