package capoeira.berimbau.tab.action;

import capoeira.berimbau.tab.NoteSheet;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class NewAction extends CommonAction {
	public NewAction(NoteSheet sheet) {
		super(sheet, "New", KeyEvent.VK_N, KeyEvent.CTRL_MASK);
	}
	
	public void actionPerformed(ActionEvent e) {	
		this.sheet.init();
		this.sheet.initTitle();
	}
}