package capoeira.berimbau.tab.action;

import capoeira.berimbau.tab.NoteSheet;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class ExitAction extends CommonAction {
	public ExitAction(NoteSheet sheet) {
		super(sheet, "Exit", KeyEvent.VK_X, KeyEvent.CTRL_MASK);
	}
	
	public void actionPerformed(ActionEvent e) {	
		System.exit(1);	
	}
}
