package capoeira.berimbau.tab.note;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

public class CloseNote extends Note {
	public static final int HALF = 1;
	public static final int ONE = 2;
	public static final int TWO_QUARTER = 3;
	public static final int ONE_AND_HALF = 4;
	public static final int TWO = 5;
	public static final int FOUR_OCTET = 6;
	
	public CloseNote(int beat) {
		super(beat);
		this.noteNumber = 90;   
	}
	
	public CloseNote() {
		super();
		this.noteNumber = 90;
	}
	
	public Dimension getPreferredSize() {
		if (this.getType() == TWO) {
			return new Dimension(NoteFactory.WIDTH * 4, NoteFactory.HEIGHT);
		} else if (this.getType() == ONE_AND_HALF) {
			return new Dimension(NoteFactory.WIDTH * 3, NoteFactory.HEIGHT);
		} else if (this.getType() == ONE) {
			return new Dimension(NoteFactory.WIDTH * 2, NoteFactory.HEIGHT);
		} else if (this.getType() == HALF) {
			return new Dimension(NoteFactory.WIDTH, NoteFactory.HEIGHT);
		} else if (this.getType() == TWO_QUARTER) {
			return new Dimension(NoteFactory.WIDTH, NoteFactory.HEIGHT);
		} else if (this.getType() == FOUR_OCTET) {
			return new Dimension(NoteFactory.WIDTH, NoteFactory.HEIGHT);
		}
		return new Dimension();
	}
				
	public void paint(Graphics g) {
		g.setColor(this.getSelectedColor());
		Dimension d = this.getPreferredSize();
		if (this.isSelected) {
			g.drawRect(0, 0, d.width - 1, d.height -1);
		}
//		g.setColor(Color.black);
		
		if (this.getType() == TWO) {
			NoteFactory.paintCloseNoteTwo(g, 80);
		} else if (this.getType() == ONE_AND_HALF) {
			int x = 60;
			NoteFactory.paintCloseNote(g, x);
			g.fillOval(x + NoteFactory.EYE_WIDTH + NoteFactory.DOT_SIZE, 40, NoteFactory.DOT_SIZE, NoteFactory.DOT_SIZE);
		} else if (this.getType() == ONE) {
			NoteFactory.paintCloseNote(g, 40);	
		} else if (this.getType() == HALF) {
			NoteFactory.paintCloseNote(g, 15);
			g.fillRect(15 + NoteFactory.EYE_WIDTH - HALF, 
			NoteFactory.OFFSET, 
			10, 
			NoteFactory.THICK);
		} else if (this.getType() == TWO_QUARTER) {
			NoteFactory.paintCloseNote(g, 10);
			g.fillRect(10 + NoteFactory.EYE_WIDTH, 10, 20, 2);
			g.fillRect(10 + NoteFactory.EYE_WIDTH, 20, 20, 2);
			NoteFactory.paintCloseNote(g, 30);
		} else if (this.getType() == FOUR_OCTET) {
			NoteFactory.paintCloseOctetNote(g, 5);
			NoteFactory.paintCloseOctetNote(g, 15);
			NoteFactory.paintCloseOctetNote(g, 25);
			NoteFactory.paintCloseOctetNote(g, 35);
			g.fillRect(5 + NoteFactory.EYE_WIDTH/2, 10, 30, 2);
			g.fillRect(5 + NoteFactory.EYE_WIDTH/2, 15, 30, 2);
			g.fillRect(5 + NoteFactory.EYE_WIDTH/2, 20, 30, 2);
		}
		
		g.fillRect(0, d.height/ONE, d.width, NoteFactory.THICK);
		if (this.isTemplate()) {
			g.drawRect(0, 0, d.width - HALF, d.height - HALF);
		}
	}
}
