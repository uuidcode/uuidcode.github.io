package capoeira.berimbau.tab.note;

import java.awt.Dimension;
import java.awt.Graphics;

public class BuzzNote extends Note {
	public static final int TWO_QUARTER = 1;
	public static final int HALF = 2;
	public static final int FOUR_OCTET = 3;
	
	public BuzzNote() {
		super();
		this.noteNumber = 120;
	}
		
	public BuzzNote(int beat) {
		super(beat);
		this.noteNumber = 120;
	}
	
	public Dimension getPreferredSize() {
		if (this.getType() == TWO_QUARTER) {
			return new Dimension(NoteFactory.WIDTH, NoteFactory.HEIGHT);
		} else if (this.getType() == HALF) {
			return new Dimension(NoteFactory.WIDTH, NoteFactory.HEIGHT);
		} else if (this.getType() == FOUR_OCTET) {
			return new Dimension(NoteFactory.WIDTH, NoteFactory.HEIGHT);
		}  
		return new Dimension();
	}
		
	public void paint(Graphics g) {
		g.setColor(this.getSelectedColor());
		Dimension d = this.getPreferredSize();
		if (this.isSelected) {
			g.drawRect(0, 0, d.width - 1, d.height -1);
		}

		if (this.getType() == TWO_QUARTER) {
			NoteFactory.paintBuzzNote(g, 10);
			g.fillRect(10 + NoteFactory.EYE_WIDTH, 10, 20, 2);
			g.fillRect(10 + NoteFactory.EYE_WIDTH, 20, 20, 2);
			NoteFactory.paintBuzzNote(g, 30);
		} else if (this.getType() == HALF) {
			NoteFactory.paintBuzzNote(g, 15);
			g.fillRect(15 + NoteFactory.EYE_WIDTH - 1, 
						NoteFactory.OFFSET, 
						10, 
						NoteFactory.THICK);
		} else if (this.getType() == FOUR_OCTET) {
			NoteFactory.paintBuzzOctetNote(g, 5);
			NoteFactory.paintBuzzOctetNote(g, 15);
			NoteFactory.paintBuzzOctetNote(g, 25);
			NoteFactory.paintBuzzOctetNote(g, 35);
			g.fillRect(5 + NoteFactory.EYE_WIDTH/2, 10, 30, 2);
			g.fillRect(5 + NoteFactory.EYE_WIDTH/2, 15, 30, 2);
			g.fillRect(5 + NoteFactory.EYE_WIDTH/2, 20, 30, 2);
		}		
		
		g.fillRect(0, d.height/2, d.width, NoteFactory.THICK);		
		if (this.isTemplate()) {
			g.drawRect(0, 0, d.width - 1, d.height - 1);
		}
	}
}