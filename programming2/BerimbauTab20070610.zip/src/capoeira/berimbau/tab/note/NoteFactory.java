package capoeira.berimbau.tab.note;
import java.awt.Graphics;

public class NoteFactory {
	public final static int WIDTH = 50;
	public final static int HEIGHT = 100;
	public final static int EYE_WIDTH = 12;
	public final static int EYE_HEIGHT = 8;
	public final static int OFFSET = 10;
	public final static int THICK = 2;
	public final static int VAR_HEIGHT = 30;
	public final static int CLOSE_TOP_OPEN_TOP_DIFF = 20;
	public final static int DOT_SIZE = 5;

	public static void paintCloseNoteTwo(Graphics g, int x) {
		g.drawOval(x, 
			OFFSET + VAR_HEIGHT, 
			EYE_WIDTH, EYE_HEIGHT);
		g.fillRect(x + EYE_WIDTH - 1,
			OFFSET,
			THICK,
			VAR_HEIGHT + EYE_HEIGHT / 2);
	}
	
	public static void paintCloseNote(Graphics g, int x) {
		g.fillOval(x, 
			OFFSET + VAR_HEIGHT, 
			EYE_WIDTH, EYE_HEIGHT);
		g.fillRect(x + EYE_WIDTH - 1,
			OFFSET,
			THICK,
			VAR_HEIGHT + EYE_HEIGHT / 2);
	}
	
	public static void paintCloseOctetNote(Graphics g, int x) {
		g.fillOval(x, 
			OFFSET + VAR_HEIGHT, 
			EYE_WIDTH/2, EYE_HEIGHT);
		g.fillRect(x + EYE_WIDTH/2 - 1,
			OFFSET,
			THICK,
			VAR_HEIGHT + EYE_HEIGHT / 2);
	}
	
	public static void paintOpenNoteTwo(Graphics g, int x) {
		g.drawOval(x, 
			OFFSET + VAR_HEIGHT + CLOSE_TOP_OPEN_TOP_DIFF, 
			EYE_WIDTH, 
			EYE_HEIGHT);
		g.fillRect(x + EYE_WIDTH - 1, 
			OFFSET + CLOSE_TOP_OPEN_TOP_DIFF, 
			THICK, 
			VAR_HEIGHT + EYE_HEIGHT/2);
	}
		
	public static void paintOpenNote(Graphics g, int x) {
		g.fillOval(x, 
			OFFSET + VAR_HEIGHT + CLOSE_TOP_OPEN_TOP_DIFF, 
			EYE_WIDTH, 
			EYE_HEIGHT);
		g.fillRect(x + EYE_WIDTH - 1, 
			OFFSET + CLOSE_TOP_OPEN_TOP_DIFF, 
			THICK, 
			VAR_HEIGHT + EYE_HEIGHT/2);
	}
	
	public static void paintOpenOctetNote(Graphics g, int x) {
		g.fillOval(x, 
			OFFSET + VAR_HEIGHT + CLOSE_TOP_OPEN_TOP_DIFF, 
			EYE_WIDTH/2, 
			EYE_HEIGHT);
		g.fillRect(x + EYE_WIDTH/2 - 1, 
			OFFSET + CLOSE_TOP_OPEN_TOP_DIFF, 
			THICK, 
			VAR_HEIGHT + EYE_HEIGHT/2);
	}
	
	public static void paintBuzzNote(Graphics g, int x) {
		g.drawLine(x, 
			OFFSET + VAR_HEIGHT, 
			x + EYE_WIDTH, 
			OFFSET + VAR_HEIGHT + EYE_HEIGHT);
		g.drawLine(x + 1, 
			OFFSET + VAR_HEIGHT, 
			x + EYE_WIDTH + 1, 
			OFFSET + VAR_HEIGHT + EYE_HEIGHT - 1);
		g.drawLine(x, 
			OFFSET + VAR_HEIGHT + EYE_HEIGHT, 
			x + EYE_WIDTH, 
			OFFSET + VAR_HEIGHT);
		g.drawLine(x, 
			OFFSET + VAR_HEIGHT + EYE_HEIGHT - 1, 
			x + EYE_WIDTH + 1, 
			OFFSET + VAR_HEIGHT);
		g.fillRect(x + EYE_WIDTH - 1, 
			OFFSET, 
			THICK, 
			VAR_HEIGHT + EYE_HEIGHT/2);
	}
	
	public static void paintBuzzOctetNote(Graphics g, int x) {
		g.drawLine(x, 
			OFFSET + VAR_HEIGHT, 
			x + EYE_WIDTH/2, 
			OFFSET + VAR_HEIGHT + EYE_HEIGHT);
		g.drawLine(x + 1, 
			OFFSET + VAR_HEIGHT, 
			x + EYE_WIDTH/2 + 1, 
			OFFSET + VAR_HEIGHT + EYE_HEIGHT - 1);
		g.drawLine(x, 
			OFFSET + VAR_HEIGHT + EYE_HEIGHT, 
			x + EYE_WIDTH/2, 
			OFFSET + VAR_HEIGHT);
		g.drawLine(x, 
			OFFSET + VAR_HEIGHT + EYE_HEIGHT - 1, 
			x + EYE_WIDTH/2 + 1, 
			OFFSET + VAR_HEIGHT);
		g.fillRect(x + EYE_WIDTH/2 - 1, 
			OFFSET, 
			THICK, 
			VAR_HEIGHT + EYE_HEIGHT/2);
	}
}
