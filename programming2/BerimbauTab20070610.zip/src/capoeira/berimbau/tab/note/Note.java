package capoeira.berimbau.tab.note;
import capoeira.berimbau.tab.NoteSheet;
import capoeira.berimbau.tab.TabMidiChannel;
import capoeira.berimbau.tab.VirtualPoint;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;

import javax.swing.JPanel;
import javax.swing.JViewport;

import capoeira.berimbau.tab.debugger.Debugger;


public abstract class Note extends JPanel 
	implements MouseListener, ComponentListener {
	private static final Dimension PREFERRED_SIZE = new Dimension(NoteFactory.WIDTH, NoteFactory.HEIGHT);
	private Color selectedColor = Color.BLACK;
	private NoteSheet sheet;
	
	protected int type;
	protected int noteNumber;
	protected boolean isSelected;
	protected boolean isFloating = false;
	private Vector virtualPoints = new Vector();
	private boolean isTemplate = true;
		
	public Note() {
		this.type = 1;
		this.setOpaque(false);
		this.addComponentListener(this);
		this.setFocusable(true);
	}
	
	public Note(int beat) {
		this.type = beat;
		this.setOpaque(false);
		this.addMouseListener(this);
		this.setFocusable(true);
	}
	
	public void addVirtualPoint(VirtualPoint point) {
		this.virtualPoints.add(point);
	}
	
	public void removeAllVirtualPoint() {
		this.virtualPoints.removeAllElements();	
	}
	
	public String toString() {
		StringBuffer buffer = new StringBuffer();
				
		buffer.append("[");
		buffer.append("type=" + type);
		buffer.append(",noteNumber=" + noteNumber);
		buffer.append(",isFloating=" + isFloating);
		buffer.append(",virtualPoints=" + virtualPoints);
		buffer.append(",isTemplate=" + isTemplate);
		buffer.append(",sheet=" + (sheet!=null ? true:false));
		buffer.append("]");
		return buffer.toString() + super.toString();
	}
	
	public Note getNewInstance() {
		try {
			Note note = (Note) this.getClass().newInstance();
			note.setType(this.getType());
			return note;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public int getType() {
		return type;
	}

	public void setType(int i) {
		type = i;
	}

	public void mouseClicked(MouseEvent e) {
		if (this.isTemplate == true) {
			Note note = this.getNewInstance();
			note.setTemplate(false);
			if (this.sheet != null) {
				Dimension d = note.getPreferredSize();
				note.setSheet(this.sheet);
				this.sheet.add(note);
				
				JViewport view = (JViewport) this.sheet.getParent();
				Rectangle viewRect = view.getViewRect();
				note.setBounds(0, viewRect.y, d.width, d.height);
				this.sheet.setSelectedNote(new NoteComposite(note));
				this.sheet.suggestAndAttach();
				Debugger.log(new Exception(), view.getViewRect());				
			}
		}
	}

	public void selected(boolean isSelected) {
		this.isSelected = isSelected;
		if (this.isSelected) {
			this.selectedColor = Color.BLUE;
			TabMidiChannel.play(this.noteNumber);
		} else {
			this.selectedColor = Color.BLACK;
		}
		this.repaint();
	}
	
	public void mouseEntered(MouseEvent e) {
		this.selected(true);
	}

	public void mouseExited(MouseEvent e) {
		this.selected(false);
	}

	public void mousePressed(MouseEvent e) {
	
	}

	public void mouseReleased(MouseEvent e) {
	
	}

	public Color getSelectedColor() {
		return selectedColor;
	}

	public NoteSheet getSheet() {
		return sheet;
	}

	public void setSheet(NoteSheet sheet) {
		this.sheet = sheet;
	}

	public boolean isTemplate() {
		return isTemplate;
	}

	public void setTemplate(boolean b) {
		isTemplate = b;
	}

	public int getNoteNumber() {
		return noteNumber;
	}

	public void setNoteNumber(int i) {
		noteNumber = i;
	}

	public boolean isFloating() {
		return isFloating;
	}

	public void setFloating(boolean b) {
		isFloating = b;
	}

	public void componentHidden(ComponentEvent e) {
		if (this.sheet != null) {
			this.sheet.debuggerRefresh();
		}
	}

	public void componentMoved(ComponentEvent e) {
		if (this.sheet != null) {
			this.sheet.debuggerRefresh();
		}
	}

	public void componentResized(ComponentEvent e) {
		if (this.sheet != null) {
			this.sheet.debuggerRefresh();
		}
	}

	public void componentShown(ComponentEvent e) {
		if (this.sheet != null) {
			this.sheet.debuggerRefresh();
		}
	}
}
