package capoeira.berimbau.tab.note;

import capoeira.berimbau.tab.NoteSheet;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.Vector;

import capoeira.berimbau.tab.debugger.Debugger;

public class NoteComposite {
	private Vector notes = new Vector();
	private Rectangle rect = new Rectangle();
	
	public NoteComposite() {
		
	}
	
	public NoteComposite(Note note) {
		this.add(note);
	}
		
	public NoteComposite newInstance() {
		try {
			NoteComposite newNoteComposite = (NoteComposite) this.getClass().newInstance();
			Vector notes = this.getNotes();
			for (int i = 0; i < notes.size(); i++) {
				Note note = (Note) notes.get(i);
				try {
					Note newNote = (Note) note.getClass().newInstance();
					newNote.setType(note.getType());
					newNote.setTemplate(false);
					Dimension d = newNote.getPreferredSize();
					newNote.setBounds(note.getX() + 100, note.getY() + 100, d.width, d.height);
					NoteSheet sheet = note.getSheet();
					newNote.setSheet(sheet);
					sheet.add(newNote);
					newNoteComposite.add(newNote);
					sheet.revalidate();
					sheet.repaint();	
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			return newNoteComposite;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public String toString() {
		return rect + ", " + notes;
	}
	
	public void add(Note note) {
		this.notes.add(note);
		this.calculateBounds();
	}

	public int getNoteCount() {
		return this.notes.size();
	}

	public Dimension getPreferredSize() {
		return new Dimension(this.getBounds().width, this.getBounds().height);
	}

	public int getX() {
		return this.getBounds().x;
	}

	public int getY() {
		return this.getBounds().y;

	}

	public void setBounds(Rectangle rect) {
		this.rect = rect;
	}

	public void calculateBounds() {
		int minX = Integer.MAX_VALUE;
		int maxX = 0;
		int minY = Integer.MAX_VALUE;
		int maxY = 0;

		for (int i = 0; i < this.notes.size(); i++) {
			Note note = (Note) this.notes.get(i);
			if (minX > note.getX()) {
				minX = note.getX();
			}

			if (maxX < (note.getX() + note.getWidth())) {
				maxX = note.getX() + note.getWidth();
			}

			if (minY > note.getY()) {
				minY = note.getY();
			}

			if (maxY < (note.getY() + note.getHeight())) {
				maxY = note.getY() + note.getHeight();
			}
		}

		rect.x = minX;
		rect.y = minY;
		rect.width = (maxX - minX);
		rect.height = (maxY - minY);
		Debugger.log(new Exception(), rect);
	}

	public Rectangle getBounds() {
		return rect;
	}

	public void selected(boolean isSelected) {
		for (int i = 0; i < this.notes.size(); i++) {
			((Note) this.notes.get(i)).selected(isSelected);
		}
	}

	public boolean contains(Note note) {
		return this.notes.contains(note);
	}

	public boolean contains(Point p) {
		Debugger.log(new Exception(), this.getBounds());
		Debugger.log(new Exception(), p);
		return this.getBounds().contains(p);
	}
	
	public void remove() {
		for (int i = 0; i < this.notes.size(); i++) {
			Note note = (Note) this.notes.get(i);
			note.getSheet().remove(note);
		}
	}
	
	public void setPosition(int x, int y) {
		for (int i = 0; i < this.notes.size(); i++) {
			Note note = (Note) this.notes.get(i);
			Rectangle rect = note.getBounds();
			rect.x += (x - this.rect.x);
			rect.y += (y - this.rect.y);
			note.setBounds(rect);
		}
		this.rect.x = x;
		this.rect.y = y;
	}

	public Vector getNotes() {
		return notes;
	}

}
