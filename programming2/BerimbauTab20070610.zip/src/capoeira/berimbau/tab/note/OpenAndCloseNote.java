package capoeira.berimbau.tab.note;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

public class OpenAndCloseNote extends Note {
	public final static int OPEN_HALF_CLOSE_HALF = 1;
	public final static int CLOSE_HALF_OPEN_HALF = 2;
	public final static int OPEN_QUARTER_CLOSE_QUARTER = 3;
	public final static int CLOSE_QUARTER_OPEN_QUARTER = 4;
	public final static int CLOSE_HALF_OPEN_QUARTER = 5;
	public final static int CLOSE_HALF_OPEN_ONE = 6;
	
		 
	public OpenAndCloseNote(int beat) {
		super(beat);
		this.noteNumber = 60;
	}

	public OpenAndCloseNote() {
		super();
		this.noteNumber = 60;
	}
	
	public Dimension getPreferredSize() {
		if (this.getType() == OPEN_HALF_CLOSE_HALF) {
			return new Dimension(NoteFactory.WIDTH * 2, NoteFactory.HEIGHT);
		} else if (this.getType() == CLOSE_HALF_OPEN_HALF) {
			return new Dimension(NoteFactory.WIDTH * 2, NoteFactory.HEIGHT);
		} else if (this.getType() == OPEN_QUARTER_CLOSE_QUARTER) {
			return new Dimension(NoteFactory.WIDTH, NoteFactory.HEIGHT);
		} else if (this.getType() == CLOSE_QUARTER_OPEN_QUARTER) {
			return new Dimension(NoteFactory.WIDTH, NoteFactory.HEIGHT);
		} else if (this.getType() == CLOSE_HALF_OPEN_QUARTER) {
			return new Dimension(NoteFactory.WIDTH * 3, NoteFactory.HEIGHT);
		} else if (this.getType() == CLOSE_HALF_OPEN_ONE) {
			return new Dimension(NoteFactory.WIDTH * 3, NoteFactory.HEIGHT);
		}
		return new Dimension();
	}
			
	public void paint(Graphics g) {
		g.setColor(this.getSelectedColor());
		Dimension d = this.getPreferredSize();
		if (this.isSelected) {
			g.drawRect(0, 0, d.width - 1, d.height -1);
		}
//		g.setColor(Color.black);
		if (this.getType() == CLOSE_HALF_OPEN_HALF) {
			NoteFactory.paintCloseNote(g, 20);
			g.fillRect(20 + NoteFactory.EYE_WIDTH, 10, 40, 2);
			g.fillRect(60 + NoteFactory.EYE_WIDTH - 1, NoteFactory.THICK + 10, NoteFactory.THICK, NoteFactory.CLOSE_TOP_OPEN_TOP_DIFF);
			NoteFactory.paintOpenNote(g, 60);
		} else if (this.getType() == CLOSE_QUARTER_OPEN_QUARTER) {
			NoteFactory.paintCloseNote(g, 10);
			g.fillRect(10 + NoteFactory.EYE_WIDTH, 10, 20, 2);
			g.fillRect(10 + NoteFactory.EYE_WIDTH, 20, 20, 2);
			g.fillRect(30 + NoteFactory.EYE_WIDTH - 1, NoteFactory.THICK + 10, NoteFactory.THICK, NoteFactory.CLOSE_TOP_OPEN_TOP_DIFF);
			NoteFactory.paintOpenNote(g, 30);
		} else if (this.getType() == CLOSE_HALF_OPEN_QUARTER) {
			NoteFactory.paintOpenNote(g, 20);
			g.fillRect(20 + NoteFactory.EYE_WIDTH, 10, 30, 2);
			g.fillRect(20 + NoteFactory.EYE_WIDTH + 20, 20, 10, 2);
			g.fillRect(20 + NoteFactory.EYE_WIDTH - 1, NoteFactory.THICK + 10, NoteFactory.THICK, NoteFactory.CLOSE_TOP_OPEN_TOP_DIFF);
			NoteFactory.paintCloseNote(g, 50);
			
			NoteFactory.paintOpenNote(g, 80);
			g.fillRect(80 + NoteFactory.EYE_WIDTH, 10, 30, 2);
			g.fillRect(80 + NoteFactory.EYE_WIDTH + 20, 20, 10, 2);
			g.fillRect(80 + NoteFactory.EYE_WIDTH - 1, NoteFactory.THICK + 10, NoteFactory.THICK, NoteFactory.CLOSE_TOP_OPEN_TOP_DIFF);
			NoteFactory.paintCloseNote(g, 110);						
		} else if (this.getType() == OPEN_HALF_CLOSE_HALF) {
			NoteFactory.paintOpenNote(g, 20);
			g.fillRect(20 + NoteFactory.EYE_WIDTH, 10, 40, 2);
			g.fillRect(20 + NoteFactory.EYE_WIDTH - 1, NoteFactory.THICK + 10, NoteFactory.THICK, NoteFactory.CLOSE_TOP_OPEN_TOP_DIFF);
			NoteFactory.paintCloseNote(g, 60);
		} else if (this.getType() == OPEN_QUARTER_CLOSE_QUARTER) {
			NoteFactory.paintOpenNote(g, 10);
			g.fillRect(10 + NoteFactory.EYE_WIDTH, 10, 20, 2);
			g.fillRect(10 + NoteFactory.EYE_WIDTH, 20, 20, 2);
			g.fillRect(10 + NoteFactory.EYE_WIDTH - 1, NoteFactory.THICK + 10, NoteFactory.THICK, NoteFactory.CLOSE_TOP_OPEN_TOP_DIFF);
			NoteFactory.paintCloseNote(g, 30);
		} else if (this.getType() == CLOSE_HALF_OPEN_ONE) {
			NoteFactory.paintOpenNote(g, 20);
			NoteFactory.paintCloseNote(g, 60);
			NoteFactory.paintCloseNote(g, 100);
			g.fillRect(20 + NoteFactory.EYE_WIDTH, 10, 80, 2);
			g.fillRect(20 + NoteFactory.EYE_WIDTH - 1, 10, 2, NoteFactory.CLOSE_TOP_OPEN_TOP_DIFF);
			g.drawArc(60 + NoteFactory.EYE_WIDTH/2, 49, 40, 20, 180, 180);
			g.drawArc(60 + NoteFactory.EYE_WIDTH/2, 50, 40, 20, 180, 180);						
		}
		g.fillRect(0, d.height/2, d.width, NoteFactory.THICK);
		if (this.isTemplate()) {
			g.drawRect(0, 0, d.width - 1, d.height - 1);
		}
	}
}
