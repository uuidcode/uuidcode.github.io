package capoeira.berimbau.tab.note;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

public class OpenNote extends Note {
	public static final int HALF = 1;
	public static final int ONE = 2;
	public static final int TWO_QUARTER = 3;
	public static final int ONE_AND_HALF = 4;
	public static final int TWO = 5;
	public static final int HALF_AND_HALF = 6;
	public static final int QUARTER_AND_HALF_QAUARTER = 7;
	public static final int FOUR_OCTET = 8;
		
	public OpenNote(int beat) {
		super(beat);
		this.noteNumber = 60;
	}
	
	public OpenNote() {
		super();
		this.noteNumber = 60;
	}
	
	public Dimension getPreferredSize() {
		if (this.getType() == TWO) {
			return new Dimension(NoteFactory.WIDTH * 4, NoteFactory.HEIGHT);
		} else if (this.getType() == ONE_AND_HALF) {
			return new Dimension(NoteFactory.WIDTH * 3, NoteFactory.HEIGHT);
		} else if (this.getType() == ONE) {
			return new Dimension(NoteFactory.WIDTH * 2, NoteFactory.HEIGHT);
		} else if (this.getType() == HALF) {
			return new Dimension(NoteFactory.WIDTH, NoteFactory.HEIGHT);
		} else if (this.getType() == TWO_QUARTER) {
			return new Dimension(NoteFactory.WIDTH, NoteFactory.HEIGHT);
		} else if (this.getType() == HALF_AND_HALF) {
			return new Dimension(NoteFactory.WIDTH * 2, NoteFactory.HEIGHT);
		} else if (this.getType() == QUARTER_AND_HALF_QAUARTER) {
			return new Dimension(NoteFactory.WIDTH * 2, NoteFactory.HEIGHT);
		} else if (this.getType() == FOUR_OCTET) {
			return new Dimension(NoteFactory.WIDTH, NoteFactory.HEIGHT);
		} 
		return new Dimension();
	}
	
	public void paint(Graphics g) {
		g.setColor(this.getSelectedColor());
		Dimension d = this.getPreferredSize();
		if (this.isSelected) {
			g.drawRect(0, 0, d.width - 1, d.height -1);
		}
//		g.fillRect(0, 0, d.width, d.height);
//		g.setColor(Color.black);
		if (this.getType() == TWO) {
			NoteFactory.paintOpenNoteTwo(g, 80);
		} else if (this.getType() == ONE_AND_HALF) {
			int x = 60;
			NoteFactory.paintOpenNote(g, x);
			g.fillOval(x + NoteFactory.EYE_WIDTH + NoteFactory.DOT_SIZE, 60, NoteFactory.DOT_SIZE, NoteFactory.DOT_SIZE);				
		} else if (this.getType() == ONE) {
			NoteFactory.paintOpenNote(g, 40);	
		} else if (this.getType() == HALF) {
			NoteFactory.paintOpenNote(g, 15);
			g.fillRect(15 + NoteFactory.EYE_WIDTH - 1, 
			NoteFactory.OFFSET + NoteFactory.CLOSE_TOP_OPEN_TOP_DIFF, 
			10, 
			NoteFactory.THICK);
		} else if (this.getType() == TWO_QUARTER) {
			NoteFactory.paintOpenNote(g, 10);
			g.fillRect(10 + NoteFactory.EYE_WIDTH, 10 + NoteFactory.CLOSE_TOP_OPEN_TOP_DIFF, 20, 2);
			g.fillRect(10 + NoteFactory.EYE_WIDTH, 20 + NoteFactory.CLOSE_TOP_OPEN_TOP_DIFF, 20, 2);
			NoteFactory.paintOpenNote(g, 30);
		} else if (this.getType() == HALF_AND_HALF) {
			NoteFactory.paintOpenNote(g, 20);
			g.fillRect(20 + NoteFactory.EYE_WIDTH, 10 + NoteFactory.CLOSE_TOP_OPEN_TOP_DIFF, 40, 2);
			NoteFactory.paintOpenNote(g, 60);
		} else if (this.getType() == QUARTER_AND_HALF_QAUARTER) {
			NoteFactory.paintOpenNote(g, 20);
			g.fillRect(20 + NoteFactory.EYE_WIDTH, 10 + NoteFactory.CLOSE_TOP_OPEN_TOP_DIFF, 40, 2);
			g.fillRect(20 + NoteFactory.EYE_WIDTH, 20 + NoteFactory.CLOSE_TOP_OPEN_TOP_DIFF, 10, 2);
			NoteFactory.paintOpenNote(g, 60);
			g.fillOval(60 + NoteFactory.EYE_WIDTH + NoteFactory.DOT_SIZE, 60, NoteFactory.DOT_SIZE, NoteFactory.DOT_SIZE);
		} else if (this.getType() == FOUR_OCTET) {
			NoteFactory.paintOpenOctetNote(g, 5);
			NoteFactory.paintOpenOctetNote(g, 15);
			NoteFactory.paintOpenOctetNote(g, 25);
			NoteFactory.paintOpenOctetNote(g, 35);
			g.fillRect(5 + NoteFactory.EYE_WIDTH/2, 10 + NoteFactory.CLOSE_TOP_OPEN_TOP_DIFF, 30, 2);
			g.fillRect(5 + NoteFactory.EYE_WIDTH/2, 15 + NoteFactory.CLOSE_TOP_OPEN_TOP_DIFF, 30, 2);
			g.fillRect(5 + NoteFactory.EYE_WIDTH/2, 20 + NoteFactory.CLOSE_TOP_OPEN_TOP_DIFF, 30, 2);
		}
	
		g.fillRect(0, d.height/2, d.width, NoteFactory.THICK);
		if (this.isTemplate()) {
			g.drawRect(0, 0, d.width - 1, d.height - 1);
		}
	}
}
