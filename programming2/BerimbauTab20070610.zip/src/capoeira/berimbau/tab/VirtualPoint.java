package capoeira.berimbau.tab;

import java.awt.Point;

public class VirtualPoint extends Point {
	private boolean isHidden = false;
	
	public VirtualPoint(int x, int y) {
		super(x, y);
	}
	
	public boolean isHidden() {
		return isHidden;
	}
	
	public void setHidden(boolean b) {
		isHidden = b;
	}

}
