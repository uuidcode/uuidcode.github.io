package capoeira.berimbau.tab;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Vector;

import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JViewport;
import javax.swing.filechooser.FileFilter;

import capoeira.berimbau.tab.debugger.Debugger;
import capoeira.berimbau.tab.debugger.DebuggerPanel;
import capoeira.berimbau.tab.note.Note;
import capoeira.berimbau.tab.note.NoteComposite;

import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageEncoder;

public class NoteSheet
	extends JPanel
	implements MouseMotionListener, MouseListener, ContainerListener, ComponentListener {
	public final static int TITLE_HEIGHT = 50;
	public final static int TITLE_WIDTH = 300;
	public final static int WIDTH = 800;
	public final static int HEIGHT = 100;
	public final static int OFFSET = 10;
	public final static int ROW_COUNT = 8;

	private final static int THRESHOLD_HEIHGT_SCOLLBAR_MOVING = 50;
	private final static int THICK = 2;
	private final static int BAR_HEIGHT = 20;
	private final static Dimension PREFERRED_SIZE =
		new Dimension(WIDTH + (2 * OFFSET), HEIGHT);
	private final static int UNIT_X = 10;
	private final static int UNIT_Y = 10;
	private final static int TAB_COUNT = 4;
	private final static int SIZE = 32;

	private Point dragStartPoint = new Point();
	private Point dragEndPoint = new Point();
	private Point dragPreviousPoint = new Point();

	private boolean isDragging = false;
	private NoteComposite selectedNote;
	private NoteComposite clipboardNote;
	private int selectedOffsetX;
	private int selectedOffsetY;
	private VirtualPoint[][] virtualPoints = null;
	private Rectangle prePostionRect = null;
	private Rectangle currentPrePositionRect = new Rectangle();
	private Rectangle currentSelectedRect = new Rectangle();
	private DebuggerPanel debuggerPanel = null;
	private JFileChooser fileChooser = new JFileChooser(".");
	private FileFilter filter = new DefaultFileFilter(DefaultFileFilter.CTB);
	private TitleTextField title = new TitleTextField();
	private File file = null;
	private boolean openning = false;
	private boolean deubgging = false;

	public NoteSheet() {
		this.init();
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
		this.addContainerListener(this);
		this.addComponentListener(this);
		this.setFocusable(true);
	}

	public void delete() {
		if (this.selectedNote != null) {
			this.selectedNote.remove();
			this.selectedNote = null;
			revalidate();
			repaint();
		}
	}

	//	public Dimension getPreferedSize() {
	//		return new Dimension(1000, 1000);
	//	}

	private void initVirtualPoints() {
		this.virtualPoints = new VirtualPoint[ROW_COUNT][SIZE];
		for (int i = 0; i < this.virtualPoints.length; i++) {
			for (int j = 0; j < this.virtualPoints[i].length; j++) {
				int x = OFFSET + j * (WIDTH / SIZE);
				int y = TITLE_HEIGHT + HEIGHT * i + HEIGHT / 2;
				virtualPoints[i][j] = new VirtualPoint(x, y);
			}
		}
	}

	public void paste() {
		Debugger.log(new Exception(), "paste");
		NoteComposite noteComposite = clipboardNote;
		if (noteComposite != null) {
			noteComposite.selected(false);
			NoteComposite newNoteComposite = noteComposite.newInstance();
			if (newNoteComposite != null) {
				NoteSheet.this.selectedNote = newNoteComposite;
				NoteSheet.this.selectedNote.selected(true);
				NoteSheet.this.clipboardNote = null;
			}
			this.debuggerRefresh();
		}
	}

	public void copy() {
		Debugger.log(new Exception(), "copy");
		clipboardNote = selectedNote;
		this.debuggerRefresh();
	}

	private boolean checkValidPrePosition(Rectangle rect) {
		for (int i = 0; i < this.virtualPoints.length; i++) {
			for (int j = 0; j < this.virtualPoints[i].length; j++) {
				if (this.virtualPoints[i][j].isHidden()
					&& rect.contains(this.virtualPoints[i][j])) {
					return false;
				}
			}
		}

		return true;
	}

	public void addNote(Note note) {
		this.recalculateVirtualPoint();

	}

	private void suggestPrePosition() {
		Debugger.log(new Exception(), "suggestPrePosition1");
		this.recalculateVirtualPoint();

		if (this.selectedNote != null) {
			Debugger.log(new Exception(), "suggestPrePosition2");
			Dimension d = this.selectedNote.getPreferredSize();
			int x = this.selectedNote.getX() + d.width / 2;
			int y = this.selectedNote.getY() + d.height / 2;

			int minLength = Integer.MAX_VALUE;
			int minIndex = 0;
			int diffX = 0;
			int diffY = 0;

			for (int i = 0; i < this.virtualPoints.length; i++) {
				for (int j = 0; j < this.virtualPoints[i].length; j++) {
					if (!this.virtualPoints[i][j].isHidden()) {
						int length =
							(this.virtualPoints[i][j].x - x)
								* (this.virtualPoints[i][j].x - x)
								+ (this.virtualPoints[i][j].y - y)
									* (this.virtualPoints[i][j].y - y);
						if (length < minLength) {
							diffX = x - this.virtualPoints[i][j].x;
							diffY = y - this.virtualPoints[i][j].y;

							int currentX = this.selectedNote.getX();
							int currentY = this.selectedNote.getY();

							Rectangle rect =
								new Rectangle(
									currentX - diffX,
									currentY - diffY,
									d.width,
									d.height);
							if (this.checkValidPrePosition(rect)) {
								minLength = length;
								Rectangle totalRepaint =
									this.currentPrePositionRect.union(rect);
								this.prePostionRect = rect;
								this.repaintRect(totalRepaint);
								this.currentPrePositionRect =
									this.prePostionRect;
							}
						}
					}
				}
			}
		}
	}

	private void repaintRect(Rectangle rect) {
		this.repaint(rect.x - 1, rect.y - 1, rect.width + 2, rect.height + 2);
	}

	public void mouseDragged(MouseEvent e) {
		if (this.selectedNote != null) {
			boolean canDrag = false;

			if (!this.isDragging) {
				canDrag = this.selectedNote.contains(e.getPoint());
			} else {
				canDrag = true;
			}

			if (canDrag) {
				JViewport view = (JViewport) this.getParent();
				Rectangle viewRect = view.getViewRect();
				if ((e.getY() + THRESHOLD_HEIHGT_SCOLLBAR_MOVING)
					> (viewRect.y + viewRect.height)) {
					JScrollPane scrollPane = (JScrollPane) view.getParent();
					JScrollBar scrollBar = scrollPane.getVerticalScrollBar();
					scrollBar.setValue(
						scrollBar.getValue()
							+ THRESHOLD_HEIHGT_SCOLLBAR_MOVING);
				}

				if ((e.getY() - THRESHOLD_HEIHGT_SCOLLBAR_MOVING) > 0
					&& (e.getY() - THRESHOLD_HEIHGT_SCOLLBAR_MOVING)
						< viewRect.y) {
					JScrollPane scrollPane = (JScrollPane) view.getParent();
					JScrollBar scrollBar = scrollPane.getVerticalScrollBar();
					scrollBar.setValue(
						scrollBar.getValue()
							- THRESHOLD_HEIHGT_SCOLLBAR_MOVING);
				}

				int x = UNIT_X * (e.getX() / UNIT_X);
				x -= this.selectedOffsetX;
				int y = UNIT_Y * (e.getY() / UNIT_Y);
				y -= this.selectedOffsetY;
				Dimension d = this.selectedNote.getPreferredSize();
				if (x >= 0 && y >= 0) {
					this.selectedNote.setPosition(x, y);
				}
				this.isDragging = true;
				this.suggestPrePosition();
			}
		} else {
			this.isDragging = true;
			int x = this.dragStartPoint.x;
			int preX = this.dragPreviousPoint.x;
			if (x > e.getX()) {
				x = e.getX();
			}

			if (preX > e.getX()) {
				preX = e.getX();
			}

			int y = this.dragStartPoint.y;
			int preY = this.dragPreviousPoint.y;
			if (y > e.getY()) {
				y = e.getY();
			}

			if (preY > e.getY()) {
				preY = e.getY();
			}

			this.currentSelectedRect.x = x;
			this.currentSelectedRect.y = y;
			this.currentSelectedRect.width =
				Math.abs(e.getX() - dragStartPoint.x);
			this.currentSelectedRect.height =
				Math.abs(e.getY() - dragStartPoint.y);

			Rectangle previousRectDrawn = new Rectangle();
			previousRectDrawn.x = preX;
			previousRectDrawn.y = preY;
			previousRectDrawn.width = Math.abs(e.getX() - dragPreviousPoint.x);
			previousRectDrawn.height = Math.abs(e.getY() - dragPreviousPoint.y);

			Rectangle totalRepaint =
				this.currentSelectedRect.union(previousRectDrawn);
			this.repaintRect(totalRepaint);
			this.dragPreviousPoint = e.getPoint();
		}
		this.debuggerRefresh();
	}

	public void mouseMoved(MouseEvent e) {

	}

	public void componentAdded(ContainerEvent e) {
		Object object = e.getChild();
		if (object instanceof Note) {
			if (this.selectedNote != null) {
				this.selectedNote.selected(false);
			}
			Debugger.log(new Exception(), object);

			NoteComposite noteComposite = new NoteComposite();
			noteComposite.add((Note) object);

			if (!this.openning) {
				this.selectedNote = noteComposite;
				this.selectedNote.selected(true);
			}
		}
		this.debuggerRefresh();
	}

	public void componentRemoved(ContainerEvent e) {
		this.debuggerRefresh();
	}

	public void mouseClicked(MouseEvent e) {
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public void mousePressed(MouseEvent e) {
		this.requestFocus(true);
		this.title.select(0, 0);
		Debugger.log(new Exception(), "pressed");
		Object object = this.getComponentAt(e.getX(), e.getY());
		if (object != null && object instanceof Note) {
			Note note = (Note) object;
			if (this.selectedNote != null
				&& !this.selectedNote.contains(note)) {
				this.selectedNote.selected(false);
			}

			boolean makeNewSelectNote = false;
			if (this.selectedNote != null
				&& this.selectedNote.getNoteCount() == 1) {
				makeNewSelectNote = true;
			}

			if (this.selectedNote == null) {
				makeNewSelectNote = true;
			}

			if (makeNewSelectNote) {
				NoteComposite noteComposite = new NoteComposite();
				noteComposite.add(note);
				noteComposite.selected(true);
				this.selectedNote = noteComposite;
			}

			this.selectedOffsetX = UNIT_X * ((e.getX() - note.getX()) / UNIT_X);
			this.selectedOffsetY = UNIT_Y * ((e.getY() - note.getY()) / UNIT_Y);
		} else {
			if (this.selectedNote != null) {
				this.selectedNote.selected(false);
				this.selectedNote = null;
			}

			this.dragStartPoint = e.getPoint();
		}
		this.debuggerRefresh();
	}

	public void suggestAndAttach() {
		this.suggestPrePosition();
		this.attach();
		this.recalculateVirtualPoint();
	}

	private void attach() {
		Debugger.log(new Exception(), "attach");
		Rectangle rect = new Rectangle();
		rect.x = this.prePostionRect.x;
		rect.y = this.prePostionRect.y;
		rect.width = this.prePostionRect.width;
		rect.height = this.prePostionRect.height;
		Debugger.log(new Exception(), rect);
		this.selectedNote.setPosition(rect.x, rect.y);
		this.revalidate();
		this.repaint();
		this.prePostionRect = null;
	}

	public void mouseReleased(MouseEvent e) {
		Debugger.log(new Exception(), "mouseReleased");

		if (this.selectedNote != null && this.prePostionRect != null) {
			attach();
		} else {
			if (this.isDragging) {
				this.dragEndPoint = e.getPoint();
				NoteComposite note = this.getSelectedNote();
				Debugger.log(new Exception(), note);
				if (note.getNoteCount() > 0) {
					this.selectedNote = note;
					this.selectedNote.selected(true);
				}
				this.update(this.getGraphics());
			}
		}
		this.isDragging = false;
		this.debuggerRefresh();
		this.currentSelectedRect = new Rectangle();
		this.repaint();
	}

	private NoteComposite getSelectedNote() {
		NoteComposite note = new NoteComposite();
		Component[] component = this.getComponents();
		for (int i = 0; i < component.length; i++) {
			if (component[i] != null && component[i] instanceof Note) {
				Rectangle rect = new Rectangle();
				rect.x = dragStartPoint.x;
				if (rect.x > dragEndPoint.x) {
					rect.x = dragEndPoint.x;
				}
				rect.y = dragStartPoint.y;
				if (rect.y > dragEndPoint.y) {
					rect.y = dragEndPoint.y;
				}

				rect.width = Math.abs(dragEndPoint.x - dragStartPoint.x);
				rect.height = Math.abs(dragEndPoint.y - dragStartPoint.y);
				if (rect
					.contains(
						component[i].getX() + component[i].getWidth() / 2,
						component[i].getY() + component[i].getHeight() / 2)) {
					note.add((Note) component[i]);
				}
			}
		}
		return note;
	}

	private int getTotalNoteComponentCount() {
		int count = 0;
		Component[] components = this.getComponents();
		for (int i = 0; i < components.length; i++) {
			if (components[i] != null && components[i] instanceof Note) {
				count++;
			}
		}
		return count;
	}

	private void recalculateVirtualPoint() {
		int totalNoteComponentCount = this.getTotalNoteComponentCount();

		Component[] components = this.getComponents();
		long currentTime = System.currentTimeMillis();
		for (int i = 0; i < this.virtualPoints.length; i++) {
			for (int j = 0; j < this.virtualPoints[i].length; j++) {
				for (int k = 0; k < components.length; k++) {
					if (components[k] != null
						&& components[k] instanceof Note) {
						Note note = (Note) components[k];
						int x = this.virtualPoints[i][j].x - note.getX();
						int y = this.virtualPoints[i][j].y - note.getY();

						boolean isHidden = note.contains(x, y);
						if (isHidden) {
							if (!this.selectedNote.contains(note)) {
								this.virtualPoints[i][j].setHidden(true);
								break;
							} else {
								this.virtualPoints[i][j].setHidden(false);
							}
						} else {
							if (this.selectedNote.contains(note)) {
								this.virtualPoints[i][j].setHidden(false);
							}
						}
					}
				}
			}
		}
	}

	//	public Dimension getPreferredSize() {
	//		return PREFERRED_SIZE;
	//	}

	public void update(Graphics g) {
		this.paint(g, true);
	}

	public void paint(Graphics g, boolean paintRow) {
		//		super.paint(g);
		if (isOpaque()) { //paint background
			g.setColor(getBackground());
			g.fillRect(0, 0, getWidth(), getHeight());
		}

		Component[] com = this.getComponents();
		boolean isSelected = false;
		for (int i = 0; com != null && i < com.length; i++) {
			if (this.selectedNote != null) {
				if (com[i] instanceof Note) {
					Note note = (Note) com[i];
					if (this.selectedNote.contains(note)) {
						isSelected = true;
					}
				}
			}

			if (!isSelected) {
				g.translate(com[i].getX(), com[i].getY());
				com[i].paint(g);
				g.translate(-com[i].getX(), -com[i].getY());
			}
			isSelected = false;
		}

		if (this.selectedNote != null) {
			Vector notes = this.selectedNote.getNotes();
			if (notes != null) {
				for (int i = 0; i < notes.size(); i++) {
					Object object = notes.get(i);
					if (object != null && object instanceof Note) {
						Note note = (Note) object;
						g.translate(note.getX(), note.getY());
						note.paint(g);
						g.translate(-note.getX(), -note.getY());
					}
				}
			}
		}

		g.setColor(Color.BLACK);
		for (int i = 0; i < ROW_COUNT; i++) {
			boolean isEmpty = true;
			for (int k = 0; k < this.virtualPoints[i].length; k++) {
				isEmpty = !this.virtualPoints[i][k].isHidden();
				if (i == 0) {
					isEmpty = false;
				}
				
				if (!isEmpty) {
					break;
				}
			}
			
			

			if (!isEmpty || paintRow) {
				for (int j = 0; j <= TAB_COUNT; j++) {
					if (j == 0) {
						Font font = g.getFont();
						g.setFont(
							new Font(
								"BookMan Old Style",
								Font.ITALIC | Font.BOLD,
								10));
						g.drawString(
							String.valueOf(i + 1),
							OFFSET + j * (WIDTH / 4) - 5,
							TITLE_HEIGHT
								+ i * HEIGHT
								+ (HEIGHT - BAR_HEIGHT) / 2
								- 2);
						g.setFont(font);

					}
					g.fillRect(
						OFFSET + j * (WIDTH / 4),
						TITLE_HEIGHT + i * HEIGHT + (HEIGHT - BAR_HEIGHT) / 2,
						THICK,
						BAR_HEIGHT);
				}
				g.fillRect(
					OFFSET,
					TITLE_HEIGHT + HEIGHT * i + HEIGHT / 2,
					WIDTH,
					THICK);
			}

		}

		if (this.currentSelectedRect != null) {
			g.drawRect(
				currentSelectedRect.x,
				currentSelectedRect.y,
				currentSelectedRect.width,
				currentSelectedRect.height);
		}

		if (this.prePostionRect != null) {
			g.drawRect(
				prePostionRect.x,
				prePostionRect.y,
				prePostionRect.width,
				prePostionRect.height);
		}
	}

	public void paint(Graphics g) {
		this.paint(g, true);
	}

	public void init() {
		this.setFocusable(true);
		this.setRequestFocusEnabled(true);
		this.setLayout(null);
		this.dragStartPoint = new Point();
		this.dragEndPoint = new Point();
		this.dragPreviousPoint = new Point();
		this.isDragging = false;
		this.selectedNote = null;
		this.clipboardNote = null;
		this.selectedOffsetX = 0;
		this.selectedOffsetY = 0;
		this.initVirtualPoints();
		this.prePostionRect = null;
		this.currentPrePositionRect = new Rectangle();
		this.currentSelectedRect = new Rectangle();
		this.file = null;
		this.removeAll();
		this.revalidate();
		this.repaint();
	}

	public void initTitle() {
		this.title.setText("No Title");
		this.title.setHorizontalAlignment(JTextField.CENTER);
		this.add(this.title);
		this.title.setBounds(
			OFFSET + WIDTH / 2 - TITLE_WIDTH / 2,
			OFFSET,
			TITLE_WIDTH,
			TITLE_HEIGHT - 2 * OFFSET);
		this.title.resize();
		this.revalidate();
		this.repaint();
	}

	public void open() {
		Debugger.log(new Exception(), "open");
		this.openning = true;
		File selectedFile = null;
		FileFilter filter = new DefaultFileFilter(DefaultFileFilter.CTB);
		fileChooser.setFileFilter(filter);
		if (JFileChooser.APPROVE_OPTION == fileChooser.showOpenDialog(this)) {
			selectedFile = fileChooser.getSelectedFile();
		}

		if (selectedFile == null) {
			return;
		} else {
			if (!selectedFile.getName().endsWith(filter.getDescription())) {
				return;
			}
		}

		this.init();
		this.file = selectedFile;

		BufferedReader reader = null;
		try {
			reader =
				new BufferedReader(
					new InputStreamReader(new FileInputStream(selectedFile)));
			int lineNumber = 0;
			String line = null;
			while ((line = reader.readLine()) != null) {
				lineNumber++;
				String[] value = line.split(";");
				Object object = Class.forName(value[0]).newInstance();
				if (object != null) {
					boolean isValidComponent = false;
					if (lineNumber == 1) {
						if (object instanceof TitleTextField) {
							this.title = (TitleTextField) object;
							this.title.setText(value[1]);
							isValidComponent = true;
						}
					} else {
						if (object instanceof Note) {
							Note note = (Note) object;
							note.setType(Integer.parseInt(value[1]));
							note.setTemplate(false);
							note.setSheet(this);
							isValidComponent = true;
						}
					}

					if (isValidComponent) {
						Component com = (Component) object;
						Rectangle rect =
							new Rectangle(
								Integer.parseInt(value[2]),
								Integer.parseInt(value[3]),
								Integer.parseInt(value[4]),
								Integer.parseInt(value[5]));
						this.add(com);
						com.setBounds(rect);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (Exception e) {

				}
			}
			this.openning = false;
		}
		this.revalidate();
		this.repaint();
		this.title.setHorizontalAlignment(JTextField.CENTER);
		this.title.resize();
		Debugger.log(new Exception(), "open end");
	}

	private String getBoundsInfo(Component com) {
		StringBuffer content = new StringBuffer();
		Rectangle rect = com.getBounds();
		content.append(rect.x);
		content.append(";");
		content.append(rect.y);
		content.append(";");
		content.append(rect.width);
		content.append(";");
		content.append(rect.height);
		return content.toString();
	}

	private void save(File curentFile) {
		StringBuffer content = new StringBuffer();
		Component[] com = this.getComponents();
		content.append(this.title.getClass().getName());
		content.append(";");
		content.append(this.title.getText());
		content.append(";");
		content.append(this.getBoundsInfo(this.title));
		content.append("\r\n");

		for (int i = 0; com != null && i < com.length; i++) {
			if (com[i] != null && com[i] instanceof Note) {
				Note note = (Note) com[i];
				content.append(note.getClass().getName());
				content.append(";");
				content.append(note.getType());
				content.append(";");
				content.append(this.getBoundsInfo(note));
				content.append("\r\n");
			}
		}

		BufferedWriter writer = null;
		try {
			writer =
				new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream(curentFile)));
			writer.write(content.toString());
			writer.flush();
		} catch (Exception e) {
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (Exception e) {

				}
			}
		}
	}

	public void saveAs() {
		File selectedFile = this.getSaveFile();
		if (selectedFile != null) {
			this.save(selectedFile);
			this.file = selectedFile;
		}
	}

	public File getSaveFile() {
		File selectedFile = null;
		fileChooser.setFileFilter(filter);
		if (JFileChooser.APPROVE_OPTION == fileChooser.showSaveDialog(this)) {
			selectedFile = fileChooser.getSelectedFile();
		}

		if (selectedFile == null) {
			return null;
		} else {
			if (!selectedFile.getName().endsWith(filter.getDescription())) {
				selectedFile =
					new File(
						selectedFile.getParent(),
						selectedFile.getName() + "." + filter.getDescription());
			}
		}
		return selectedFile;
	}

	public void save() {
		if (this.file == null) {
			File selectedFile = this.getSaveFile();
			if (selectedFile != null) {
				this.save(selectedFile);
				this.file = selectedFile;
			}
		} else {
			this.save(this.file);

		}
	}

	public Dimension getPrintPreferredSize() {
		return new Dimension(WIDTH + OFFSET * 2, 2 * TITLE_HEIGHT + HEIGHT * this.getRowCount());
	}
	
	public int getRowCount() {
		int rowCont = 0;
		for (int i = 0; i < ROW_COUNT; i++) {
		boolean isEmpty = true;
			for (int k = 0; k < this.virtualPoints[i].length; k++) {
				isEmpty = !this.virtualPoints[i][k].isHidden();
				if (i == 0) {
					isEmpty = false;
				}
		
				if (!isEmpty) {
					rowCont++;
					break;
				}
			}
		}
		return rowCont;
	}
	
	public void saveAsImage() {
		if (this.selectedNote != null) {
			this.selectedNote.selected(false);
		}
		
		File selectedFile = null;
		fileChooser.setFileFilter(new DefaultFileFilter(DefaultFileFilter.JPG));
		if (JFileChooser.APPROVE_OPTION == fileChooser.showSaveDialog(this)) {
			selectedFile = fileChooser.getSelectedFile();
		}

		if (selectedFile == null) {
			return;
		} else {
			if (!selectedFile.getName().endsWith(fileChooser.getFileFilter().getDescription())) {
				selectedFile =
					new File(
						selectedFile.getParent(),
						selectedFile.getName()
							+ "."
							+ fileChooser.getFileFilter().getDescription());
			}
		}

		Dimension size = this.getPrintPreferredSize();
		BufferedImage image =
			new BufferedImage(
				size.width,
				size.height,
				BufferedImage.TYPE_INT_RGB);
		Graphics2D g2 = image.createGraphics();
		this.paint(g2, false);
		try {
			OutputStream out = new FileOutputStream(selectedFile);
			JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
			encoder.encode(image);
			out.close();
		} catch (Exception e) {
		}
	}

	public DebuggerPanel getDebuggerPanel() {
		return debuggerPanel;
	}

	public void setDebuggerPanel(DebuggerPanel panel) {
		debuggerPanel = panel;
	}

	public void componentHidden(ComponentEvent e) {
		this.debuggerRefresh();
	}

	public void componentMoved(ComponentEvent e) {
		this.debuggerRefresh();
	}

	public void debuggerRefresh() {
		if (this.debuggerPanel != null) {
			this.debuggerPanel.refresh();
		}
	}

	public void componentResized(ComponentEvent e) {
		this.debuggerRefresh();
	}

	public void componentShown(ComponentEvent e) {
		this.debuggerRefresh();

	}

	public JFileChooser getFileChooser() {
		return fileChooser;
	}

	//	protected void paintComponent(Graphics g) {
	////		super.paintChildren(g);
	//		Component[] com = this.getComponents();
	//		for (int i = 0; com != null && i < com.length; i++) {
	//			if (this.selectedNote != null) {
	//				if (com[i] instanceof Note) {
	//					Note note = (Note) com[i];
	//					this.selectedNote.contains(note);
	//					note.paint(g);
	//				}
	//			}
	//		}
	//		
	//		if (this.selectedNote != null) {
	//			Vector notes = this.selectedNote.getNotes();
	//			if (notes != null) {
	//				for (int i = 0; i < notes.size(); i++) {
	//					Object object = notes.get(i);
	//					if (object != null && object instanceof Note) {
	//						Note note = (Note) object;
	//						note.paint(g);
	//					}
	//				}
	//			}
	//		}
	//	}

	public void setSelectedNote(NoteComposite composite) {
		selectedNote = composite;
	}

}
