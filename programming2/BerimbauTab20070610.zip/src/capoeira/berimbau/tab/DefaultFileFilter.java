package capoeira.berimbau.tab;

import java.io.File;

import javax.swing.filechooser.FileFilter;

public class DefaultFileFilter extends FileFilter {
	public final static String CTB = "ctb";
	public final static String JPG = "jpg";
	
	private String ext;

	public DefaultFileFilter(String ext) {
		this.ext = ext;
	}
	public boolean accept(File f) {
		if (f.isDirectory()) {
			return true;
		}

		return f.getName().endsWith(this.ext);
	}

	public String getDescription() {
		return this.ext;
	}
}