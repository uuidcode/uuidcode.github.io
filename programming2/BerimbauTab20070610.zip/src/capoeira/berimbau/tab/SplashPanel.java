package capoeira.berimbau.tab;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JWindow;

public class SplashPanel extends JWindow {
	private JLabel initialingLabel;
	private static String mainImage = Main.IMAGE_DIR + "berimbau" + Main.IMAGE_EXT;
	
	public SplashPanel() {
		super();
		PlayMP3 play = new PlayMP3(Main.IMAGE_DIR + "berimbau.mp3");
		play.start();
	}

	public void showSplash() {
		JPanel content = (JPanel) getContentPane();
		content.setBackground(Color.white);

		// Set the window's bounds, centering the window
		int width = 375;
		int height = 500;
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (screen.width - width) / 2;
		int y = (screen.height - height) / 2;
		setBounds(x, y, width, height);

		// Build the splash screen
		JLabel label =
			new JLabel(new ImageIcon(mainImage));
//		JLabel titleLabel = new JLabel("Berimbau Tab", JLabel.CENTER);
		this.initialingLabel = new JLabel("");
		this.initialingLabel.setHorizontalAlignment(JLabel.CENTER);
//		titleLabel.setFont(new Font("Sans-Serif", Font.BOLD, 12));
		JPanel panel = new JPanel(new BorderLayout());
		panel.setBackground(Color.white);
//		panel.add(titleLabel, BorderLayout.NORTH);
		panel.add(label, BorderLayout.CENTER);
		content.add(panel, BorderLayout.CENTER);
		content.add(initialingLabel, BorderLayout.SOUTH);
		content.setBorder(BorderFactory.createLineBorder(Color.BLACK, 5));
		setVisible(true);		
	}

	public static String getMainImage() {
		return mainImage;
	}

}
