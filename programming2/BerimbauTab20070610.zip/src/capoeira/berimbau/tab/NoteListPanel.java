package capoeira.berimbau.tab;

import java.awt.Component;

import javax.swing.JPanel;

import capoeira.berimbau.tab.note.Note;

public class NoteListPanel extends JPanel {
	private NoteSheet sheet;
	
	public NoteSheet getSheet() {
		return sheet;
	}

	public void setSheet(NoteSheet sheet) {
		this.sheet = sheet;
	}
	
	public Component add(Component com) {
		super.add(com);
		
		if (com instanceof Note) {
			Note note = (Note) com;
			note.setSheet(this.sheet);			
		}
		
		return com;
	}
}
