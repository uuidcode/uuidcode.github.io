package capoeira.berimbau.tab;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;

public class Tab extends JPanel {
	private final static int WIDTH = 800;
	private final static int HEIGHT = 100;
	private final static int THICK = 2;
	private final static int OFFSET = 10;
	private final static int BAR_HEIGHT = 20;
	private final static Dimension PREFERRED_SIZE = new Dimension(WIDTH + (2 * OFFSET), HEIGHT);
		
	public Dimension getPreferredSize() {
		return PREFERRED_SIZE;
	}

	public void paint(Graphics g) {
		g.setColor(Color.BLACK);
		g.fillRect(OFFSET, HEIGHT/2 - 1, WIDTH, THICK);
		for (int i = 0; i < 5; i++) {
			g.fillRect(OFFSET + i*(WIDTH/4), (HEIGHT - BAR_HEIGHT)/2, THICK, BAR_HEIGHT);
		}
	}
}
