package caruru;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.zip.CRC32;

public class CheckSum {
	public static long getChecksumValue(File f) throws Exception {
		CRC32 checksum = new CRC32();
		checksum.reset();
		BufferedInputStream inputStream = null;

		try {
			inputStream = new BufferedInputStream(new FileInputStream(f));
			byte[] bytes = new byte[1024];
			int len = 0;
			while ((len = inputStream.read(bytes)) >= 0) {
				checksum.update(bytes, 0, len);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (Exception e) {
			}
		}
		return checksum.getValue();
	}
}
