package caruru;

import caruru.client.Client;
import caruru.server.Server;

public class Caruru {
	public final static String NAME = "Caruru";
	
	public static void main(String[] args) {
		Log.log(new Exception(), "Caruru started.");
		if (args != null && 
			args.length == 1 && 
			"-server".equals(args[0])) {
			new Server().run();		
		} else if (args != null && 
			args.length == 1 && 
			"-copy".equals(args[0])) {
			new Client().copy(Caruru.NAME);		
		} else if (args != null && 
			args.length == 2 && 
			"-copy".equals(args[0])) {
			new Client().copy(args[1]);			
		} else if (args != null && 
			args.length >= 1 && 
			"-run".equals(args[0])) {
			if (args.length >= 2) {
				new Client().update(args[1]);
			} else {
				new Client().run();
			}
		} else {
			System.out.println("Unrecognized option");
		}
		
		Log.log(new Exception(), "Caruru finished.");
		System.exit(0);
	}
}
