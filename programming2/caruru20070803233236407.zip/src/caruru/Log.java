package caruru;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Log {
	private final static int MAX_SIZE = 1024 * 1024 * 5;
	public final static String LOG_FILE_NAME = "caruru.log";
	public final static File LOG_FILE = new File(LOG_FILE_NAME);
	
	static {
		if (LOG_FILE.exists()) {
			if (LOG_FILE.length() > MAX_SIZE ) {
				LOG_FILE.delete();
			}
		}
	}
	
	private static String getCurrentDate() {
		return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
	}
		
	public static void log(Exception e) {
		StringBuffer buffer = new StringBuffer();
		StackTraceElement[] elements = e.getStackTrace();
		for (int i = 0; i < elements.length; i++) {
			buffer.append(elements[i] + "\r\n");
		}
		log(e, buffer.toString());
	}
	
	public static void log(Exception e, String name, String value) {
		log(e, "[" + name + "=" + value + "]");
	}
		
	public static void log(Exception exception, String log) {
		BufferedWriter writer = null;
		try {
			writer =
				new BufferedWriter(
					new OutputStreamWriter(
						new FileOutputStream(LOG_FILE, true)));
			StringBuffer format = new StringBuffer();
			format.append(getCurrentDate());
			format.append(" ");
			format.append(exception.getStackTrace()[0]);
			format.append(" ");
			format.append(log);
			format.append("\r\n");
			writer.write(format.toString());
		} catch (Exception e) {
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (Exception e) {
				}
			}
		}
	}
}
