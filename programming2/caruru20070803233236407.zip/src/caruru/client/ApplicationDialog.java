package caruru.client;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import caruru.Log;

public class ApplicationDialog extends JDialog {
	private ApplicationInfo app = null;
	private String oldName = null;
	private CaruruUI owner = null;
	private ApplicationInfo[] apps = null;
	public ApplicationDialog(CaruruUI owner, String title, String name)  {
		super(owner, title, true);
		System.out.println(UIUtility.getFrame(owner));
		this.owner = owner;
		try {
			apps = ApplicationInfo.getApplicationInfo();
		} catch (Exception e) {
		}
		 
				
		String server = "";
		String port = "";
		
		if (name == null) {
			name = "";
			oldName = "";
		} else {
			oldName = name;
			for (int i = 0; i < apps.length; i++) {
				if (name.equals(apps[i].getName())) {
					app = apps[i];	
					break;
				}
			}
	
			if (app != null) {
				server = app.getIP();
				port = String.valueOf(app.getPort());
			}
		}
		
		JPanel panel = new JPanel(new GridLayout2(3, 2));
		
		panel.add(new JLabel("Name"));
		JPanel namePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		final JTextField nameTextField = new JTextField(name);
		nameTextField.setColumns(15);
		namePanel.add(nameTextField);
		panel.add(namePanel);
		
		panel.add(new JLabel("Server"));
		JPanel serverPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		final JTextField serverTextField = new JTextField(server);
		serverTextField.setColumns(15);
		serverPanel.add(serverTextField);
		panel.add(serverPanel);
		
		panel.add(new JLabel("Port"));
		JPanel portPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		final JTextField portTextField = new JTextField(port);
		portTextField.setColumns(5);
		portPanel.add(portTextField);
		panel.add(portPanel);
		
		panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		
		JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JButton okButton = new JButton("OK");
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (app != null) {
					if (!oldName.equals(nameTextField.getText())) {
						for (int i = 0; i < apps.length; i++) {
							if (apps[i].getName().equals(nameTextField.getText())) {
								JOptionPane.showMessageDialog(
								UIUtility.getFrame(ApplicationDialog.this.owner),
								nameTextField.getText() + " already exist.",
								"Caruru error",
								JOptionPane.ERROR_MESSAGE);
								return;
							}
						}
					}
					
					app.setName(nameTextField.getText());
					app.setIP(serverTextField.getText());
					app.setPort(Integer.parseInt(portTextField.getText()));				
				
					try {
						ApplicationInfo.save(apps);
					} catch (Exception ex) {
						Log.log(new Exception(), ex.toString());
					}
				} else {
					for (int i = 0; i < apps.length; i++) {
						if (apps[i].getName().equals(nameTextField.getText())) {
							JOptionPane.showMessageDialog(
							UIUtility.getFrame(ApplicationDialog.this.owner),
							nameTextField.getText() + " already exist.",
							"Caruru error",
							JOptionPane.ERROR_MESSAGE);
							return;
						}
					}
										
					app = new ApplicationInfo();
					app.setName(nameTextField.getText());
					app.setIP(serverTextField.getText());
					app.setPort(Integer.parseInt(portTextField.getText()));
					
					ApplicationInfo[] newApps = new ApplicationInfo[apps.length + 1];
					for (int i = 0; i < apps.length; i++) {
						newApps[i] = apps[i];
					}
								
					newApps[apps.length] = app;
					try {
						ApplicationInfo.save(newApps);
					} catch (Exception ex) {
						Log.log(new Exception(), ex.toString());
					}
				}
				
				ApplicationDialog.this.owner.refresh();
				dispose();
			}
		});
		bottomPanel.add(okButton);
		
		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		bottomPanel.add(cancelButton);
		
		JPanel mainPanel = new JPanel(new BorderLayout());
		mainPanel.add(panel, BorderLayout.CENTER);
		mainPanel.add(bottomPanel, BorderLayout.SOUTH);
		
		this.setContentPane(mainPanel);
		int width = 250;
		int height = 160;
		setSize(new Dimension(width, height));
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (screen.width - width) / 2;
		int y = (screen.height - height) / 2;
		this.setLocation(x, y);
		this.setResizable(false);
	}
}
