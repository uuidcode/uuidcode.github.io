package caruru.client;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.Timer;

public class CaruruUI extends JFrame {
	private static final String LIST_MODE = "list";
	private static final String DOWNLOAD_MODE = "download";
	private final static String BUILD_ID_FILE = "buildId";
	private final static String VERSION_FILE = "version";
	private final static int DEFAULT_WIDTH = 400;
	private final static int DEFAULT_HEIGHT = 400;

	private JProgressBar mainProgress = null;
	private JProgressBar fileProgress = null;
	private JLabel mainLabel = null;
	private JLabel fileLabel = null;
	private JLabel titleLabel = null;
	private JTextArea errorTextArea = null;
	private JPanel contentPanel = null;
	private JPanel mainPanel = null;
	private boolean isClose = false;
	private JList applicationList = null;
	private CardLayout cardLayout = null;
	private static CaruruUI caruruInstance;

	public static CaruruUI getInstance() {
		if (caruruInstance == null) {
			caruruInstance = new CaruruUI();
		}
		return caruruInstance;
	}

	private CaruruUI() {
		super();
		String version = this.getStringFromFile(new File(VERSION_FILE));
		String buildId = this.getStringFromFile(new File(BUILD_ID_FILE));
		this.setTitle("Caruru version " + version + " buildId " + buildId);
		UIUtility.setUI();
		this.addWindowListener(new WindowListener() {
			public void windowActivated(WindowEvent e) {
			}

			public void windowClosed(WindowEvent e) {
				isClose = true;
			}

			public void windowClosing(WindowEvent e) {
				isClose = true;
			}

			public void windowDeactivated(WindowEvent e) {
			}

			public void windowDeiconified(WindowEvent e) {
			}

			public void windowIconified(WindowEvent e) {
			}

			public void windowOpened(WindowEvent e) {
			}
		});

		this.setIconImage(
			Toolkit.getDefaultToolkit().getImage("resource/image/header.gif"));

		//		CurvesPanel glassPane = new CurvesPanel();
		//		this.setGlassPane(glassPane);
		//		glassPane.setVisible(true);

		this.contentPanel = new JPanel();
		this.contentPanel.setLayout(
			new BoxLayout(this.contentPanel, BoxLayout.Y_AXIS));

		this.contentPanel.add(this.getHeaderPanel());
		this.contentPanel.add(new JSeparator(SwingConstants.HORIZONTAL));

		this.cardLayout = new CardLayout();
		this.mainPanel = new JPanel(cardLayout);
		//cardLayout.addLayoutComponent(this.getApplicationPanel(), LIST_MODE);
		//cardLayout.addLayoutComponent(this.getDownloadPanel(), DOWNLOAD_MODE);
		this.mainPanel.add(this.getApplicationPanel(), LIST_MODE);
		this.mainPanel.add(this.getDownloadPanel(), DOWNLOAD_MODE);
		cardLayout.show(this.mainPanel, LIST_MODE);

		this.contentPanel.add(this.mainPanel);

		this.contentPanel.add(this.getFooterPanel());
		this.getContentPane().add(this.contentPanel);

//				TransparentPanel glassPane = new TransparentPanel();
//				this.setGlassPane(glassPane);
//				glassPane.setVisible(true);

		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (screen.width - DEFAULT_WIDTH) / 2;
		int y = (screen.height - DEFAULT_HEIGHT) / 2;
		this.setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
		this.setLocation(x, y);
		this.setResizable(false);
		this.setVisible(true);
	}

	public void refresh() {
		try {
			this.applicationList.setListData(
				ApplicationInfo.getApplicationInfo());
		} catch (Exception e) {
			this.setErrorMessage(e.getMessage());
		}
	}

	private JPanel getFooterPanel() {
		JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JButton closeButton = new JButton("Close");
		closeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				isClose = true;
			}
		});
		footerPanel.add(closeButton);
		return footerPanel;
	}

	private JPanel getHeaderPanel() {
		final JPanel titlePanel = new JPanel();
		Timer animation = new Timer(50, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				titlePanel.repaint();
			}
		});
		animation.start();
		titlePanel.setLayout(new BorderLayout());
		titlePanel.setBackground(Color.WHITE);
		JLabel label = new JLabel("Caruru");
		this.titleLabel =
			new JLabel(" - Select application. Click \"Run\" button.");
		label.setFont(new Font("Gulim", Font.BOLD, 20));
		titlePanel.add(label, BorderLayout.CENTER);
		titlePanel.add(this.titleLabel, BorderLayout.SOUTH);
		titlePanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

		JPanel bannerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		bannerPanel.setBackground(Color.WHITE);
		bannerPanel.add(new JLabel(new ImageIcon("resource/image/header.gif")));

		JPanel headerPanel = new JPanel(new BorderLayout());
		headerPanel.add(titlePanel, BorderLayout.CENTER);
		headerPanel.add(bannerPanel, BorderLayout.EAST);
		headerPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, 60));
		headerPanel.setBackground(Color.WHITE);
		return headerPanel;
	}

	private JPanel getApplicationPanel() {
		JPanel applicationPanel = new JPanel();
		applicationPanel.setLayout(new BorderLayout());
		JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		JButton runButton = new JButton("Run");
		runButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ApplicationInfo.setApplicationNumber(
					applicationList.getSelectedIndex());
			}
		});
		controlPanel.add(runButton);

		JButton newButton = new JButton("New");
		newButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					JDialog dailog =
						new ApplicationDialog(
							CaruruUI.this,
							"Caruru - New application",
							null);
					dailog.show();
				} catch (Exception ex) {
				}
			}
		});
		controlPanel.add(newButton);

		JButton editButton = new JButton("Edit");
		editButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object object = applicationList.getSelectedValue();
				if (object != null && object instanceof ApplicationInfo) {
					ApplicationInfo info = (ApplicationInfo) object;
					JDialog dialog =
						new ApplicationDialog(
							CaruruUI.this,
							"Caruru - Edit application",
							info.getName());
					dialog.show();
				}

			}
		});
		controlPanel.add(editButton);

		JButton removeButton = new JButton("Remove");
		removeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object object = applicationList.getSelectedValue();
				String selectApplicationName = null;
				if (object != null && object instanceof ApplicationInfo) {
					ApplicationInfo info = (ApplicationInfo) object;
					selectApplicationName = info.getName();
				} else {
					return;
				}

				if (JOptionPane.OK_OPTION
					!= JOptionPane.showConfirmDialog(
						UIUtility.getFrame(CaruruUI.this),
						"Do you want to remove \""
							+ selectApplicationName
							+ "\"?",
						"Caruru",
						JOptionPane.OK_CANCEL_OPTION)) {
					return;
				}

				try {
					ApplicationInfo[] apps =
						ApplicationInfo.getApplicationInfo();
					ApplicationInfo[] newApps =
						new ApplicationInfo[apps.length - 1];
					int currentIndex = 0;
					for (int i = 0; i < apps.length; i++) {
						if (!apps[i].getName().equals(selectApplicationName)) {
							newApps[currentIndex++] = apps[i];
						}
					}
					ApplicationInfo.save(newApps);
					refresh();
				} catch (Exception ex) {
				}
			}
		});
		controlPanel.add(removeButton);

		this.applicationList = new JList();
		this.applicationList.setCellRenderer(new ApplicationPanel());
		this.applicationList.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 2) {
					ApplicationInfo.setApplicationNumber(
						applicationList.getSelectedIndex());
				}
			}
		});

		try {
			applicationList.setListData(ApplicationInfo.getApplicationInfo());
			this.applicationList.setSelectedIndex(0);
		} catch (Exception e) {
			setErrorMessage(e.getMessage());
		}

		applicationPanel.add(
			new JScrollPane(this.applicationList),
			BorderLayout.CENTER);
		applicationPanel.add(controlPanel, BorderLayout.NORTH);
		applicationPanel.setBorder(
			BorderFactory.createEmptyBorder(10, 10, 10, 10));
		applicationPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, 400));
		return applicationPanel;
	}

	private String getStringFromFile(File f) {
		BufferedReader reader = null;
		try {
			reader =
				new BufferedReader(
					new InputStreamReader(new FileInputStream(f)));
			String line = null;
			return reader.readLine();
		} catch (Exception e) {
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (Exception e) {
				}
			}
		}

		return null;
	}

	public void setMainProgressValue(int value) {
		this.mainProgress.setValue(value);
	}

	public void setFileProgressValue(int value) {
		this.fileProgress.setValue(value);
	}

	public void setMainLabelText(String text) {
		this.mainLabel.setText(text);
	}

	public void setFileLabelText(String text) {
		this.fileLabel.setText(text);
	}

	public void setDownloadMode(String applicatonName) {
		this.titleLabel.setText(" - " + applicatonName + " is downloading.");
		this.cardLayout.show(this.mainPanel, DOWNLOAD_MODE);
	}

	private JPanel getDownloadPanel() {
		JPanel downloadPanel = new JPanel(new GridLayout(2, 1));
		this.mainLabel = new JLabel();
		this.mainProgress = new JProgressBar();
		mainProgress.setMinimum(0);
		mainProgress.setMaximum(100);
		mainProgress.setStringPainted(true);
		downloadPanel.add(mainLabel);
		downloadPanel.add(mainProgress);

		JPanel filePanel = new JPanel(new GridLayout(2, 1));
		this.fileLabel = new JLabel();
		this.fileProgress = new JProgressBar();
		fileProgress.setMinimum(0);
		fileProgress.setMaximum(100);
		fileProgress.setStringPainted(true);
		filePanel.add(fileLabel);
		filePanel.add(fileProgress);

		JPanel progressPanel = new JPanel(new GridLayout(2, 1));
		progressPanel.add(downloadPanel);
		progressPanel.add(filePanel);
		progressPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, 400));
		progressPanel.setBorder(
			BorderFactory.createEmptyBorder(10, 10, 10, 10));
		return progressPanel;
	}

	public void setErrorMessage(final String log) {
		JOptionPane.showMessageDialog(
			UIUtility.getFrame(CaruruUI.this),
			log,
			"Caruru error",
			JOptionPane.ERROR_MESSAGE);
	}

	public int select() throws Exception {
		while (ApplicationInfo.getApplicationNumber() == -1) {
			try {
				Thread.sleep(500);
				if (isClose) {
					throw new Exception("Close");
				}
			} catch (Exception e) {
				if ("Close".equals(e.getMessage())) {
					throw e;
				}
			}
		}
		return ApplicationInfo.getApplicationNumber();
	}
	public static void main(String[] args) throws InterruptedException {
		CaruruUI ui = new CaruruUI();
		ui.setIconImage(
			Toolkit.getDefaultToolkit().getImage("resource/image/header.gif"));

	}
}
