package caruru.client;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.util.Enumeration;

import javax.swing.BorderFactory;
import javax.swing.JTable;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

public class UIUtility {
	public static void setUI() {
		UIDefaults uiDefaults = UIManager.getDefaults();
		Color defaultColor = new Color(247, 255, 222);
		Font font = new Font("Gulim", Font.PLAIN, 12);
		Enumeration enum = uiDefaults.keys();
		while (enum.hasMoreElements()) {
			Object obj = enum.nextElement();

			String key = obj.toString();
			if (key.toLowerCase().indexOf("font") != -1) {
				UIManager.put(key, font);
			}

			Object value = UIManager.get(key);
			if (value != null
				&& value.toString().toLowerCase().indexOf("[r=204,g=204,b=204]")
					!= -1) {
				UIManager.put(key, defaultColor);
			}
		}

		UIManager.put("Button.background", defaultColor);
		UIManager.put("OptionPane.background", defaultColor);
		UIManager.put("Panel.background", defaultColor);
		UIManager.put("TabbedPane.background", defaultColor);
		UIManager.put("TabbedPane.tabAreaBackground", defaultColor);
		UIManager.put("TabbedPane.light", defaultColor);
		UIManager.put("TabbedPane.selected", defaultColor);
		UIManager.put("Label.background",defaultColor);
		UIManager.put("ScrollBar.background", defaultColor);
		UIManager.put("ViewPoint.background", defaultColor);
		UIManager.put("MenuBar.background", defaultColor);
		UIManager.put("Menu.background", defaultColor);
		UIManager.put("PopUpMenu.background", defaultColor);
		UIManager.put("Divider.background", defaultColor);
		UIManager.put("ScrollBar.thumb", defaultColor);
		UIManager.put("ScrollBar.thumbHighlight", defaultColor);
		UIManager.put("ScrollBar.background", defaultColor);
		UIManager.put("TableHeader.background", defaultColor);
		UIManager.put("ScrollPane.background", defaultColor);
		UIManager.put("Viewport.background", defaultColor);
		UIManager.put("ToolBar.background", defaultColor);
		UIManager.put("Window.background", defaultColor);
		UIManager.put("List.background", defaultColor);
		UIManager.put("Desktop.background", new Color(132, 130, 132));
	}

	public static Border getBorder(String name) {
		Border etchedTitleBorder = BorderFactory.createEtchedBorder();
		return BorderFactory.createTitledBorder(etchedTitleBorder, name);
	}

	public static Frame getFrame(Container container) {
		while (true) {
			if (container instanceof Frame) {
				return (Frame) container;
			}
			container = container.getParent();
			if (container == null) {
				break;
			}
		}

		return null;
	}

	public static void fixColumnSize(final JTable table) {
		new Thread() {
			public void run() {
				TableColumnModel model = table.getColumnModel();
				TableModel tableModel = table.getModel();
				int rowCount = tableModel.getRowCount();
				int columnCount = tableModel.getColumnCount();

				Graphics g = table.getGraphics();
				while (g == null) {
					g = table.getGraphics();
					try {
						Thread.sleep(1000);
					} catch (Exception e) {
					}
				}

				for (int i = 0; i < columnCount; i++) {
					int maxWidth = 40;
					FontMetrics metrics = g.getFontMetrics();
					int width =
						metrics.stringWidth(
							table
								.getColumnModel()
								.getColumn(i)
								.getIdentifier()
								.toString());
					if (width > maxWidth) {
						maxWidth = width;
					}

					for (int j = 0; j < rowCount; j++) {
						Object valueObject = tableModel.getValueAt(j, i);
						if (valueObject != null) {
							String value = valueObject.toString();
							width = metrics.stringWidth(value);
							if (width > maxWidth) {
								maxWidth = width;
							}
						}
					}
					model.getColumn(i).setPreferredWidth(maxWidth + 10);
				}
			}
		}
		.start();
	}
}
