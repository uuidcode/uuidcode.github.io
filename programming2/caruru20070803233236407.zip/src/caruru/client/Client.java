package caruru.client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import caruru.Caruru;
import caruru.CheckSum;
import caruru.Log;

public class Client {
	public Client() {
	}

	private Vector getChangedFiles(
		File workingDir,
		Document doc,
		boolean deleteAllowModifyFile) {
		Vector changedFiles = new Vector();
		List list = doc.selectNodes("/config/files/file");
		for (int i = 0; i < list.size(); i++) {
			Object object = list.get(i);
			if (object instanceof Element) {
				Element element = (Element) object;
				String fileName = element.valueOf("@name");
				String allowModify = element.valueOf("@allowModify");
				String checkSum = element.valueOf("@checksum");

				File file = new File(workingDir, fileName);
				if ("true".equals(allowModify)) {
					if (deleteAllowModifyFile) {
						file.delete();
					}
				} else {
					if (!file.exists()) {
						changedFiles.add(fileName);
					} else {
						try {
							long currentCheckSum =
								CheckSum.getChecksumValue(file);
							if (!checkSum
								.equals(String.valueOf(currentCheckSum))) {
								changedFiles.add(fileName);
							}
						} catch (Exception e) {
							changedFiles.add(fileName);
						}
					}
				}
			}
		}
		return changedFiles;
	}

	private void checkAndMakeDir(File workingDir, Document doc) {
		List list = doc.selectNodes("/config/files/dir");
		for (int i = 0; i < list.size(); i++) {
			Object object = list.get(i);
			if (object instanceof Element) {
				Element element = (Element) object;
				String dirName = element.valueOf("@name");
				Log.log(new Exception(), "checkDir " + dirName);
				File dirFile = new File(workingDir, dirName);
				if (!dirFile.exists()) {
					dirFile.mkdirs();
					Log.log(
						new Exception(),
						"make " + dirFile.getAbsolutePath());
				}
			}
		}
	}

	private void receiveFile(
		CaruruUI caruruUI,
		InputStream in,
		File f,
		long fileSize)
		throws Exception {
		if (f.exists()) {
			f.delete();
		}

		FileOutputStream fos = null;
		try {
			Log.log(new Exception(), f.getAbsolutePath());
			fos = new FileOutputStream(f);
			byte[] buffer = new byte[1024];
			int readSize = -1;
			long totalSize = 0;
			while ((readSize = in.read(buffer)) > 0) {
				fos.write(buffer, 0, readSize);
				fos.flush();
				totalSize += readSize;

				if (fileSize == totalSize) {
					break;
				}

				if (caruruUI != null) {
					caruruUI.setFileProgressValue(
						(int) ((double) 100
							* ((double) totalSize / (double) fileSize)));
				}

			}
		} catch (Exception e) {
			throw e;
		} finally {
			if (fos != null) {
				try {
					fos.close();
				} catch (Exception e) {
				}
			}
		}
	}

	private String readLine(InputStream in) throws Exception {
		byte[] buffer = new byte[1024];
		int readByte = 0;
		int i = 0;
		while ((readByte = in.read()) > 0) {
			if (readByte == 13) {
				readByte = in.read();
				buffer[i] = (byte) readByte;
				if (readByte == 10) {
					String readString = new String(buffer, 0, i);
					return readString;
				} else {
					buffer[i] = (byte) readByte;
				}
			} else {
				buffer[i] = (byte) readByte;
			}
			i++;
		}
		return null;
	}

	public Document getApplicatonXML(
		InputStream in,
		BufferedWriter writer,
		String applicationName)
		throws Exception {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ByteArrayInputStream bais = null;

		try {
			writer.write(applicationName + "\r\n");
			writer.flush();
			String line = null;
			while ((line = readLine(in)) != null) {
				if (".".equals(line)) {
					break;
				} else {
					baos.write((line + "\r\n").getBytes());
					baos.flush();
				}
			}
			bais = new ByteArrayInputStream(baos.toByteArray());
			Log.log(new Exception(), new String(baos.toByteArray()));
			SAXReader saxReader = new SAXReader();
			return saxReader.read(bais);
		} catch (Exception e) {
			throw e;
		} finally {
			if (bais != null) {
				try {
					bais.close();
				} catch (Exception e) {
				}
			}

			if (baos != null) {
				try {
					baos.close();
				} catch (Exception e) {
				}
			}
		}
	}

	private String getCurrentDate() {
		return getCurrentDate(new Date());
	}

	private String getCurrentDate(Date date) {
		return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
	}

	private void copy(File newFile, File old) {
		FileInputStream source = null;
		FileOutputStream destination = null;
		byte[] buffer = new byte[1024];
		int bytes_read;

		try {
			source = new FileInputStream(old);
			destination = new FileOutputStream(newFile);
			while (true) {
				bytes_read = source.read(buffer);
				if (bytes_read == -1)
					break;
				destination.write(buffer, 0, bytes_read);
			}
		} catch (IOException e) {
			Log.log(e);
		} finally {
			if (source != null)
				try {
					source.close();
				} catch (IOException e) {
					;
				}
			if (destination != null)
				try {
					destination.close();
				} catch (IOException e) {
					;
				}
		}
	}

	private void dirCopy(File destDir, File currentFileDir) {
		File[] list = currentFileDir.listFiles();
		for (int i = 0; i < list.length; i++) {
			File oldFile = list[i];
			if (oldFile.isFile()) {
				boolean isLogFile = Log.LOG_FILE_NAME.equals(oldFile.getName());
				if (!isLogFile) {
					File newFile = new File(destDir, list[i].getName());
					copy(newFile, list[i]);
					Log.log(
						new Exception(),
						oldFile.getAbsolutePath()
							+ "->"
							+ newFile.getAbsolutePath());
				}
			}

			if (oldFile.isDirectory()) {
				File newFile = new File(destDir, list[i].getName());
				newFile.mkdir();
				dirCopy(newFile, oldFile);
			}
		}
	}

	public void copy(String applicationName) {
		try {
			Thread.sleep(1000);
		} catch (Exception e) {
		}

		String currentDir = System.getProperty("user.dir");
		Log.log(new Exception(), "copy process");
		Log.log(new Exception(), "currentDir:" + currentDir);
		File f = new File(currentDir);
		if (f.exists()) {
			dirCopy(f.getParentFile(), f);
		}

		try {
			String command = "java -jar Caruru.jar -run";
			if (!Caruru.NAME.equals(applicationName)) {
				command += " " + applicationName;
			}

			Runtime.getRuntime().exec(command, null, f.getParentFile());
			Log.log(new Exception(), "exec " + command);
		} catch (Exception e) {
			Log.log(e);
		}
	}

	public void update(String applicatonName) {
		ApplicationInfo info = getApplicationInfo();
		if (info != null) {
			if (!this.update(info, true, applicatonName)) {
				try {
					ApplicationInfo[] applicationInfo =
						ApplicationInfo.getApplicationInfo();
					for (int i = 0; i < applicationInfo.length; i++) {
						if (applicatonName
							.equals(applicationInfo[i].getName())) {
							this.update(
								applicationInfo[i],
								false,
								applicationInfo[i].getName());
							return;
						}
					}
				} catch (Exception e) {
					Log.log(e);
				}
			}
		}
	}

	private boolean update(
		ApplicationInfo info,
		boolean isCaruruUpdate,
		String option) {

		Document document = null;
		BufferedWriter out = null;
		InputStream in = null;
		Socket socket = null;
		File runFile = null;
		File workingDir = null;
		boolean started = false;
		boolean isUpdated = false;
		boolean appInfoModified = false;
		CaruruUI caruruUI = CaruruUI.getInstance();

		Log.log(new Exception(), "update process.");
		try {
			Log.log(new Exception(), info.toString());

			workingDir = new File(info.getName());
			if (!workingDir.exists()) {
				Log.log(
					new Exception(),
					"make " + workingDir.getAbsolutePath() + ".");
				workingDir.mkdir();
				info.setInsatlledDate(
					new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(
						new Date()));
				appInfoModified = true;
			}

			if (!isCaruruUpdate) {
				runFile = new File(workingDir, "run.bat");
			}

			try {
				socket = new Socket(info.getIP(), info.getPort());
				in = socket.getInputStream();
				out =
					new BufferedWriter(
						new OutputStreamWriter(socket.getOutputStream()));
			} catch (Exception e) {
				caruruUI.setErrorMessage("Can't connect to the server.");
				throw e;
			}

			Document infoXML = this.getApplicatonXML(in, out, info.getName());

			String command = infoXML.valueOf("/config/command");
			String version = infoXML.valueOf("/config/version");
			String buildId = infoXML.valueOf("/config/buildId");
			String integrityDirName = infoXML.valueOf("/config/integrityDir");

			if (integrityDirName != null
				&& integrityDirName.trim().length() != 0) {
				File integrityDir =
					new File(workingDir + "/" + integrityDirName);
				if (integrityDir.exists()) {
					this.deleteDirectory(integrityDir);
				}
			}

			this.checkAndMakeDir(workingDir, infoXML);

			Vector changedFiles =
				this.getChangedFiles(workingDir, infoXML, true);

			if (changedFiles.size() > 0) {
				isUpdated = true;
			}

			if (isUpdated) {
				caruruUI.setDownloadMode(info.getName());
				caruruUI.setVisible(true);
				caruruUI.setMainLabelText(
					changedFiles.size() + " files updated.");
				info.setLastUpdatedDate(this.getCurrentDate());

				this.download(
					info.getName(),
					in,
					out,
					workingDir,
					changedFiles);

				caruruUI.setVisible(false);
				caruruUI.dispose();
			} else {
				Log.log(new Exception(), "no file updated.");
			}

			this.disconnect(out);

			if (isCaruruUpdate) {
				if (isUpdated) {
					command = "java -jar Caruru.jar -copy " + option;
					Log.log(new Exception(), "exec " + command);
					Runtime.getRuntime().exec(command, null, workingDir);
				}
			} else {
				if (isUpdated) {
					info.setLastUpdatedDate(
						new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(
							new Date()));
					info.setVersion(version);
					info.setBuildId(buildId);
					appInfoModified = true;
				}
				command += " " + info.getIP();
				command += " " + info.getPort();
				command += " " + info.getName();

				this.makeRunFile(runFile, command);
				this.makeRunFile(
					new File(info.getName() + ".bat"),
					"java -jar Caruru.jar -run " + info.getName());
				Log.log(new Exception(), "exec " + command);
				Runtime.getRuntime().exec(command, null, workingDir);
			}

			if (appInfoModified) {
				info.save();
			}
		} catch (Exception e) {
			caruruUI.dispose();

			Log.log(e);

			if (runFile != null
				&& runFile.exists()
				&& workingDir != null
				&& workingDir.exists()) {
				try {
					String oldCommand = this.getOldCommand(runFile);
					Log.log(new Exception(), oldCommand);
					Runtime.getRuntime().exec(oldCommand, null, workingDir);
				} catch (Exception ex) {
					Log.log(ex);
				}
			}
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (Exception e) {
				}
			}

			if (out != null) {
				try {
					out.close();
				} catch (Exception e) {
				}
			}

			if (socket != null) {
				try {
					socket.close();
				} catch (Exception e) {
				}
			}
			Log.log(new Exception(), "update complete");
			return isUpdated;
		}
	}

	private void download(
		String applicationName,
		InputStream in,
		BufferedWriter out,
		File workingDir,
		Vector changedFiles)
		throws IOException, Exception, InterruptedException {
		Log.log(new Exception(), "update files.");

		CaruruUI caruruUI = CaruruUI.getInstance();
		caruruUI.setVisible(true);
		caruruUI.setFocusable(true);
		caruruUI.setDownloadMode(applicationName);
		caruruUI.setMainLabelText(changedFiles.size() + " files updated.");

		for (int i = 0; i < changedFiles.size(); i++) {
			String fileName = changedFiles.get(i).toString();
			out.write(fileName + "\r\n");
			out.flush();
			String fileSize = readLine(in);
			String fileNameAndSize =
				fileName + "[" + Long.parseLong(fileSize) + " bytes]";

			caruruUI.setFileLabelText("download " + fileNameAndSize);

			Log.log(new Exception(), fileNameAndSize);

			caruruUI.setMainLabelText(
				changedFiles.size()
					+ " files updated. "
					+ (i + 1)
					+ "st file is downloading");
			this.receiveFile(
				caruruUI,
				in,
				new File(workingDir, fileName),
				Long.parseLong(fileSize));
			caruruUI.setMainProgressValue(
				(int) ((double) 100
					* ((double) (i + 1) / (double) changedFiles.size())));
			Thread.sleep(100);
		}
	}

	private void disconnect(BufferedWriter writer) throws IOException {
		writer.write(".\r\n");
		writer.flush();
	}

	private ApplicationInfo getApplicationInfo() {
		try {
			SAXReader saxReader = new SAXReader();
			Document configDocument =
				saxReader.read(ApplicationInfo.CONFIG_FILE);
			String ip = configDocument.valueOf("/config/server/@ip");
			String port = configDocument.valueOf("/config/server/@port");

			return new ApplicationInfo(
				false,
				Caruru.NAME,
				ip,
				Integer.parseInt(port),
				"",
				"");
		} catch (Exception e) {
			Log.log(e);
		}
		return null;
	}

	private boolean update() {
		ApplicationInfo info = getApplicationInfo();
		if (info != null) {
			return this.update(info, true, Caruru.NAME);
		}
		return true;
	}

	private void delete(File f) {
		if (f.isDirectory()) {
			File[] list = f.listFiles();
			for (int i = 0; i < list.length; i++) {
				if (list[i].isDirectory()) {
					delete(list[i]);
				} else {
					list[i].delete();
				}
			}
			f.delete();
		} else {
			f.delete();
		}
	}

	private boolean applicationIsUpdated(
		String ip,
		int port,
		String applicationName,
		String currentBuildId) {
		Document document = null;
		SAXReader saxReader = null;
		BufferedWriter writer = null;
		InputStream in = null;
		Socket socket = null;

		try {

			socket = new Socket(ip, port);
			in = socket.getInputStream();
			writer =
				new BufferedWriter(
					new OutputStreamWriter(socket.getOutputStream()));

			Document applicationXML =
				this.getApplicatonXML(in, writer, applicationName);
			String buildId = applicationXML.valueOf("/config/buildId");
			writer.write(".\r\n");
			writer.flush();
			return currentBuildId.equals(buildId);
		} catch (Exception e) {
			Log.log(e);
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (Exception e) {
				}
			}

			if (writer != null) {
				try {
					writer.close();
				} catch (Exception e) {
				}
			}

			if (socket != null) {
				try {
					socket.close();
				} catch (Exception e) {
				}
			}
		}
		return false;
	}

	private boolean deleteDirectory(File path) {
		if (path.exists()) {
			File[] files = path.listFiles();
			for (int i = 0; i < files.length; i++) {
				if (files[i].isDirectory()) {
					deleteDirectory(files[i]);
				} else {
					files[i].delete();
				}
			}
		}
		return (path.delete());
	}

	public void run() {
		if (!this.update()) {
			Log.log(new Exception(), "run");

			//SplashPanel splash = new SplashPanel();
			CaruruUI caruruUI = CaruruUI.getInstance();
			caruruUI.setVisible(true);

			try {
				ApplicationInfo.setApplicationNumber(-1);
				int selectedApplicationNumber = caruruUI.select();
			//	splash.setVisible(true);

				ApplicationInfo[] applicationInfo =
					ApplicationInfo.getApplicationInfo();
				ApplicationInfo info =
					applicationInfo[selectedApplicationNumber];

			//	splash.setMessage(
			//		"\"" + info.getName() + "\" is getting ready to start.");

				this.update(info, false, null);
			} catch (Exception e) {
			} finally {
				caruruUI.dispose();
			//	splash.dispose();
			}
		}
	}

	private String getExceptionMessage(Exception e) {
		StackTraceElement[] stackTrace = e.getStackTrace();
		StringBuffer buffer = new StringBuffer();
		for (int i = 0; i < stackTrace.length; i++) {
			buffer.append(stackTrace[i] + "\r\n");
		}
		return buffer.toString();
	}

	private void makeRunFile(File f, String command) {
		BufferedWriter writer = null;
		try {
			writer =
				new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream(f)));
			writer.write(command);
			writer.flush();
		} catch (Exception e) {
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (Exception e) {
				}
			}
		}
	}

	private String getOldCommand(File f) throws Exception {
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(f));
			String line = null;
			StringBuffer buffer = new StringBuffer();
			while ((line = reader.readLine()) != null) {
				buffer.append(line + "\r\n");
			}
			return buffer.toString();
		} catch (Exception e) {
			throw e;
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private void getCurrentFileList(File f, String currentDir, Vector fileList)
		throws Exception {
		if (f.isDirectory()) {
			File[] files = f.listFiles();
			if (currentDir == null) {
				currentDir = "";
			} else {
				fileList.add(currentDir + f.getName());
				currentDir += f.getName() + "/";
			}

			for (int i = 0; i < files.length; i++) {
				getCurrentFileList(files[i], currentDir, fileList);
			}
		} else {
			fileList.add(currentDir + f.getName());
		}
	}
}