package caruru.client;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import caruru.Log;

public class ApplicationInfo {
	public final static String CONFIG_FILE = "client.xml";
	private boolean defaultRunner;
	private String name;
	private String IP;
	private int port;
	private String installedDate;
	private String lastUpdatedDate;
	private String version;
	private String buildId;
	private static String selfUpdateServerIP;
	private static int selfUpdateServerPort;
	private static int applicationNumber = -1;

	public ApplicationInfo() {
		this.installedDate = "";
		this.lastUpdatedDate = "";
		this.version = "";
		this.buildId = "";
	}

	public ApplicationInfo(
		boolean defaultRunner,
		String name,
		String IP,
		int port,
		String installedDate,
		String lastUpdatedDate) {
		this.defaultRunner = defaultRunner;
		this.name = name;
		this.IP = IP;
		this.port = port;
		this.installedDate = installedDate;
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public boolean getDefaultRunner() {
		return defaultRunner;
	}

	public String getInstalledDate() {
		return installedDate;
	}

	public String getIP() {
		return IP;
	}

	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public String getName() {
		return name;
	}

	public int getPort() {
		return port;
	}

	public void setDefaultRunner(boolean defaultRunner) {
		this.defaultRunner = defaultRunner;
	}

	public void setInsatlledDate(String date) {
		installedDate = date;
	}

	public void setIP(String string) {
		IP = string;
	}

	public void setLastUpdatedDate(String date) {
		lastUpdatedDate = date;
	}

	public void setName(String string) {
		name = string;
	}

	public void setPort(int i) {
		port = i;
	}

	private static String getAttribute(String name, String value) {
		return "\t" + name + "=\"" + value + "\"\r\n";
	}

	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("name=" + this.getName() + "\r\n");
		buffer.append("ip=" + this.getIP() + "\r\n");
		buffer.append("port=" + String.valueOf(this.getPort()) + "\r\n");
		buffer.append("installedDate=" + this.getInstalledDate() + "\r\n");
		buffer.append("lastUpdatedDate=" + this.getLastUpdatedDate() + "\r\n");
		buffer.append("version=" + this.getVersion() + "\r\n");
		buffer.append("buildId=" + this.getBuildId() + "\r\n");
		return buffer.toString();
	}

	public void save() {
		try {
			String date =
				new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

			if (this.installedDate == null
				|| this.installedDate.trim().length() == 0) {
				this.installedDate = date;
			}

			if (this.lastUpdatedDate == null
				|| this.lastUpdatedDate.trim().length() == 0) {
				this.lastUpdatedDate = date;
			}

			ApplicationInfo[] infos = getApplicationInfo();
			for (int i = 0; i < infos.length; i++) {
				if (infos[i].getName().equals(this.getName())) {
					infos[i] = this;
					break;
				}
			}
			save(infos);
		} catch (Exception e) {
			Log.log(e);
		}

	}

	public static void save(ApplicationInfo[] info) throws Exception {
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(new File(CONFIG_FILE)));
			StringBuffer xml = new StringBuffer();
			xml.append("<?xml version=\"1.0\" encoding=\"euc-kr\"?>\r\n");
			xml.append("<config>\r\n");
			xml.append("<server\r\n");
			xml.append(getAttribute("ip", ApplicationInfo.selfUpdateServerIP));
			xml.append(
				getAttribute(
					"port",
					String.valueOf(ApplicationInfo.selfUpdateServerPort)));
			xml.append("/>\r\n");
			for (int i = 0; i < info.length; i++) {
				xml.append("<application\r\n");
				xml.append(getAttribute("name", info[i].getName()));
				xml.append(
					getAttribute(
						"defaultRunner",
						String.valueOf(info[i].getDefaultRunner())));
				xml.append(getAttribute("ip", info[i].getIP()));
				xml.append(
					getAttribute("port", String.valueOf(info[i].getPort())));
				xml.append(
					getAttribute("installedDate", info[i].getInstalledDate()));
				xml.append(
					getAttribute(
						"lastUpdatedDate",
						info[i].getLastUpdatedDate()));
				xml.append(getAttribute("version", info[i].getVersion()));
				xml.append(getAttribute("buildId", info[i].getBuildId()));
				xml.append("/>\r\n");
			}
			xml.append("</config>\r\n");
			writer.write(xml.toString());
			writer.flush();
		} catch (Exception e) {
			throw e;
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (Exception e) {
				}
			}
		}
	}

	public static ApplicationInfo[] getApplicationInfo() throws Exception {
		SAXReader saxReader = new SAXReader();
		Document document = saxReader.read(CONFIG_FILE);

		selfUpdateServerIP = document.valueOf("/config/server/@ip");
		selfUpdateServerPort =
			Integer.parseInt(document.valueOf("/config/server/@port"));

		List applicationList = document.selectNodes("/config/application");
		ApplicationInfo[] applicationInfo =
			new ApplicationInfo[applicationList.size()];
		for (int i = 0; i < applicationList.size(); i++) {
			Element element = (Element) applicationList.get(i);
			String defaultRunner = element.valueOf("@defaultRunner");
			String ip = element.valueOf("@ip");
			String port = element.valueOf("@port");
			String applicationName = element.valueOf("@name");
			String installedDate = element.valueOf("@installedDate");
			String lastUpdatedDate = element.valueOf("@lastUpdatedDate");
			String version = element.valueOf("@version");
			String buildId = element.valueOf("@buildId");

			applicationInfo[i] =
				new ApplicationInfo(
					"true".equals(defaultRunner),
					applicationName,
					ip,
					Integer.parseInt(port),
					installedDate,
					lastUpdatedDate);
			applicationInfo[i].setVersion(version);
			applicationInfo[i].setBuildId(buildId);
			if (applicationList.size() == 1) {
				applicationInfo[i].setDefaultRunner(true);
			}
		}
		return applicationInfo;
	}

	public String getBuildId() {
		return buildId;
	}

	public String getVersion() {
		return version;
	}

	public void setBuildId(String string) {
		buildId = string;
	}

	public void setVersion(String string) {
		version = string;
	}

	public static int getApplicationNumber() {
		return applicationNumber;
	}

	public static void setApplicationNumber(int i) {
		applicationNumber = i;
	}
}
