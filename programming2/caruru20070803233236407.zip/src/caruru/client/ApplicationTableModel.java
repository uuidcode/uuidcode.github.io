package caruru.client;

import java.util.Vector;

import javax.swing.table.DefaultTableModel;

public class ApplicationTableModel extends DefaultTableModel {
	private boolean isEditable = true;
	
	public ApplicationTableModel() {
		this.columnIdentifiers.add("Name");
		this.columnIdentifiers.add("Version");
		this.columnIdentifiers.add("BuildId");
		this.columnIdentifiers.add("Update Server IP");
		this.columnIdentifiers.add("Update Server Port");
		this.columnIdentifiers.add("Installed Date");
		this.columnIdentifiers.add("Last updated Date");
	}
	
	public void addRow(ApplicationInfo info) {
		Vector row = new Vector();
		row.add(info.getName());
		row.add(info.getVersion());
		row.add(info.getBuildId());
		row.add(info.getIP());
		row.add(new Integer(info.getPort()));
		row.add(info.getInstalledDate());
		row.add(info.getLastUpdatedDate());
		this.addRow(row);
	}
	
	public boolean isCellEditable(int row, int column) {
		return false;
	}
	
	public boolean isEditable() {
		return isEditable;
	}

	public void setEditable(boolean b) {
		isEditable = b;
	}

}
