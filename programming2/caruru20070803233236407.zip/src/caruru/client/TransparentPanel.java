package caruru.client;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.geom.CubicCurve2D;
import java.awt.geom.GeneralPath;
import java.awt.image.BufferedImage;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.Timer;

public class TransparentPanel extends JPanel {
	private RenderingHints hints;
	private int count;

	public TransparentPanel() {
		this.setOpaque(false);
		hints =
			new RenderingHints(
				RenderingHints.KEY_ALPHA_INTERPOLATION,
				RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
		hints.put(
			RenderingHints.KEY_ANTIALIASING,
			RenderingHints.VALUE_ANTIALIAS_ON);
		hints.put(
			RenderingHints.KEY_COLOR_RENDERING,
			RenderingHints.VALUE_COLOR_RENDER_QUALITY);
		hints.put(
			RenderingHints.KEY_INTERPOLATION,
			RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		hints.put(
			RenderingHints.KEY_RENDERING,
			RenderingHints.VALUE_RENDER_QUALITY);
	}

	private void drawCurve(
		Graphics2D g2,
		float y1,
		float y1_offset,
		float y2,
		float y2_offset,
		float cx1,
		float cx1_offset,
		float cy1,
		float cy1_offset,
		float cx2,
		float cx2_offset,
		float cy2,
		float cy2_offset,
		float thickness,
		float speed,
		boolean invert) {

		float width = getWidth();
		float height = getHeight();

		double offset = Math.sin(count / (speed * Math.PI));
		float start_x = 0.0f;
		float start_y = y1 + (float) (offset * y1_offset);
		float end_x = width;
		float end_y = y2 + (float) (offset * y2_offset);
		float ctrl1_x = (float) offset * cx1_offset + cx1;
		float ctrl1_y = cy1 + (float) (offset * cy1_offset);
		float ctrl2_x = (float) (offset * cx2_offset) + cx2;
		float ctrl2_y = (float) (offset * cy2_offset) + cy2;

		CubicCurve2D curve =
			new CubicCurve2D.Double(
				start_x,
				start_y,
				ctrl1_x,
				ctrl1_y,
				ctrl2_x,
				ctrl2_y,
				end_x,
				end_y);

		GeneralPath path = new GeneralPath(curve);
		path.lineTo(width, height);
		path.lineTo(0, height);
		path.closePath();

		Area thickCurve = new Area((Shape) path.clone());
		AffineTransform translation =
			AffineTransform.getTranslateInstance(0, thickness);
		path.transform(translation);
		thickCurve.subtract(new Area(path));

		Color start = new Color(255, 255, 255, 255);
		Color end = new Color(255, 255, 255, 50);

		Rectangle bounds = thickCurve.getBounds();
		GradientPaint painter =
			new GradientPaint(
				0,
				curve.getBounds().y,
				invert ? end : start,
				0,
				bounds.y + bounds.height,
				invert ? start : end);
		Paint oldPainter = g2.getPaint();
		g2.setPaint(painter);

		g2.fill(thickCurve);

		g2.setPaint(oldPainter);
	}

	protected void paintComponent(Graphics g) {
		count++;
		BufferedImage bufimg =
			new BufferedImage(
				this.getWidth(),
				this.getHeight(),
				BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2 = bufimg.createGraphics();
		g2.setColor(g.getColor());

		super.paintComponent(g2);

		int width = getWidth();
		int height = getHeight();

		Color gradientStart = new Color(182, 219, 136); //220, 255, 149);
		Color gradientEnd = new Color(158, 211, 102); //183, 234, 98);

		GradientPaint painter =
			new GradientPaint(0, 0, gradientStart, 0, height, gradientEnd);
		Paint oldPainter = g2.getPaint();
		g2.setPaint(painter);
		//g2.fill(g2.getClip());
		g2.fillRect(0, 0, width, height);

		gradientStart = new Color(183, 234, 98, 200);
		gradientEnd = new Color(220, 255, 149, 255);

		painter =
			new GradientPaint(0, 0, gradientEnd, 0, height / 2, gradientStart);
		g2.setPaint(painter);
		//g2.fill(g2.getClip());
		g2.fillRect(0, 0, width, height);

		painter =
			new GradientPaint(
				0,
				height / 2,
				gradientStart,
				0,
				height,
				gradientEnd);
		g2.setPaint(painter);
		g2.fillRect(0, 0, width, height);

		g2.setPaint(oldPainter);

		g2.translate(0, -30);
		drawCurve(
			g2,
			20.0f,
			-10.0f,
			20.0f,
			-10.0f,
			width / 2.0f - 40.0f,
			10.0f,
			0.0f,
			-5.0f,
			width / 2.0f + 40,
			1.0f,
			0.0f,
			5.0f,
			50.0f,
			5.0f,
			false);
		g2.translate(0, 30);

//		g2.translate(0, height - 60);
//		drawCurve(
//			g2,
//			30.0f,
//			-15.0f,
//			50.0f,
//			15.0f,
//			width / 2.0f - 40.0f,
//			1.0f,
//			15.0f,
//			-25.0f,
//			width / 2.0f,
//			1.0f / 2.0f,
//			0.0f,
//			25.0f,
//			15.0f,
//			6.0f,
//			false);
//		g2.translate(0, -height + 60);
//
//		drawCurve(
//			g2,
//			height - 35.0f,
//			-5.0f,
//			height - 50.0f,
//			10.0f,
//			width / 2.0f - 40.0f,
//			1.0f,
//			height - 35.0f,
//			-25.0f,
//			width / 2.0f,
//			1.0f / 2.0f,
//			height - 20.0f,
//			25.0f,
//			25.0f,
//			4.0f,
//			true);

		Graphics2D gx = (Graphics2D) g;

		gx.setComposite(
			AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.4f));
		gx.drawImage(bufimg, 0, 0, null);
	}

	public static void main(String[] args) {
		JFrame f = new JFrame();

		JPanel cp = new JPanel(new FlowLayout());
		cp.add(new JButton("OK"));
		cp.add(new JScrollPane(new JTree()));
		f.setContentPane(cp);
		final JPanel p = new TransparentPanel();
		p.setLayout(new FlowLayout());
		//p.add(new JButton("OK"));
		f.setGlassPane(p);
		p.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(400, 400);
		f.setVisible(true);

//		Timer animation = new Timer(100, new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				p.repaint();
//			}
//		});
//		animation.start();
	}
}
