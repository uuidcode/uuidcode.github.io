package caruru.client;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListCellRenderer;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

public class ApplicationPanel extends JPanel implements ListCellRenderer {
	protected ApplicationLabel appImgageLabel;
	protected JLabel[] descLabel = new JLabel[7];
	protected static Border noFocusBorder = new EmptyBorder(1, 1, 1, 1);
	
	public ApplicationPanel() {
		this.setLayout(new BorderLayout());
		this.appImgageLabel = new ApplicationLabel("");
		this.add(appImgageLabel, BorderLayout.WEST);

		JPanel descriptPanel = new JPanel(new GridLayout(descLabel.length, 1));
		descriptPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		for (int i = 0; i < descLabel.length; i++) {
			this.descLabel[i] = new JLabel();
			descriptPanel.add(this.descLabel[i]);
		}
		this.add(descriptPanel, BorderLayout.CENTER);
		this.setPreferredSize(new Dimension(300, 140));
	}

	private void setApplication(ApplicationInfo info) {
		boolean hasImage = false;
		hasImage = setImageFile(info, ".jpg");
		
		if (!hasImage) {
			hasImage = setImageFile(info, ".gif");
		}
		
		if (!hasImage) {
			hasImage = setImageFile(info, ".png");
		}
		
		if (!hasImage) {
			this.appImgageLabel.setImage("");
		}
		
		this.descLabel[0].setText("Name: " + info.getName());
		this.descLabel[1].setText("Version: " + info.getVersion());
		this.descLabel[2].setText("BuildId: " + info.getBuildId());
		this.descLabel[3].setText("Update server: " + info.getIP());
		this.descLabel[4].setText("Update server port: " + info.getPort());
		this.descLabel[5].setText("Installed date: " + info.getInstalledDate());
		this.descLabel[6].setText(
			"Last updated date: " + info.getLastUpdatedDate());
	}

	private boolean setImageFile(ApplicationInfo info, String suffix) {
		String fileName = info.getName() + "/" + info.getName() + suffix;
		File f = new File(fileName);
		if (f.exists()) {
			this.appImgageLabel.setImage(fileName);
			return true;
		}
		return false;
	}

	public Component getListCellRendererComponent(
		JList list,
		Object value,
		int index,
		boolean isSelected,
		boolean cellHasFocus) {
		if (value != null && value instanceof ApplicationInfo) {
			this.setApplication((ApplicationInfo) value);

			if (isSelected) {
				this.setForeground(list.getSelectionForeground());
				this.setBackground(list.getSelectionBackground());
			} else {
				this.setForeground(list.getForeground());
				this.setBackground(list.getBackground());
			}

			if (cellHasFocus) {
				this.setBorder(
					UIManager.getBorder("List.focusCellHighlightBorder"));
			} else {
				this.setBorder(noFocusBorder);
			}

			return this;
		}
		return this;
	}
}