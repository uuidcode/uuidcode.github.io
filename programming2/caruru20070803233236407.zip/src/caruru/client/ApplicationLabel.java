package caruru.client;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class ApplicationLabel extends JLabel {
	private String filename;
	private boolean imageFileExists = false;

	public ApplicationLabel(String filename) {
		this.filename = filename;
		this.exist();
		this.filename = filename;
		this.setPreferredSize(new Dimension(120, 120));
	}

	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		if (this.imageFileExists) {
			ImageIcon imageIcon = new ImageIcon(this.filename);
			Image image = imageIcon.getImage();
			g.drawImage(image, 10, 10, 100, 100, this);
		} else {
			g.drawString("No image", 30, 70);
		}
	}

	public void setImage(String fileName) {
		this.filename = fileName;
		this.exist();

	}

	private void exist() {
		File f = new File(filename);
		if (f.exists() && 
			(filename.toLowerCase().lastIndexOf(".jpg") > 0 ||
			filename.toLowerCase().lastIndexOf(".gif") > 0 ||
			filename.toLowerCase().lastIndexOf(".png") > 0)) {
			imageFileExists = true;
		} else {
			this.imageFileExists = false;
		}
	}
}