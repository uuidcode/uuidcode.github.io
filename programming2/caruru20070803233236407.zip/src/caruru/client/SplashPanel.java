package caruru.client;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JWindow;

public class SplashPanel extends JWindow {
	private JLabel initialingLabel;
	
	public SplashPanel() {
		JPanel content = (JPanel) getContentPane();
		content.setLayout(new BorderLayout());
		
		int width = 300;
		int height = 30;
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (screen.width - width) / 2;
		int y = (screen.height - height) / 2;
		setBounds(x, y, width, height);
		
		this.initialingLabel = new JLabel("");
		this.initialingLabel.setHorizontalAlignment(JLabel.CENTER);
		content.add(initialingLabel, BorderLayout.CENTER);
		content.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
	}

	public void setMessage(final String message) {
		new Thread() {
			public void run() {
				initialingLabel.setText(message);
			}
		}.start();
		
	}
}
