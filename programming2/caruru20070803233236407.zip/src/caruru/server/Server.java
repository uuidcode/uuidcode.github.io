package caruru.server;

import java.net.ServerSocket;
import java.net.Socket;

import org.dom4j.Document;
import org.dom4j.io.SAXReader;

import caruru.Log;

public class Server {
	private int port;
	public final static String CONFIG_FILE = "server.xml";
	
	public void run() {
		Document document = null;
		try {
			SAXReader reader = new SAXReader();
			document = reader.read(CONFIG_FILE);
		} catch (Exception e) {
			Log.log(e);
		}		
		
		ServerSocket serverSocket = null;
		try {
			serverSocket = new ServerSocket(Integer.parseInt(document.valueOf("/config/port")));
		} catch (Exception e) {
			Log.log(e);
			return;
		}
		
		Log.log(new Exception(), "start.");
		while (true) {
			Socket socket = null;
			try {
				socket = serverSocket.accept();
			} catch (Exception e) {
				Log.log(e, e.getMessage());
				return;
			}
			
			Thread thread = new ServerThread(socket);
			thread.start();
		}		
	}
}
