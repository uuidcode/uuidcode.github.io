package caruru.server;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.util.List;
import java.util.Vector;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;

import caruru.CheckSum;
import caruru.Log;

public class ServerThread extends Thread {
	private final static String BUILD_ID_FILE = "buildId";
	private final static String VERSION_FILE = "version";
	
	private Socket socket;
	private Document document;
	private Vector excludeFileVector;
	private Vector allowModifyFileVector;
	
	public ServerThread(Socket socket) {
		this.socket = socket;
		
		try {
			SAXReader reader = new SAXReader();
			document = reader.read(Server.CONFIG_FILE);
		} catch (Exception e) {
			Log.log(e);
		}		
	}
	
	private String getStringFromFile(File f) {
		BufferedReader reader = null;
		
		try {
			reader =
				new BufferedReader(
					new InputStreamReader(
						new FileInputStream(f)));
			String line = null;
			return reader.readLine();
		} catch (Exception e) {
			Log.log(e);
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (Exception e) {
				}
			}
		}
		
		return null;
	}
			
	public void sendFile(OutputStream out, File f) throws Exception {
		FileInputStream fis = null;		
					
		try {
			long size = f.length();
			out.write((String.valueOf(size) + "\r\n").getBytes());
			out.flush();
			Log.log(new Exception(), f.getAbsolutePath() + "[" + String.valueOf(size) + "]");
			fis = new FileInputStream(f);
			byte[] buffer = new byte[1024];
			int readSize = -1;
			while((readSize = fis.read(buffer)) > 0) {
				out.write(buffer, 0, readSize);
				out.flush();
			}
			Log.log(new Exception(), "send complete.");
		} catch (Exception e) {
			throw e;
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}		 
	}
	
	public void run() {
		Log.log(new Exception(), "====================================");
		OutputStream out = null;
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
			out = this.socket.getOutputStream();
			Log.log(new Exception(), socket.getRemoteSocketAddress().toString() + " run.");
			String applicationName = reader.readLine();
			Log.log(new Exception(), applicationName);
			String deployDir = document.valueOf("/config/deployDir");
			Node node = document.selectSingleNode("/config/applications/application[@name='" + applicationName + "']");
			boolean applicationStrutureisOK = false;
			File applicationDeployDir = null;
			String command = null;
			Element applicationElement = null;
			if (node != null && node.getNodeType() == Node.ELEMENT_NODE) {
				applicationElement = (Element) node;
				command = applicationElement.valueOf("@command");
				Log.log(new Exception(), "applicationName", applicationName);
				Log.log(new Exception(), "command", command);
				
				applicationDeployDir = new File(deployDir + File.separatorChar + applicationName);
				Log.log(new Exception(), "applicationDeployDir", applicationDeployDir.getAbsolutePath());
				if (applicationDeployDir.exists()) {
					applicationStrutureisOK = true;
				} else {
					Log.log(new Exception(), applicationDeployDir.getAbsolutePath() + " does not exist.");
				}
			}
			
			if (!applicationStrutureisOK) {
				return;
			} 
			
			Log.log(new Exception(), "loaded config.");
			
			List excludeFiles = applicationElement.selectNodes("excludeFiles/file");
			this.excludeFileVector = new Vector();
			for (int i = 0; excludeFiles != null && i < excludeFiles.size(); i++) {
				this.excludeFileVector.add(((Element) excludeFiles.get(i)).valueOf("@name"));
			}
			Log.log(new Exception(), this.excludeFileVector.toString());
						
			List allowModifyFiles = applicationElement.selectNodes("allowModifyFiles/file");
			this.allowModifyFileVector = new Vector();
			for (int i = 0; allowModifyFiles != null && i < allowModifyFiles.size(); i++) {
				this.allowModifyFileVector.add(((Element) allowModifyFiles.get(i)).valueOf("@name"));
			}
			Log.log(new Exception(), this.allowModifyFileVector.toString());
			
			String integrityDir = applicationElement.valueOf("integrityDir");
			String applicationStructureXML = this.getApplicationStrutureXML(applicationDeployDir, command, integrityDir);
			Log.log(new Exception(), applicationStructureXML);
			out.write(applicationStructureXML.getBytes());
			out.flush();
			out.write(".\r\n".getBytes());
			out.flush();
			
			String fileName = null;
			while ((fileName = reader.readLine()) != null) {
				if (".".equals(fileName)) {
					break;
				}
				Log.log(new Exception(), fileName);
				sendFile(out, new File(applicationDeployDir, fileName));
			}	
			Log.log(new Exception(), "end.");
		} catch (Exception e) {
			Log.log(e);
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (Exception e) {
				}
			}
			
			if (reader != null) {
				try {
					reader.close();
				} catch (Exception e) {
				}
			}
			
			if (socket != null) {
				try {
					socket.close();
				} catch (Exception e) {
				}
			}			
		}
	}
	
	public String getDirStructureXML(File f, String currentDir) throws Exception {
		if (f.isDirectory()) {
			StringBuffer xml = new StringBuffer();			
			File[] files = f.listFiles();
			if (currentDir == null) {
				currentDir = "";
			} else {
				xml.append("<dir name=\"");
				xml.append(currentDir + f.getName());
				xml.append("\"/>\r\n");
				currentDir += f.getName() + "/";
			}			
			
			for (int i = 0; i < files.length; i++) {
				xml.append(getDirStructureXML(files[i], currentDir));
			}
			return xml.toString();
		} else {
			StringBuffer xml = new StringBuffer();
			if (!this.excludeFileVector.contains(f.getName())) {
				xml.append("<file");
				xml.append(" name=\"" +  currentDir + f.getName() + "\"");
				xml.append(" checksum=\"" + CheckSum.getChecksumValue(f) + "\"");
				if (this.allowModifyFileVector.contains(f.getName())) {
					xml.append(" allowModify=\"true\"");
				}
				xml.append("/>\r\n");
			}
			return xml.toString();
		}
	}
	
	public String getApplicationStrutureXML(File f, String command, String integrityDir) throws Exception {
		StringBuffer xml = new StringBuffer();
		xml.append("<?xml version=\"1.0\" encoding=\"euc-kr\"?>\r\n");
		xml.append("<config>\r\n");
		xml.append("<version>" + this.getStringFromFile(new File(f, VERSION_FILE)) + "</version>\r\n");
		xml.append("<buildId>" + this.getStringFromFile(new File(f, BUILD_ID_FILE)) + "</buildId>\r\n");
		xml.append("<command>" + command + "</command>\r\n");
		if (integrityDir != null && integrityDir.trim().length() != 0) {
			xml.append("<integrityDir>" + integrityDir + "</integrityDir>\r\n");
		}
		xml.append("<files>\r\n");
		xml.append(this.getDirStructureXML(f, null));
		xml.append("</files>\r\n");
		xml.append("</config>\r\n");
		return xml.toString();
	}
}
