import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MakeVersionAndBuildNo {
	private final static String VERSION = "1.0";
	private final static String VERSION_FILE = "version";
	private final static String BUILD_ID_FILE = "buildId";
	private final static String BUILD_FILE = "build";
	
	private int getBuildNo() {
		BufferedReader reader = null;
		BufferedWriter writer = null;
		int buildNo = 1;
		
		try {
			reader =
				new BufferedReader(
					new InputStreamReader(
						new FileInputStream(new File(BUILD_FILE))));
			String line = reader.readLine();
			buildNo = Integer.parseInt(line);
		} catch (Exception e) {
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (Exception e) {
				}
			}
		}

		try {
			writer =
				new BufferedWriter(
					new OutputStreamWriter(
						new FileOutputStream(new File(BUILD_FILE))));
			writer.write(String.valueOf(buildNo + 1) + "\r\n");
			writer.flush();
		} catch (Exception e) {
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (Exception e) {
				}
			}
		}
		
		return buildNo;
	}

	public void make() {
		BufferedWriter writer = null;

		try {
			writer =
				new BufferedWriter(
					new OutputStreamWriter(
						new FileOutputStream(new File(VERSION_FILE))));
			writer.write(VERSION);
			writer.flush();
		} catch (Exception e) {
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (Exception e) {
				}
			}
		}

		try {
			writer =
				new BufferedWriter(
					new OutputStreamWriter(
						new FileOutputStream(new File(BUILD_ID_FILE))));
			writer.write(
				new SimpleDateFormat("yyyyMMddHHmmss").format(new Date())
					+ this.getBuildNo() + "\r\n");
			writer.flush();
		} catch (Exception e) {
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (Exception e) {
				}
			}
		}
	}
	public static void main(String[] args) {
		new MakeVersionAndBuildNo().make();
	}
}
