import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Vector;

public class BuildLog {
	private final static String BUILD_LOG_FILE = "build.log";

	public void log(String buildId, String log) {
		File f = new File(BUILD_LOG_FILE);
		Vector content = new Vector();
		BufferedReader reader = null;

		try {
			reader =
				new BufferedReader(
					new InputStreamReader(new FileInputStream(f)));
			String line = null;
			while ((line = reader.readLine()) != null) {
				content.add(line + "\r\n");
			}
		} catch (Exception e) {

		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (Exception e) {

				}
			}
		}

		BufferedWriter writer = null;
		try {
			writer =
				new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream(f)));
			writer.write(buildId + "\r\n");
			writer.write("\t" + log + "\r\n\r\n");
			for (int i = 0; i < content.size(); i++) {
				writer.write(content.get(i).toString());
			}
		} catch (Exception e) {
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (Exception e) {

				}
			}
		}
	}
	
	public static void main(String[] args) {
		if (args.length == 2) {
			String buildId = args[0];
			String log = args[1];
			log = log.trim();
			if (log.length() != 0) {
				new BuildLog().log(args[0], args[1]);
			}	
		}
	}
}
