package swingX.util;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

public class UIUtilities {
	public static Frame getFrame(Container container) {
		while (true) {
			if (container instanceof Frame) {
				return (Frame) container;
			}
			container = container.getParent();
			if (container == null) {
				break;
			}
		}

		return null;
	}

	public static void fixColumnSize(final JTable table) {
		new Thread() {
			public void run() {
				TableColumnModel model = table.getColumnModel();
				TableModel tableModel = table.getModel();
				int rowCount = tableModel.getRowCount();
				int columnCount = tableModel.getColumnCount();

				Graphics g = table.getGraphics();
				while (g == null) {
					g = table.getGraphics();
					try {
						Thread.sleep(1000);
					} catch (Exception e) {
					}
				}

				for (int i = 0; i < columnCount; i++) {
					int maxWidth = 40;
					FontMetrics metrics = g.getFontMetrics();
					int width =
						metrics.stringWidth(
							table
								.getColumnModel()
								.getColumn(i)
								.getIdentifier()
								.toString());
					if (width > maxWidth) {
						maxWidth = width;
					}

					for (int j = 0; j < rowCount; j++) {
						Object valueObject = tableModel.getValueAt(j, i);
						if (valueObject != null) {
							String value = valueObject.toString();
							width = metrics.stringWidth(value);
							if (width > maxWidth) {
								maxWidth = width;
							}
						}
					}

					model.getColumn(i).setPreferredWidth(maxWidth + 20);
				}
			}
		}
		.start();
	}

	public static void showExceptionDialog(Container owner, Exception ex) {
		StackTraceElement[] ste = ex.getStackTrace();
		JTextArea textArea = new JTextArea();
		for (int i = 0; i < ste.length; i++) {
			textArea.append(ste[i] + "\n");
		}
		textArea.setEditable(false);

		JPanel p = new JPanel(new BorderLayout());
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setPreferredSize(new Dimension(600, 300));
		p.add(scrollPane, BorderLayout.CENTER);
		JLabel errorMessageLabel = new JLabel(ex.getMessage());
		errorMessageLabel.setBorder(
			BorderFactory.createEmptyBorder(5, 5, 5, 5));
		p.add(errorMessageLabel, BorderLayout.NORTH);

		JOptionPane.showMessageDialog(
			UIUtilities.getFrame(owner),
			p,
			"Error",
			JOptionPane.ERROR_MESSAGE);
	}

	public static JPanel compact(JComponent com) {
		JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT));
		p.add(com);
		return p;
	}

	public static JPanel createFieldPanel(JTextField textField, String unit) {
		JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		panel.add(textField);
		panel.add(new JLabel(unit));
		return panel;
	}

	public static void setTitleBorder(JComponent com, String title) {
		com.setBorder(
			BorderFactory.createTitledBorder(
				BorderFactory.createEtchedBorder(),
				title));
	}
}
