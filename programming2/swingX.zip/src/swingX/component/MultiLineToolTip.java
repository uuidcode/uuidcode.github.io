package swingX.component;

import javax.swing.JComponent;
import javax.swing.JToolTip;

public class MultiLineToolTip extends JToolTip {
	private static final String uiClassID = "ToolTipUI";
	private String tipText;
	private  JComponent component;
	protected int columns = 0;
	protected int fixedwidth = 0;
		
	public MultiLineToolTip() {
		updateUI();
	}

	public void updateUI() {
		setUI(MultiLineToolTipUI.createUI(this));
	}

	public void setColumns(int columns) {
		this.columns = columns;
		this.fixedwidth = 0;
	}

	public int getColumns() {
		return columns;
	}

	public void setFixedWidth(int width) {
		this.fixedwidth = width;
		this.columns = 0;
	}

	public int getFixedWidth() {
		return fixedwidth;
	}
}
