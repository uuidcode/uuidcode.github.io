package swingX.messageObject;
public interface MessageListener {
	public void listen(Message message);	
}
