package swingX.messageObject;

public interface Message {
}