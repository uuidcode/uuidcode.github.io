package swingX.messageObject.test;

import javax.swing.JFrame;

import swingX.messageObject.LogMessage;
import swingX.messageObject.LogPanel;
import swingX.messageObject.MessageQueue;

public class Test {
	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setContentPane(new LogPanel());
		f.setSize(400, 400);
		f.setVisible(true);
		MessageQueue.getInstance().sendMessage(new LogMessage("Hello, World!"));
	}
}
