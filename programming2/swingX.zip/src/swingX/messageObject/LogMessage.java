package swingX.messageObject;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LogMessage implements Message {
	private static final String NEWLINE = "\n\n";
	private static final String DATE_FORMAT = "yyyy/MM/dd hh:mm:ss";
	private Object message;
	private String title;
	private Date date;
	
	public LogMessage(Object message) {
		this.date = new Date();
		this.message = message;
	}
	
	public LogMessage(Object message, String title) {
		this.date = new Date();
		this.message = message;
		this.title = title;
	}
	
	public String toString() {
		if (message instanceof String) {
			return new SimpleDateFormat(DATE_FORMAT).format(this.date) + " " + message;
		} else if (message instanceof Exception) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			((Exception) message).printStackTrace(pw);
			String messageText = sw.toString();
			if (this.title != null) {
				messageText = this.title.toString() + NEWLINE + messageText;	
			}
			return new SimpleDateFormat(DATE_FORMAT).format(this.date) + " " + messageText;
		} else {
			return new SimpleDateFormat(DATE_FORMAT).format(this.date) + " " + message.toString();
		}
	}

	public Object getMessage() {
		return message;
	}

	public String getDescription() {
		return message.toString();
	}
	
	public Object getTitle() {
		return title;
	}
}
