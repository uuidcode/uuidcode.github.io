package swingX.messageObject;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import swingX.util.UIUtilities;

public class LogPanel extends JPanel implements MessageListener {
	private JScrollPane scrollPane;
	private JTextArea textarea;

	public LogPanel() {
		this.setLayout(new BorderLayout());
		this.textarea = new JTextArea();
		this.textarea.setEditable(false);
		this.scrollPane = new JScrollPane(this.textarea);
		this.add(scrollPane, BorderLayout.CENTER);
		JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		JButton removeButton = new JButton("Remove all log");
		removeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textarea.setText("");
			}
		});
		controlPanel.add(removeButton);
		this.add(controlPanel, BorderLayout.NORTH);
		MessageQueue.getInstance().addListener(this);
		this.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
	}

	public synchronized void listen(final Message message) {
		if (message != null && message instanceof LogMessage) {
			final LogMessage consoleMessage = (LogMessage) message;
			final Object object = consoleMessage.getMessage();

			textarea.append(message + "\n");
			scrollPane.getVerticalScrollBar().setValue(
				scrollPane.getVerticalScrollBar().getMaximum());
			scrollToEnd();

			new Thread() {
				public void run() {
					JTextArea textArea = new JTextArea(consoleMessage.toString());
					textArea.setEditable(false);
					JScrollPane messageScrollPaen = new JScrollPane(textArea);
					messageScrollPaen.setPreferredSize(new Dimension(600, 300));
					if (object != null && object instanceof Exception) {
						JOptionPane.showMessageDialog(
							UIUtilities.getFrame(LogPanel.this),
							messageScrollPaen,
							"Error",
							JOptionPane.ERROR_MESSAGE);
					}
				}
			}.start();
		}
	}

	private void scrollToEnd() {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				if (isAdjusting()) {
					return;
				}
				int height = textarea.getHeight();
				textarea.scrollRectToVisible(
					new Rectangle(0, height - 1, textarea.getWidth(), height));
			}
		});
	}

	private boolean isAdjusting() {
		JScrollBar scrollBar = this.scrollPane.getVerticalScrollBar();
		if (scrollBar != null && scrollBar.getValueIsAdjusting()) {
			return true;
		}
		return false;
	}

	public String toString() {
		return this.getClass().getName();
	}
}
