package swingX.metaObject;

import javax.swing.table.DefaultTableModel;

public class PropertyTableModel extends DefaultTableModel {
	public PropertyTableModel() {
		this.addColumn("Name");
		this.addColumn("Value");
	}

	public boolean isCellEditable(int row, int column) {
		return false;
	}

	public void addRow(String name, String value) {
		this.addRow(new Object[] { name, value });
	}

	public void setNewProperty(MetaField field) {
		int rowIndex = getColumnIndex(field.displayName);
		if (rowIndex < 0) {
			return;
		}
		this.setValueAt(field.getValue(), rowIndex, 1);
	}
	
	public void addValue(String rowName, int value) {
		int rowIndex = getColumnIndex(rowName);
		if (rowIndex < 0) {
			return;
		}
		
		try {
			int currentValue =
				Integer.parseInt(this.getValueAt(rowIndex, 1).toString())
					+ value;
			this.setValueAt(String.valueOf(currentValue), rowIndex, 1);
		} catch (Exception e) {
		}
	}

	private int getColumnIndex(String rowName) {
		int rowCount = this.getRowCount();
		int rowIndex = -1;
		for (int i = 0; i < rowCount; i++) {
			if (this.getValueAt(i, 0).equals(rowName)) {
				rowIndex = i;
				break;
			}
		}
		return rowIndex;
	}
}
