package swingX.metaObject;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Dimension;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;

public class MetaObjectFormPanel extends MetaObjectPanel {
	private String name;
	private MetaObject object;
		
	public MetaObjectFormPanel(String name, MetaObject object) {
		this(name, object, false);
	}

	public MetaObjectFormPanel(
		String name,
		MetaObject object,
		boolean isPlain) {
			
		this.object = object;
		this.name = name;

		String keyValue = object.getKeyField().getValue();
		boolean isNew = false;
		if (keyValue == null || keyValue.trim().length() == 0) {
			isNew = true;
			keyValue = String.valueOf(System.currentTimeMillis());
			object.getKeyField().setValue(keyValue);
		}

		try {
			MetaField[] fields = XMLObject.getField(object);
			int rowCount = 0;
			for (int i = 0; i < fields.length; i++) {
				if (fields[i].visibleInForm) {
					rowCount++;
				}
			}

			JPanel panel = new JPanel(new GridLayout2(rowCount, 2));

			int height = rowCount * 30;
			int width = 0;

			for (int i = 0; i < fields.length; i++) {
				if (fields[i].visibleInForm) {
					panel.add(new JLabel(fields[i].displayName));
					JPanel fieldPanel =
						new JPanel(new FlowLayout(FlowLayout.LEFT));

					if (fields[i].type == MetaField.IMAGE) {
						File imageFile = new File(fields[i].getValue());
						if (imageFile.exists()) {
							fieldPanel.add(new ImageLabel(imageFile.getName()));
							height += 90;
						}
					} else if (fields[i].type == MetaField.TEXTAREA) {
						height += 90;
					}

					
					if (fields[i].type == MetaField.TEXTAREA) {
						final CardLayout cardLayout = new CardLayout();
						final JPanel p = new JPanel(cardLayout);
						JLabel label =
							new JLabel(
								"<html><pre>"
									+ fields[i].getValue()
									+ "</pre></html>");
						label.addMouseListener(new MouseListener() {
							public void mouseClicked(MouseEvent e) {
								if (e.getClickCount() == 2) {
									cardLayout.show(p, "textarea");
								}
							}

							public void mouseEntered(MouseEvent e) {
							}

							public void mouseExited(MouseEvent e) {
							}

							public void mousePressed(MouseEvent e) {
							}

							public void mouseReleased(MouseEvent e) {
							}
						});

						p.add(label, "label");
						p.add(
							new JScrollPane(fields[i].displayComponent),
							"textarea");

						if (isNew) {
							cardLayout.show(p, "textarea");
						} else {
							cardLayout.show(p, "label");
						}

						fieldPanel.add(p);
					} else {
						fieldPanel.add(fields[i].displayComponent);
					}
					fieldPanel.add(
						new JLabel(
							fields[i].suffix == null ? "" : fields[i].suffix));

					panel.add(fieldPanel);

					int currentWidth =
						fields[i].size * 20
							+ fields[i].displayName.length() * 10;
					if (currentWidth > width) {
						width = currentWidth;
					}
				}
			}

			panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

			this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
			if (!isPlain) {
				JLabel titleLabel =
					new JLabel(object.getFormDescription(), JLabel.LEFT);
				titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
				titleLabel.setBorder(
					BorderFactory.createEmptyBorder(5, 5, 5, 5));
				this.add(titleLabel);
				JSeparator separator = new JSeparator();
				separator.setAlignmentX(Component.LEFT_ALIGNMENT);
				this.add(separator);
			}

			JPanel contentWrapPanel = new JPanel(new BorderLayout());
			JPanel contentPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
			contentPanel.add(panel);

			if (!isPlain) {
				JScrollPane contentScrollPane = new JScrollPane(contentPanel);
				contentWrapPanel.add(contentScrollPane, BorderLayout.CENTER);
				contentWrapPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
				this.add(contentWrapPanel);
			} else {
				this.add(contentPanel);
			}

			if (!isPlain) {
				this.setPreferredSize(new Dimension(600, 400));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String toString() {
		return this.name;
	}

	public void save() {
		XMLObject.save(this.object);
	}	
}