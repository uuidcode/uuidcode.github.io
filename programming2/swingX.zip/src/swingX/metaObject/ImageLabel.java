package swingX.metaObject;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class ImageLabel extends JLabel {
	private String filename;
	private boolean imageFileExists = false;

	public ImageLabel(String filename) {
		this.filename = filename;
		this.setPreferredSize(new Dimension(120, 120));
	}

	protected void paintComponent(Graphics g) {
		super.paintComponent(g);

		ImageIcon imageIcon = new ImageIcon(this.filename);
		int width = imageIcon.getIconHeight();
		int height = imageIcon.getIconHeight();
		int max = 100;
		Image image = imageIcon.getImage();

		if (width <= max && height > max) {
			width = (int) ((float) max * (float) width / (float) height);
			height = max;
		} else if (width > max && height <= max) {
			height = (int) ((float) max * (float) height / (float) width);
			width = max;
		} else if (width > max && height > max) {
			if (width >= height) {
				height = (int) ((float) max * (float) height / (float) width);
				width = max;
			} else {
				width = (int) ((float) max * (float) width / (float) height);
				height = max;
			}
		}
		g.drawImage(
			image,
			10 + (max - width) / 2,
			10 + (max - height) / 2,
			width,
			height,
			this);

	}

	public void setImage(String fileName) {
		this.filename = fileName;
	}
}