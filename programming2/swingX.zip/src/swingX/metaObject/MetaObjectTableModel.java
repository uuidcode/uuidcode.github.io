package swingX.metaObject;

import java.util.Vector;

import javax.swing.table.DefaultTableModel;

public class MetaObjectTableModel extends DefaultTableModel {
	private MetaObject[] metaObjects;
	private MetaObject object;

	public MetaObjectTableModel(MetaObject object) {
		super();
		this.object = object;
		try {
			Vector columns = new Vector();
			MetaField[] metaFieldsForColumnName = XMLObject.getField(this.object);
			for (int i = 0; i < metaFieldsForColumnName.length; i++) {
				if (metaFieldsForColumnName[i].visibleInList) {
					this.addColumn(metaFieldsForColumnName[i].displayName);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}

	public void setDataVector(MetaObject[] metaObjects) {
		try {
			Vector dataVector = new Vector();
			for (int i = 0; i < metaObjects.length; i++) {
				MetaField[] fields = XMLObject.getField(metaObjects[i]);
				Vector row = new Vector();
				for (int j = 0; j < fields.length; j++) {
					if (fields[j].visibleInList) {
						row.add(fields[j].getValue());
					}
				}
				dataVector.add(row);
			}
			this.setDataVector(dataVector, this.columnIdentifiers);
		} catch (Exception e) {

		}
	}
}
