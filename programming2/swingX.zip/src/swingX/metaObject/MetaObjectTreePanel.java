package swingX.metaObject;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

public class MetaObjectTreePanel extends JPanel {
	private JTree tree;
	private JPanel contentPanel;
	private JPanel menuPanel;
	private MetaObjectPanel metaObjectPanel;
	private JButton saveButton;

	public MetaObjectTreePanel(DefaultMutableTreeNode rootNode) {
		setupUIManager(
			"Tree.collapsedIcon",
			"tree_folder_collapsed.gif");
		setupUIManager(
			"Tree.expandedIcon",
			"tree_folder_expanded.gif");

		this.setLayout(new BorderLayout());
		this.tree = new JTree(rootNode);
		this.tree.setRootVisible(false);
		this.tree.setShowsRootHandles(true);
		DefaultTreeCellRenderer renderer = new DefaultTreeCellRenderer();
		renderer.setLeafIcon(null);
		renderer.setClosedIcon(null);
		renderer.setOpenIcon(null);
		this.tree.setCellRenderer(renderer);
		this.tree.getSelectionModel().setSelectionMode(
			TreeSelectionModel.SINGLE_TREE_SELECTION);

		this.tree.setPreferredSize(new Dimension(200, 300));
		tree.addTreeSelectionListener(new TreeSelectionListener() {
			public void valueChanged(TreeSelectionEvent e) {
				DefaultMutableTreeNode node = getSelectedNode();

				if (node == null) {
					return;
				}

				if (node != null) {
					contentPanel.remove(menuPanel);
					menuPanel = new JPanel(new BorderLayout());
					metaObjectPanel = (MetaObjectPanel) node.getUserObject();
					if (metaObjectPanel instanceof MetaObjectListPanel) {
						saveButton.setEnabled(false);
					} else {
						saveButton.setEnabled(true);
					}
					menuPanel.add(metaObjectPanel, BorderLayout.CENTER);
					menuPanel.setBorder(
						BorderFactory.createEmptyBorder(5, 5, 5, 5));
					contentPanel.add(menuPanel, BorderLayout.CENTER);
					contentPanel.revalidate();
					contentPanel.repaint();
				}
			}
		});
		this.add(new JScrollPane(tree), BorderLayout.WEST);

		this.contentPanel = new JPanel(new BorderLayout());

		JPanel contentFooterPanel =
			new JPanel(new FlowLayout(FlowLayout.RIGHT));
		this.saveButton = new JButton("Save");
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (metaObjectPanel != null
					&& metaObjectPanel instanceof MetaObjectFormPanel) {
					((MetaObjectFormPanel) metaObjectPanel).save();
				}
			}
		});
		contentFooterPanel.add(saveButton);
		this.contentPanel.add(contentFooterPanel, BorderLayout.SOUTH);
		this.menuPanel = new JPanel();
		this.contentPanel.add(menuPanel, BorderLayout.CENTER);
		this.add(this.contentPanel, BorderLayout.CENTER);
		this.tree.setSelectionInterval(0, 0);
	}

	private void setupUIManager(String name, String fileName) {
		UIManager.put(name, getImageIcon(fileName));
	}

	private ImageIcon getImageIcon(String fileName) {
		return new ImageIcon(this.getClass().getResource(fileName));
	}

	public DefaultMutableTreeNode getSelectedNode() {
		TreePath path = tree.getSelectionPath();
		if (path == null) {
			return null;
		}

		Object object = path.getLastPathComponent();

		if (object != null && object instanceof DefaultMutableTreeNode) {
			return (DefaultMutableTreeNode) object;
		}

		return null;
	}
}
