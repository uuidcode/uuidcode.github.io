package swingX.metaObject;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;

import swingX.util.UIUtilities;

public class MetaObjectListPanel extends MetaObjectPanel {
	public final static int TABLE_VIEW = 0;
	public final static int LIST_VIEW = 1;

	public final static int SUBCOMPONENT_LEFT_POSITION = 0;
	public final static int SUBCOMPONENT_RIGHT_POSITION = 1;

	private static final String SUCCESS_MESSAGE = "Success to ";

	private int type;
	private JTable table;
	private JList list;
	private MetaObject[] metaObjects;
	private Class metaObjectClass;
	private JPanel headerPanel = null;
	private Runnable dataBinding = null;
	private Runnable refreshing = null;
	private Validatable validatable;
	private AfterActionable afterActionable;
	private String title;
	private boolean isReloading;

	private JButton addButton;
	private JButton editButton;
	private JButton removeButton;

	private boolean addIsShow = true;
	private boolean editIsShow = true;
	private boolean removeIsShow = true;
	private boolean showControlButtons = false;

	public MetaObjectListPanel(
		String title,
		Class metaObjectClass,
		int type,
		boolean showControlButton) {
		super();
		this.title = title;
		this.metaObjectClass = metaObjectClass;
		this.type = type;
		this.showControlButtons = showControlButton;

		try {
			this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
			JLabel titleLabel =
				new JLabel(
					((MetaObject) metaObjectClass.newInstance())
						.getListDescription(),
					JLabel.LEFT);
			titleLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
			titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
			this.add(titleLabel);

			if (this.showControlButtons) {
				JSeparator separator = new JSeparator();
				separator.setAlignmentX(Component.LEFT_ALIGNMENT);
				this.add(separator);

				this.headerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
				this.headerPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
				this.makeButton();
				this.add(this.headerPanel);
			}

			JPanel viewPanel = new JPanel(new BorderLayout());
			if (this.type == TABLE_VIEW) {
				MetaObjectTableModel model =
					new MetaObjectTableModel(newInstance());
				this.table = new JTable(model);
				this.table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
				this.table.getTableHeader().setReorderingAllowed(false);
				viewPanel.add(new JScrollPane(this.table), BorderLayout.CENTER);
			} else if (this.type == LIST_VIEW) {
				this.list = new JList();
				this.list.setCellRenderer(
					new MetaObjectCellRender(metaObjectClass));
				//this.list.setLayoutOrientation(JList.HORIZONTAL_WRAP);
				//list.setVisibleRowCount(1);
				viewPanel.add(new JScrollPane(this.list), BorderLayout.CENTER);
			}

			viewPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
			this.add(viewPanel);

			this.reload();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void makeButton() {
		makeAddButton();
		makeEditButton();
		makeRemoveButton();
	}

	public MetaObject getSelectedMetaObject() {
		if (this.type == TABLE_VIEW) {
			if (this.table.getSelectedRow() < 0) {
				return null;
			}
			return this.metaObjects[this.table.getSelectedRow()];
		} else if (this.type == LIST_VIEW) {
			if (this.list.getSelectedIndex() < 0) {
				return null;
			}
			return this.metaObjects[this.list.getSelectedIndex()];
		}
		return null;
	}

	public void removeSelectedMetaObject(String text) {
		MetaObject metaObject = getSelectedMetaObject();
		if (metaObject != null) {
			waitReloding();
			if (validatable == null || validatable.isRemovable()) {
				XMLObject.remove(metaObject);
				successAction(null, text);

				if (afterActionable != null) {
					afterActionable.afterRemove();
				}
			}
		} else {
			if (validatable != null) {
				validatable.isRemovable();
			}
		}
	}

	public void removeAllMetaObject() {
		XMLObject.removeXMLFile(this.metaObjectClass);
		this.reload();
	}

	private void makeRemoveButton() {
		final JButton removeButton = new JButton("remove");
		removeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				removeSelectedMetaObject(
					SUCCESS_MESSAGE + removeButton.getText());
			}
		});
		headerPanel.add(removeButton);
		this.removeButton = removeButton;
		this.removeButton.setVisible(this.removeIsShow);
	}

	private void makeEditButton() {
		final JButton editButton = new JButton("edit");
		editButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MetaObject metaObject = getSelectedMetaObject();
				if (metaObject != null) {
					waitReloding();
					if (validatable == null || validatable.isEditalbe()) {
						MetaObjectFormDialog metaObjectFormDailog =
							new MetaObjectFormDialog(
								MetaObjectListPanel.this,
								metaObject,
								MetaObjectListPanel.this.title,
								false);
						successAction(
							metaObjectFormDailog,
							SUCCESS_MESSAGE + editButton.getText());

						if (afterActionable != null
							&& metaObjectFormDailog.getStat()
								== MetaObjectFormDialog.OK) {
							afterActionable.afterEdit();
						}
					}
				} else {
					if (validatable != null) {
						validatable.isRemovable();
					}
				}
			}
		});
		headerPanel.add(editButton);
		this.editButton = editButton;
		this.editButton.setVisible(this.editIsShow);
	}

	private void makeAddButton() {
		final JButton addButton = new JButton("add");
		addButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if (validatable == null || validatable.isAddable()) {
						MetaObject metaObject = newInstance();
						MetaObjectFormDialog metaObjectFormDailog =
							new MetaObjectFormDialog(
								MetaObjectListPanel.this,
								metaObject,
								MetaObjectListPanel.this.title,
								false);

						successAction(
							metaObjectFormDailog,
							SUCCESS_MESSAGE + addButton.getText());

						if (afterActionable != null
							&& metaObjectFormDailog.getStat()
								== MetaObjectFormDialog.OK) {
							afterActionable.afterAdd();
						}
					}
				} catch (Exception ex) {
				}
			}
		});
		headerPanel.add(addButton);
		this.addButton = addButton;
		this.addButton.setVisible(this.addIsShow);
	}

	private MetaObject newInstance() throws Exception {
		return (MetaObject) Class
			.forName(this.metaObjectClass.getName())
			.newInstance();
	}

	private void waitReloding() {
		while (isReloading) {
			try {
				Thread.sleep(500);
			} catch (Exception e) {
			}
		}
	}

	public void successAction(MetaObjectFormDialog dialog, String message) {
		boolean isOK = false;
		if (dialog != null) {
			if (dialog.getStat() == MetaObjectFormDialog.OK) {
				isOK = true;
			}
		} else {
			isOK = true;
		}

		if (isOK) {
			reload();
			if (message != null) {
				JOptionPane.showMessageDialog(
					UIUtilities.getFrame(this),
					message,
					title,
					JOptionPane.INFORMATION_MESSAGE);
			}
		}
	}

	public void failAction(String message) {
		JOptionPane.showMessageDialog(
			UIUtilities.getFrame(this),
			message,
			title,
			JOptionPane.ERROR_MESSAGE);
	}

	public void reload() {
		new Thread() {
			public void run() {
				isReloading = true;
				try {
					metaObjects = XMLObject.getMetaObjects(metaObjectClass);

					Vector filteredMetaObjects = new Vector();
					for (int i = 0; i < metaObjects.length; i++) {
						if (metaObjects[i].isVisible()) {
							filteredMetaObjects.add(metaObjects[i]);
						}
					}

					metaObjects =
						(MetaObject[]) filteredMetaObjects.toArray(
							new MetaObject[0]);

					if (dataBinding != null) {
						dataBinding.run();
					}

					if (type == TABLE_VIEW) {
						(
							(MetaObjectTableModel) table
								.getModel())
								.setDataVector(
							metaObjects);
						UIUtilities.fixColumnSize(table);
					} else if (type == LIST_VIEW) {
						list.setListData(metaObjects);
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
				isReloading = false;
			}
		}
		.start();
	}

	public Runnable getDataBinding() {
		return dataBinding;
	}

	public void setDataBinding(Runnable binding) {
		dataBinding = binding;
	}
	public Class getMetaObjectClass() {
		return metaObjectClass;
	}

	public MetaObject[] getMetaObjects() {
		return metaObjects;
	}

	public void setMetaObjects(MetaObject[] objects) {
		metaObjects = objects;
	}

	private void setSubComponent(JComponent[] components) {
		for (int i = 0; i < components.length; i++) {
			this.headerPanel.add(components[i]);
		}
	}

	public void setSubComponent(
		JComponent[] components,
		int alignment,
		int addPosition) {
		JPanel panel = null;
		this.headerPanel.removeAll();
		this.headerPanel.setLayout(new FlowLayout(alignment));

		if (addPosition == SUBCOMPONENT_LEFT_POSITION) {
			setSubComponent(components);
		}

		this.makeButton();

		if (addPosition == SUBCOMPONENT_RIGHT_POSITION) {
			setSubComponent(components);
		}

		this.headerPanel.revalidate();
		this.headerPanel.repaint();
	}

	public Runnable getRefreshing() {
		return refreshing;
	}

	public void setRefreshing(Runnable runnable) {
		if (runnable != null) {
			refreshing = runnable;
			if (refreshing != null) {
				new Thread(refreshing).start();
			}
		}
	}

	public void setValidatable(Validatable validatable) {
		this.validatable = validatable;
	}

	public boolean isReloading() {
		return isReloading;
	}

	public void setAfterActionable(AfterActionable actionable) {
		afterActionable = actionable;
	}

	public JComponent getViewComponent() {
		if (this.type == TABLE_VIEW) {
			return this.table;
		} else if (this.type == LIST_VIEW) {
			return this.list;
		}
		return null;
	}

	public boolean isAddIsShow() {
		return addIsShow;
	}

	public boolean isEditIsShow() {
		return editIsShow;
	}

	public boolean isRemoveIsShow() {
		return removeIsShow;
	}

	public void setAddIsShow(boolean b) {
		this.addIsShow = b;
		this.addButton.setVisible(this.addIsShow);
	}

	public void setEditIsShow(boolean b) {
		this.editIsShow = b;
		this.editButton.setVisible(this.editIsShow);
	}

	public void setRemoveIsShow(boolean b) {
		this.removeIsShow = b;
		this.removeButton.setVisible(this.removeIsShow);
	}

	public String toString() {
		return this.title;
	}
}
