package swingX.metaObject;

import java.awt.BorderLayout;

import javax.swing.JScrollPane;

public class MetaObjectFormTablePanel extends MetaObjectPanel {
	private MetaObject object;

	public MetaObjectFormTablePanel(MetaObject object) {
		this.object = object;
		PropertyTable table = new PropertyTable(object); 
		this.setLayout(new BorderLayout());
		this.add(new JScrollPane(table), BorderLayout.CENTER);
	}

	public void save() {
		XMLObject.save(this.object);
	}
}