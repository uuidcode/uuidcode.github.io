package swingX.metaObject;

import javax.swing.JTable;

import swingX.util.UIUtilities;

public class PropertyTable extends JTable {
	private PropertyTableModel model;

	public PropertyTable(MetaObject metaObject) {
		super();
		this.model = new PropertyTableModel();
		this.setModel(this.model);
		this.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		this.getTableHeader().setReorderingAllowed(false);
		try {
			MetaField[] metaFieldsForColumnName =
				MetaField.getField(metaObject);
			for (int i = 0; i < metaFieldsForColumnName.length; i++) {
				if (metaFieldsForColumnName[i].visibleInList) {
					this.addProperty(
						metaFieldsForColumnName[i].displayName,
						metaFieldsForColumnName[i].getValue());
				}
			}
		} catch (Exception e) {
		}
	}

	public void addProperty(String name, Object value) {
		this.model.addRow(new Object[] { name, value });
		UIUtilities.fixColumnSize(this);
	}

	public void addValue(MetaField field, int value) {
		String rowName = field.displayName;
		int rowCount = this.getRowCount();
		int rowIndex = 0;
		for (int i = 0; i < rowCount; i++) {
			if (this.getValueAt(i, 0).equals(rowName)) {
				rowIndex = i;
				break;
			}
		}

		try {
			int currentValue =
				Integer.parseInt(this.getValueAt(rowIndex, 1).toString())
					+ value;
			this.setValueAt(String.valueOf(currentValue), rowIndex, 1);
		} catch (Exception e) {
		}
	}

	public void setValueAt(Object arg0, int arg1, int arg2) {
		super.setValueAt(arg0, arg1, arg2);
		UIUtilities.fixColumnSize(this);
	}

	public void setNewProperty(MetaField field, String newValue) {
		field.setValue(newValue);
		model.setNewProperty(field);
		UIUtilities.fixColumnSize(this);
	}
}
