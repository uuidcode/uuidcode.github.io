package swingX.metaObject;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;

import swingX.util.UIUtilities;

public class MetaObjectFormDialog extends JDialog {
	public final static int OK = 1;
	private int stat = 0;
	
	public MetaObjectFormDialog(
		Container owner,
		final MetaObject object,
		String title,
		boolean editing) {
		super(UIUtilities.getFrame(owner), title, true);

		JPanel mainPanel = new JPanel();
		BoxLayout boxLayout = new BoxLayout(mainPanel, BoxLayout.Y_AXIS);
		mainPanel.setLayout(boxLayout);
		
		MetaObjectFormPanel metaObjectFormPanel = new MetaObjectFormPanel(null, object);
		metaObjectFormPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		mainPanel.add(metaObjectFormPanel);
		
		JPanel bottomPanel = getBottomPanel(object);
		bottomPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		mainPanel.add(bottomPanel);
		
		mainPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		this.setContentPane(mainPanel);
		this.pack();
		
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (screen.width - this.getWidth()) / 2;
		int y = (screen.height - this.getHeight()) / 2;
		this.setLocation(x, y);
		this.setResizable(true);
		this.setVisible(true);
		
	}

	private JPanel getBottomPanel(final MetaObject object) {
		JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JButton okButton = new JButton("OK");
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stat = OK;
				XMLObject.save(object);
				dispose();
			}
		});
		bottomPanel.add(okButton);
		
		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		bottomPanel.add(cancelButton);
		return bottomPanel;
	}
	
	public int getStat() {
		return stat;
	}

}