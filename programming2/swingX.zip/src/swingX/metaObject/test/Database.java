package swingX.metaObject.test;

import swingX.metaObject.Inspector;
import swingX.metaObject.MetaField;
import swingX.metaObject.MetaObject;
import swingX.metaObject.XMLObject;

public class Database implements MetaObject {
	public MetaField id =
		new MetaField(
			"id",
			"Database Name",
			"",
			"",
			0,
			MetaField.LEFT,
			false,
			false,
			MetaField.TEXT,
			null);
	public MetaField enable =
		new MetaField(
			"enable",
			"Enable",
			"",
			"",
			10,
			MetaField.LEFT,
			true,
			true,
			MetaField.CHECKBOX,
			null);
	public MetaField name =
		new MetaField(
			"name",
			"Database Name",
			"",
			"",
			10,
			MetaField.LEFT,
			true,
			true,
			MetaField.TEXT,
			null);
	public MetaField displayImage =
		new MetaField(
			"displayImage",
			"Display Image",
			"",
			"",
			20,
			MetaField.LEFT,
			true,
			false,
			MetaField.IMAGE,
			null);
	public MetaField url =
		new MetaField(
			"url",
			"URL",
			"",
			"",
			30,
			MetaField.LEFT,
			true,
			true,
			MetaField.TEXT,
			null);
	public MetaField driver =
		new MetaField(
			"driver",
			"JDBC Driver",
			"",
			"",
			20,
			MetaField.LEFT,
			true,
			true,
			MetaField.TEXT,
			null);
	public MetaField user =
		new MetaField(
			"user",
			"User",
			"",
			"",
			10,
			MetaField.LEFT,
			true,
			true,
			MetaField.TEXT,
			null);
	public MetaField password =
		new MetaField(
			"password",
			"Password",
			"",
			"",
			10,
			MetaField.LEFT,
			true,
			false,
			MetaField.PASSWORD,
			null);
	public MetaField description =
		new MetaField(
			"description",
			"Description",
			"",
			"",
			30,
			MetaField.LEFT,
			true,
			false,
			MetaField.TEXTAREA,
			null);

	public MetaField file =
		new MetaField(
			"file",
			"File",
			"",
			"",
			30,
			MetaField.LEFT,
			true,
			true,
			MetaField.FILES_ONLY,
			null);

	public MetaField type =
		new MetaField(
			"type",
			"Type",
			"",
			"",
			0,
			MetaField.LEFT,
			true,
			true,
			MetaField.COMBOBOX,
			null);

	public Database() {
		type.setSelectableValue(new Object[] {"Java", "JQuery", "Eclipse"});
	}
	
	public MetaField getKeyField() {
		return id;
	}

	public MetaField getDisplayImageField() {
		return displayImage;
	}

	public boolean isVisible() {
		return true;
	}

	public static void main(String[] args) throws Exception {
		MetaObject[] objects = XMLObject.getMetaObjects(Database.class);
		System.out.println(Inspector.toString(objects));
	}

	public String getListDescription() {
		return this.getFormDescription();
	}

	public String getFormDescription() {
		return "<html>Database</html>";
	}
}