package swingX.metaObject.test;

import swingX.metaObject.MetaField;
import swingX.metaObject.MetaObject;

public class Preference implements MetaObject {
	public MetaField id =
		new MetaField(
			"id",
			"Id",
			"",
			"",
			0,
			MetaField.LEFT,
			false,
			false,
			MetaField.TEXT,
			null);
	public MetaField savePassword =
		new MetaField(
			"savePassword",
			"��й�ȣ ����",
			"",
			"false",
			10,
			MetaField.LEFT,
			true,
			true,
			MetaField.CHECKBOX,
			null);
	public MetaField password =
		new MetaField(
			"password",
			"��й�ȣ",
			"",
			"",
			10,
			MetaField.LEFT,
			true,
			false,
			MetaField.PASSWORD,
			null);

	public MetaField getKeyField() {
		return id;
	}

	public MetaField getDisplayImageField() {
		return null;
	}

	public boolean isVisible() {
		return true;
	}

	public static Preference newInstance() {
		try {
			Preference preference = (Preference) Preference.class.newInstance();
			preference.id.setValue(String.valueOf(System.currentTimeMillis()));
			return preference;
		} catch (Exception e) {
		}
		return null;
	}

	public String getListDescription() {
		return getFormDescription();
	}

	public String getFormDescription() {
		return "<html>Security - password<br>Hello, World</html>";
	}
}
