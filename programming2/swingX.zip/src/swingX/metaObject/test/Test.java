package swingX.metaObject.test;

import java.awt.*;
import javax.swing.*;
import javax.swing.tree.*;

import swingX.metaObject.MetaObjectFormPanel;
import swingX.metaObject.MetaObjectFormTablePanel;
import swingX.metaObject.MetaObjectListPanel;
import swingX.metaObject.MetaObjectTreePanel;
import swingX.metaObject.XMLObject;

public class Test {
	public static void setTitleBorder(JComponent com, String title) {
		com.setBorder(
			BorderFactory.createTitledBorder(
				BorderFactory.createEtchedBorder(),
				title));
	}

	public static void main(String[] args) throws Exception {
		JFrame f = new JFrame();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setExtendedState(JFrame.MAXIMIZED_BOTH);
		JPanel panel = new JPanel(new BorderLayout());
		JTabbedPane formPanel = new JTabbedPane();

		formPanel.addTab(
			"Form",
			new MetaObjectFormPanel("Test2", new Database(), true));
		formPanel.addTab(
			"Form with JScrollPane",
			new MetaObjectFormPanel("Test1", new Database()));
		formPanel.addTab(
			"Form with JTable",
			new MetaObjectFormTablePanel(new Database()));

		formPanel.addTab(
			"List with JList",
			new MetaObjectListPanel(
				"Test",
				Database.class,
				MetaObjectListPanel.LIST_VIEW,
				true));

		formPanel.addTab(
			"List with JTable",
			new MetaObjectListPanel(
				"Test",
				Database.class,
				MetaObjectListPanel.TABLE_VIEW,
				false));

		Database database = (Database) XMLObject.getMetaObject(Database.class);
		Server a = (Server) XMLObject.getMetaObject(Server.class);
		DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode();

		rootNode.add(
			new DefaultMutableTreeNode(
				new MetaObjectFormPanel("Databaase", database)));
		rootNode.add(
			new DefaultMutableTreeNode(
				new MetaObjectListPanel(
					"Server",
					Server.class,
					MetaObjectListPanel.TABLE_VIEW,
					true)));
		formPanel.addTab("List with JTree", new MetaObjectTreePanel(rootNode));

		panel.add(formPanel, BorderLayout.CENTER);
		f.setContentPane(panel);
		f.setVisible(true);
	}
}