package swingX.metaObject.test;

import swingX.metaObject.MetaField;
import swingX.metaObject.MetaObject;

public class Server implements MetaObject {
	public MetaField id = new MetaField("id", "id", "", "", 10, MetaField.LEFT, false, false, MetaField.TEXT, null);
	public MetaField server = new MetaField("server", "Server", "", "127.0.0.1", 10, MetaField.LEFT,true, true, MetaField.TEXT, null);
	public MetaField port = new MetaField("port", "Port", "", "1", 5, MetaField.LEFT,true, true, MetaField.TEXT, null);
	public MetaField file = new MetaField("file", "File", "", "2", 50, MetaField.LEFT, true, true, MetaField.FILES_ONLY, null);
	
	public MetaField getKeyField() {
		return id;
	}

	public MetaField getDisplayImageField() {
		return null;
	}

	public boolean isVisible() {
		return true;
	}

	public String getListDescription() {
		return "<html>Hello, World</html>";
	}
	
	public String getFormDescription() {
		return "<html>This is the way you left me</html";
	}
}
