package swingX.metaObject;

public interface MetaObject {
	public MetaField getKeyField();
	public MetaField getDisplayImageField();
	public boolean isVisible();
	public String getListDescription();
	public String getFormDescription();
}
