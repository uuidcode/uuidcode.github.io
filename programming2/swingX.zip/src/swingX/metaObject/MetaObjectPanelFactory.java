package swingX.metaObject;

public class MetaObjectPanelFactory {
	public static MetaObjectFormPanel createMetaObjectFormPanel(
		String name,
		MetaObject object) {
		return new MetaObjectFormPanel(name, object);
	}

	public static MetaObjectFormTablePanel createMetaObjectFormTablePanel(
		String name,
		MetaObject object) {
		return new MetaObjectFormTablePanel(object);
	}

	public static MetaObjectListPanel createMetaObjectListPanel(
		String title,
		Class metaObjectClass,
		int type,
		boolean showControlButtons) {
		return new MetaObjectListPanel(title, metaObjectClass, type, showControlButtons);
	}
}
