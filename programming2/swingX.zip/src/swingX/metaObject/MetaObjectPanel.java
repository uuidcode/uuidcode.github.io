package swingX.metaObject;

import javax.swing.JPanel;

public class MetaObjectPanel extends JPanel {
}
