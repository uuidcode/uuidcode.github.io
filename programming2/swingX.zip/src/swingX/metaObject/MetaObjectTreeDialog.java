package swingX.metaObject;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.tree.DefaultMutableTreeNode;

import swingX.util.UIUtilities;

public class MetaObjectTreeDialog
	extends JDialog
	implements WindowListener {
	public MetaObjectTreePanel metaObjectTreePanel;

	public MetaObjectTreeDialog(
		final Container owner,
		String title,
		DefaultMutableTreeNode rootNode) {

		super(UIUtilities.getFrame(owner), title, false);
		this.addWindowListener(this);

		JPanel panel = new JPanel(new BorderLayout());
		panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

		this.metaObjectTreePanel = new MetaObjectTreePanel(rootNode);
		panel.add(metaObjectTreePanel, BorderLayout.CENTER);

		JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JButton close = new JButton("close");
		close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MetaObjectTreeDialog.this.dispose();
			}
		});
		bottomPanel.add(close);

		JPanel contentPanel = new JPanel();
		BoxLayout boxLayout = new BoxLayout(contentPanel, BoxLayout.Y_AXIS);
		contentPanel.setLayout(boxLayout);
		contentPanel.add(panel);
		contentPanel.add(new JSeparator());
		contentPanel.add(bottomPanel);

		this.setContentPane(contentPanel);
		this.pack();
		this.setResizable(true);

		int width = 800;
		int height = 650;

		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (screen.width - width) / 2;
		int y = (screen.height - height) / 2;
		setBounds(x, y, width, height);
	}

	public void windowActivated(WindowEvent e) {
	}

	public void windowClosed(WindowEvent e) {
	}

	public void windowClosing(WindowEvent e) {
		MetaObjectTreeDialog.this.dispose();
	}

	public void windowDeactivated(WindowEvent e) {
	}

	public void windowDeiconified(WindowEvent e) {
	}

	public void windowIconified(WindowEvent e) {
	}

	public void windowOpened(WindowEvent e) {
	}
}