package swingX.metaObject;

import java.util.Vector;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolTip;
import javax.swing.text.JTextComponent;

import swingX.component.MultiLineToolTip;
import swingX.util.UIUtilities;

public class MetaField {
	public final static int TEXT = 1;
	public final static int PASSWORD = 2;
	public final static int TEXTAREA = 3;
	public final static int IMAGE = 4;
	public final static int CHECKBOX = 5;
	public final static int FILES_ONLY = 6;
	public final static int DIRECTORIES_ONLY = 7;
	public final static int FILES_AND_DIRECTORIES = 8;
	public final static int COMBOBOX = 9;
	
	public final static int LEFT = JTextField.LEFT;
	public final static int CENTER = JTextField.CENTER;
	public final static int RIGHT = JTextField.RIGHT;

	public boolean visibleInForm;
	public boolean visibleInList;
	public String name;
	public String displayName;
	private String value;
	public int size;
	public int align;
	public JComponent displayComponent;
	public int type;
	public String suffix;
	public String tooltip;

	/**
	 * @param name
	 * @param displayName
	 * @param suffix
	 * @param value
	 * @param size
	 * @param align
	 * @param visibleInForm
	 * @param visibleInList
	 * @param type
	 * @param tooltip
	 */
	public MetaField(
		String name,
		String displayName,
		String suffix,
		String value,
		int size,
		int align,
		boolean visibleInForm,
		boolean visibleInList,
		int type,
		String tooltip) {

		this.name = name;
		this.displayName = displayName;
		this.suffix = suffix;
		this.value = value;
		this.size = size;
		this.align = align;
		this.visibleInForm = visibleInForm;
		this.visibleInList = visibleInList;
		this.type = type;
		this.tooltip = tooltip;

		if (type == TEXT || type == IMAGE) {
			JTextField field = new JTextField() {
				public JToolTip createToolTip() {
					MultiLineToolTip tip = new MultiLineToolTip();
					tip.setComponent(this);
					return tip;
				}
			};
			field.setColumns(size);
			field.setText(this.value);
			field.setHorizontalAlignment(this.align);
			this.displayComponent = field;
		} else if (type == PASSWORD) {
			JPasswordField field = new JPasswordField() {
				public JToolTip createToolTip() {
					MultiLineToolTip tip = new MultiLineToolTip();
					tip.setComponent(this);
					return tip;
				}
			};
			field.setColumns(size);
			field.setText(this.value);
			this.displayComponent = field;
		} else if (type == TEXTAREA) {
			JTextArea field = new JTextArea(4, size) {
				public JToolTip createToolTip() {
					MultiLineToolTip tip = new MultiLineToolTip();
					tip.setComponent(this);
					return tip;
				}
			};
			field.setText(this.value);
			this.displayComponent = field;
		} else if (type == CHECKBOX) {
			JCheckBox field = new JCheckBox() {
				public JToolTip createToolTip() {
					MultiLineToolTip tip = new MultiLineToolTip();
					tip.setComponent(this);
					return tip;
				}
			};
			field.setSelected(Boolean.valueOf(this.value).booleanValue());
			this.displayComponent = field;
		} else if (
			type == FILES_ONLY
				|| type == DIRECTORIES_ONLY
				|| type == FILES_AND_DIRECTORIES) {
			final JTextField field = new JTextField() {
				public JToolTip createToolTip() {
					MultiLineToolTip tip = new MultiLineToolTip();
					tip.setComponent(this);
					return tip;
				}
			};
			field.setEditable(false);
			field.setColumns(size);
			field.setText(this.value);
			field.setToolTipText("Click to edit");
			field.addMouseListener(new MouseListener() {
				public void mouseClicked(MouseEvent e) {
					File f = new File(field.getText());
					boolean isValidFile = false;

					JFileChooser fileChooser = null;
					if (f.exists()) {
						fileChooser = new JFileChooser(f);
					} else {
						fileChooser = new JFileChooser();
					}

					fileChooser.setFileSelectionMode(getFileSelectionMode());

					fileChooser.showOpenDialog(UIUtilities.getFrame(field));
					File file = fileChooser.getSelectedFile();
					if (file != null) {
						field.setText(file.toString());
					}
				}

				public void mouseEntered(MouseEvent e) {
				}

				public void mouseExited(MouseEvent e) {
				}

				public void mousePressed(MouseEvent e) {
				}

				public void mouseReleased(MouseEvent e) {
				}
			});
			
			this.displayComponent = field;
			if (this.tooltip != null && this.tooltip.trim().length() > 0) {
				this.displayComponent.setToolTipText(this.tooltip);
			}
		} else if (type == COMBOBOX) {
			final JComboBox field = new JComboBox() {
				public JToolTip createToolTip() {
					MultiLineToolTip tip = new MultiLineToolTip();
					tip.setComponent(this);
					return tip;
				}
			};
			this.displayComponent = field;
		}
	}
	
	public void setSelectableValue(Object[] objects) {
		if (this.type == COMBOBOX) {
			JComboBox comboBox = (JComboBox) this.displayComponent;
			for (int i = 0; i < objects.length; i++) {
				comboBox.addItem(objects[i]);	
			}
			//comboBox.setSelectedItem(this.value);
		}
	}
	
	private int getFileSelectionMode() {
		if (this.type == FILES_ONLY) {
			return JFileChooser.FILES_ONLY;
		} else if (this.type == DIRECTORIES_ONLY) {
			return JFileChooser.DIRECTORIES_ONLY;
		} else if (this.type == FILES_AND_DIRECTORIES) {
			return JFileChooser.FILES_AND_DIRECTORIES;
		} else {
			return JFileChooser.FILES_ONLY;
		}
	}

	public static MetaField[] getField(MetaObject object) throws Exception {
		Field[] fields = object.getClass().getDeclaredFields();
		Vector validField = new Vector();
		AccessibleObject.setAccessible(fields, true);
		for (int i = 0; i < fields.length; i++) {
			int modifiers = fields[i].getModifiers();
			if (Modifier.isPublic(modifiers)
				&& !Modifier.isStatic(modifiers)
				&& fields[i].getType().equals(MetaField.class)) {
				validField.add(fields[i].get(object));
			}
		}
		return (MetaField[]) validField.toArray(new MetaField[0]);
	}

	public void save() {
		if (this.isTextComponent()) {
			this.value = ((JTextComponent) this.displayComponent).getText();
		} else if (type == CHECKBOX) {
			this.value =
				String.valueOf(
					((JCheckBox) this.displayComponent).isSelected());
		} else if (type == COMBOBOX) {
			Object selectedObject  = ((JComboBox) this.displayComponent).getSelectedItem();
			if (selectedObject != null) {
				this.value = selectedObject.toString(); 
			} else {
				this.value = "";
			}
		}
	}

	public static void save(MetaField[] fields) {
		for (int i = 0; i < fields.length; i++) {
			fields[i].save();
		}
	}

	public String toString() {
		try {
			return Inspector.toString(this);
		} catch (Exception e) {
		}
		return null;
	}

	public String getValue() {
		this.save();
		return this.value;
	}

	private boolean isTextComponent() {
		return this.type == TEXT
			|| type == IMAGE
			|| type == PASSWORD
			|| type == TEXTAREA
			|| type == FILES_ONLY
			|| type == DIRECTORIES_ONLY
			|| type == FILES_AND_DIRECTORIES;
	}

	public void setValue(String value) {
		if (this.isTextComponent()) {
			((JTextComponent) this.displayComponent).setText(value);
		} else if (this.type == CHECKBOX) {
			((JCheckBox) this.displayComponent).setSelected(
				Boolean.valueOf(value).booleanValue());
		} else if (this.type == COMBOBOX) {
			JComboBox comboBox = ((JComboBox) this.displayComponent);
			comboBox.setSelectedItem(value);
		}
		this.value = value;
	}

	public boolean equals(Object object) {
		if (object != null && object instanceof MetaField) {
			MetaField metaField = (MetaField) object;
			return this.name.equals(metaField.name);
		}
		return false;
	}
}